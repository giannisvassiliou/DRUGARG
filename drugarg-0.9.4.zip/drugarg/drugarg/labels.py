"""Export labelling sheets. Output only: nothing here changes how verdicts are computed."""
from __future__ import annotations

import csv
import hashlib
import sqlite3
from pathlib import Path
from typing import Dict, List

from .af import harms_of
from .ddinter import management_profile

ACTIONS = "avoid | avoid_unless_necessary | dose | timing | monitor | none"
HARMS = "bleeding; qt; hyperkalaemia; serotonin; renal; cns_respiratory; myelosuppression; other; none"


def export_management(ddinter_db: str, out: str) -> dict:
    """Distinct DDInter management texts in the local cache -> a blind sheet to label and a separate key with
    drugarg's own reading. Labellers must not open the key before they finish."""
    db = sqlite3.connect(ddinter_db)
    names: Dict[str, str] = {}
    for raw, ddid in db.execute("SELECT raw, ddid FROM names WHERE ddid IS NOT NULL"):
        names.setdefault(ddid, raw)
    groups: Dict[str, dict] = {}
    for a, b, level, inter, mgmt in db.execute(
            "SELECT a, b, level, interaction, management FROM mgmt WHERE management IS NOT NULL AND management != ''"):
        t = " ".join(mgmt.split())
        g = groups.setdefault(t, {"pairs": [], "levels": set(), "interaction": " ".join((inter or "").split())})
        g["pairs"].append(f"{names.get(a, a)} + {names.get(b, b)}")
        if level:
            g["levels"].add(level)
    rows = sorted(groups.items(), key=lambda kv: hashlib.sha1(kv[0].encode()).hexdigest())  # stable, not sorted by drug
    outd = Path(out)
    outd.mkdir(parents=True, exist_ok=True)
    with open(outd / "mgmt_texts_blind.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["text_id", "example_pairs", "n_pairs", "ddinter_level", "interaction", "management",
                    f"label_action ({ACTIONS})", f"label_harms ({HARMS})", "unsure (x)", "notes"])
        for i, (t, g) in enumerate(rows, 1):
            w.writerow([f"T{i:04d}", "; ".join(g["pairs"][:3]), len(g["pairs"]), "/".join(sorted(g["levels"])),
                        g["interaction"], t, "", "", "", ""])
    with open(outd / "mgmt_texts_key.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["text_id", "system_action", "system_reason", "system_harms"])
        for i, (t, g) in enumerate(rows, 1):
            p = management_profile(t)
            act = ("avoid_unless_necessary" if p["avoid_preferred"] else p["mitigation"]) if p["mitigation"] else (
                "avoid" if p["reason"].startswith("avoid") else "none")
            w.writerow([f"T{i:04d}", act, p["reason"], "; ".join(harms_of(g["interaction"], t))])
    return {"texts": len(rows), "pairs": sum(len(g["pairs"]) for g in groups.values()), "out": str(outd)}
