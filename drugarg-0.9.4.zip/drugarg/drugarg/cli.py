"""drugarg command line.

  drugarg probe   --endpoint URL                     # which predicates does this endpoint use?
  drugarg run     --disease-text arthritis --comed warfarin --patient-condition c_ulcerhx -o out/
  drugarg eval    --disease-text arthritis --comed warfarin --comed sertraline --patient-condition c_ckd
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from . import af, export
from .extract import Extractor, Vocab
from .rules import Rules
from .sparql import HTTPEndpoint, RDFLibEndpoint

DEFAULT_ENDPOINT = "https://bio2rdf.org/sparql"


def endpoint_from(a):
    if a.rdf_file:
        return RDFLibEndpoint(*a.rdf_file)
    return HTTPEndpoint(a.endpoint, timeout=a.timeout, retries=a.retries,
                        cache_dir=None if a.no_cache else a.cache, method=a.method)


def common(p):
    g = p.add_argument_group("knowledge source")
    g.add_argument("--endpoint", default=DEFAULT_ENDPOINT, help=f"SPARQL endpoint (default {DEFAULT_ENDPOINT})")
    g.add_argument("--rdf-file", nargs="+", help="query a local RDF dump with rdflib instead of an endpoint")
    g.add_argument("--vocab", help="JSON file overriding predicate URIs (see extract.Vocab)")
    g.add_argument("--timeout", type=float, default=60)
    g.add_argument("--retries", type=int, default=3)
    g.add_argument("--method", choices=["GET", "POST"], default="GET")
    g.add_argument("--cache", default=".drugarg-cache", help="query cache folder for reproducible runs")
    g.add_argument("--no-cache", action="store_true")
    g.add_argument("--ddinter", metavar="DB", help="DDInter severity index (from ddinter-index); overrides other severities")
    g.add_argument("--ddinter-fetch", action="store_true",
                   help="fetch DDInter management advice for the pairs this run needs (1 request/s, cached in the index)")
    g.add_argument("--ddinter-delay", type=float, default=1.0, help="seconds between DDInter requests (default 1)")
    g.add_argument("--no-management", action="store_true", help="ignore DDInter management advice (severity only)")
    g.add_argument("--management-mitigates-major", action="store_true",
                   help="let DDInter management advice mitigate major interactions too (off by default)")
    g.add_argument("--primekg", metavar="DB", help="use a PrimeKG SQLite index (from primekg-index) instead of SPARQL")


def query_args(p):
    p.add_argument("--disease-text", action="append", required=True,
                   help="keyword matched against DrugBank indication text (repeatable, OR)")
    p.add_argument("--comed", action="append", default=[], help="co-medication name or DrugBank id (repeatable)")
    p.add_argument("--patient-condition", action="append", default=[], help="condition key from the rules file (repeatable)")
    p.add_argument("--patient-disease", action="append", default=[],
                   help="PrimeKG only: patient disease name (substring of KG disease nodes); fires KG contraindication edges")
    p.add_argument("--offlabel", action="store_true", help="PrimeKG only: also use off-label use edges for candidates")
    p.add_argument("--exclude-drug", action="append", default=[], metavar="NAME",
                   help="drop a candidate (reviewed indication error); repeatable")
    p.add_argument("--corroborate-indication", action="store_true",
                   help="PrimeKG only: drop a candidate whose DrugBank indication text does not mention the disease")
    p.add_argument("--max-candidates", type=int, default=200,
                   help="candidates kept per query (0.9.4 default 200; 0.9.3 used 50, which cut the list alphabetically)")
    p.add_argument("--exclude-text", nargs="*", default=[],
                   help='phrases that do not count as a disease match, e.g. "ocular hypertension" "pulmonary"')
    p.add_argument("--require-group", nargs="*", default=["approved"],
                   help="DrugBank groups a candidate must have (default: approved; pass none to disable)")
    p.add_argument("--exclude-group", nargs="*", default=["withdrawn", "nutraceutical", "illicit"],
                   help="DrugBank groups that exclude a candidate (default: withdrawn nutraceutical illicit)")
    p.add_argument("--threshold", choices=["minor", "moderate", "major"], default="moderate")
    p.add_argument("--mitigation", action="append", choices=["monitor", "ppi", "dose", "timing"],
                   help="mitigations available (repeatable); default: monitor, dose, timing")
    p.add_argument("--no-mitigations", action="store_true")
    p.add_argument("--no-duplication", action="store_true")
    p.add_argument("--no-necessity", action="store_true",
                   help="do not let accepted alternatives overrule 'avoid unless necessary' mitigations")
    p.add_argument("--no-curated-indications", action="store_true",
                   help="do not add the curated indications from rules.json (e.g. paracetamol for osteoarthritis)")
    p.add_argument("--no-same-harm", action="store_true",
                   help="allow several mitigations against the same harm (default: one mitigation per harm)")
    p.add_argument("--untyped-ddi", choices=["lenient", "strict", "ignore", "ddinter-silent"], default="lenient",
                   help="KG interactions without severity: lenient = moderate and monitorable (default), "
                        "strict = moderate, no mitigation, ignore = not an objection")
    p.add_argument("--rules", help="rules JSON (default: bundled data/rules.json)")
    p.add_argument("--no-weak-review", action="store_true",
                   help="0.9.3 behaviour: a rejection resting only on unrated KG edges stays 'rejected' (default: 'review')")
    p.add_argument("--alt-scope", choices=["query", "node"], default="query",
                   help="alternatives for 'avoid unless necessary': any candidate of the query (default) or only "
                        "candidates sharing a disease node (0.9.3)")
    p.add_argument("--legacy-harm-tags", action="store_true",
                   help="0.9.3 harm tags (one undirected potassium tag)")
    p.add_argument("--no-094-rules", action="store_true",
                   help="drop the curated rules added in 0.9.4 (rules.json entries with \"since\": \"0.9.4\")")
    p.add_argument("--as-0.9.3", dest="as_093", action="store_true",
                   help="reproduce 0.9.3 exactly: all of the above plus --max-candidates 50")


def legacy(a) -> None:
    """--as-0.9.3 switches on every 0.9.3 toggle; harm tags are module state, set once per run."""
    if getattr(a, "as_093", False):
        a.no_weak_review = a.legacy_harm_tags = a.no_094_rules = True
        a.alt_scope = "node"
        a.max_candidates = 50
    af.use_legacy_harm_tags(getattr(a, "legacy_harm_tags", False))


def context_from(a) -> af.Context:
    legacy(a)
    mits = {"monitor": False, "ppi": False, "dose": False, "timing": False}
    if not a.no_mitigations:
        for k in (a.mitigation or ["monitor", "dose", "timing"]):
            mits[k] = True
    return af.Context(conditions=a.patient_condition, threshold=a.threshold, mitigations=mits,
                      duplication=not a.no_duplication, untyped_ddi=a.untyped_ddi,
                      use_management=not getattr(a, "no_management", False),
                      management_mitigates_major=getattr(a, "management_mitigates_major", False),
                      necessity=not getattr(a, "no_necessity", False),
                      same_harm=not getattr(a, "no_same_harm", False),
                      weak_review=not getattr(a, "no_weak_review", False),
                      alt_scope=getattr(a, "alt_scope", "query"))


def load(a):
    vocab = Vocab.from_dict(json.loads(Path(a.vocab).read_text(encoding="utf-8"))) if a.vocab else Vocab()
    legacy(a)
    rules = Rules.load(a.rules, drop_since="0.9.4" if getattr(a, "no_094_rules", False) else None)
    unknown = [c for c in a.patient_condition if c not in rules.conditions]
    if unknown:
        sys.exit(f"unknown condition(s) {unknown}; known: {', '.join(rules.conditions)}")
    if a.primekg:
        from .primekg import PrimeKGExtractor
        pk = PrimeKGExtractor(a.primekg)
        if not getattr(a, "no_curated_indications", False):
            pk.curated_indications = rules.d.get("curated_indications", [])
        return pk, rules
    if a.patient_disease:
        sys.exit("--patient-disease needs --primekg (Bio2RDF DrugBank has no disease nodes for contraindications)")
    return Extractor(endpoint_from(a), vocab), rules


def do_extract(ex, a):
    args = (a.disease_text, a.comed, a.max_candidates, None, a.require_group, a.exclude_group, a.exclude_text)
    sg = ex.extract(*args, patient_diseases=a.patient_disease, include_offlabel=a.offlabel,
                                     corroborate=getattr(a, "corroborate_indication", False)) if a.primekg else ex.extract(*args)
    if getattr(a, "exclude_drug", None):
        from .extract import apply_exclusions
        apply_exclusions(sg, a.exclude_drug)
    if getattr(a, "ddinter", None):
        from .ddinter import DDInter
        DDInter(a.ddinter).annotate(sg, fetch=getattr(a, "ddinter_fetch", False), delay=getattr(a, "ddinter_delay", 1.0))
    return sg


def cmd_probe(a):
    ex = Extractor(endpoint_from(a), Vocab.from_dict(json.loads(Path(a.vocab).read_text(encoding="utf-8"))) if a.vocab else None)
    res = ex.probe(a.drug)
    short = lambda u: u.replace("http://bio2rdf.org/", "").replace("http://purl.org/dc/terms/", "dct:") \
        .replace("http://www.w3.org/2000/01/rdf-schema#", "rdfs:").replace("http://www.w3.org/1999/02/22-rdf-syntax-ns#", "rdf:")
    print(f"# Predicates on drugbank:{a.drug}")
    for r in res["drug_predicates"]:
        print(f"  {r.get('n','?'):>5}  {short(r['p'])}   e.g. {r.get('example','')[:80]}")
    print("# Indication resource (the text must be on one of these predicates)")
    for r in res["indication_resource"]:
        print(f"  {short(r['p'])}  {r['o'][:150]}")
    if not res["indication_resource"]:
        print("  none: the indication is a literal, or set 'indication' in a --vocab file")
    print("# One DDI resource, all triples")
    for r in res["ddi_resource"]:
        print(f"  {short(r['x'])}  {short(r['p'])}  {r['o'][:150]}")
    if not res["ddi_resource"]:
        print("  none found: set ddi_path in a --vocab file")
    print("# Categories")
    for r in res["categories"]:
        print(f"  {short(r['c'])}  {short(r.get('p',''))}  {r.get('o','')[:80]}")


def pipeline(ex, rules, a, ctx):
    t0 = time.perf_counter()
    sg = do_extract(ex, a)
    t_ex = time.perf_counter() - t0
    t1 = time.perf_counter()
    F = af.build(sg, ctx, rules)
    t_build = time.perf_counter() - t1
    R = af.solve(F)
    base = af.filter_baseline(F)
    t2 = time.perf_counter()
    expl = af.explain(F, R, base)
    t_expl = time.perf_counter() - t2
    from . import __version__
    stats = {
        "drugarg_version": __version__, "endpoint": ex.ep.name, "matching_drugs": sg.query.get("matching_drugs"), "candidates": len(sg.candidates), "comedications_resolved": sg.comeds,
        "unresolved": sg.unresolved, "kg_ddis_found": len(sg.ddis),
        "ddinter_coverage": sg.query.get("ddinter_coverage"),
        "arguments": {t: sum(1 for x in F.args.values() if x.t == t) for t in ("USE", "IND", "CI", "DDI", "MIT")},
        "attacks": len(F.attacks), "supports": len(F.supports),
        "objection_sources": provenance(F),
        "undecided_grounded": R.undecided,
        "preferred_extensions": len(R.preferred) if R.preferred is not None else None,
        "seconds": {"sparql_extraction": round(t_ex, 4), "af_construction": round(t_build, 5),
                    "semantics": round(R.seconds, 5), "explanations_and_counterfactuals": round(t_expl, 4)},
        "queries": ex.ep.log,
    }
    return sg, F, R, base, expl, stats


def provenance(F) -> dict:
    """How many contraindication / interaction objections come from the KG vs from curated rules."""
    out: dict = {}
    for x in F.args.values():
        if x.t in ("CI", "DDI"):
            k = f"{x.t}: {x.source or 'curated'}"
            out[k] = out.get(k, 0) + 1
    return dict(sorted(out.items()))


def cmd_primekg_index(a):
    from .primekg import build_index
    st = build_index(a.kg, a.features, a.out)
    print(f"indexed {a.kg} -> {a.out} in {st['seconds']}s")
    print(f"  drug-disease edges {st['drug_disease_edges']:,} · drug-drug pairs {st['drug_drug_pairs']:,} · "
          f"drug/disease nodes {st['nodes']:,} · drug feature rows {st['drug_features']:,}")
    for rel in ("indication", "contraindication", "off-label use", "drug_drug"):
        print(f"  {rel:18} {st['relations'].get(rel, 0):>10,} rows in kg.csv")


def cmd_ddinter_index(a):
    from .ddinter import build_index
    st = build_index(a.paths, a.out)
    print(f"indexed {len(st['files'])} DDInter file(s) -> {a.out}: {st['pairs']:,} drug pairs, {st['drugs']:,} drug names")
    print("  rows by level: " + ", ".join(f"{k} {v:,}" for k, v in sorted(st["rows_by_level"].items())))
    if st["management_pages_kept"]:
        print(f"  kept {st['management_pages_kept']} previously fetched management page(s)")


def cmd_export_mgmt(a):
    from .labels import export_management
    r = export_management(a.db, a.out)
    print(f"{r['texts']} distinct management texts ({r['pairs']} pairs) -> {r['out']}/mgmt_texts_blind.csv "
          f"(label this) and mgmt_texts_key.csv (do not open until labelling is done)")


def cmd_ddinter_show(a):
    """Debug one pair: IDs, level, fetched page, parsed text and the mitigation it maps to."""
    from .ddinter import DDInter, classify_management
    dd = DDInter(a.db)
    if not dd.has_ids:
        sys.exit("this index has no DDInter IDs; rebuild it with drugarg 0.5+: drugarg ddinter-index <csv folder> -o " + a.db)
    ia, ib = dd.ddid(a.drug_a), dd.ddid(a.drug_b)
    print(f"{a.drug_a} -> {ia or 'not in DDInter'}   {a.drug_b} -> {ib or 'not in DDInter'}")
    if not (ia and ib):
        return
    print(f"level in bulk files: {dd.level(a.drug_a, a.drug_b) or 'no record'}")
    if a.fetch or not dd.management(ia, ib):
        print(dd.fetch_management([(ia, ib)], delay=0, refresh=a.fetch))
    info = dd.management(ia, ib)
    if not info:
        return
    print(f"url: {info['url']}  (HTTP {info['status']})")
    print(f"level on page: {info['level'] or '?'}")
    print(f"Interaction: {info['interaction'] or '(not found)'}")
    print(f"Management:  {info['management'] or '(not found)'}")
    mit, why = classify_management(info["management"])
    print(f"=> mitigation: {mit or 'none'}   ({why})")
    if a.save_html:
        a_, b_ = dd._key(ia, ib)
        html = dd.db.execute("SELECT html FROM mgmt WHERE a=? AND b=?", (a_, b_)).fetchone()[0]
        Path(a.save_html).write_text(html or "", encoding="utf-8")
        print(f"raw HTML saved to {a.save_html}")


def cmd_ddinter_reparse(a):
    from .ddinter import DDInter
    print(f"re-parsed {DDInter(a.db).reparse()} cached page(s)")


def cmd_check_queries(a):
    """Pre-freeze check: does every query resolve? Prints counts only, never candidates or verdicts."""
    from .batch import _query_args
    data = json.loads(Path(a.queries).read_text(encoding="utf-8"))
    a.max_candidates, a.offlabel, a.corroborate_indication = 10**6, False, False
    a.require_group, a.exclude_group, a.exclude_text = ["approved"], ["withdrawn", "nutraceutical", "illicit"], []
    a.vocab = None; a.rules = None; a.patient_condition = []; a.patient_disease = []
    ex, rules = load(a)
    bad = 0
    print("id | disease nodes | matching drugs | unresolved co-medications | patient-disease nodes | unknown conditions")
    for q in data["queries"]:
        qa = _query_args(a, q)
        sg = ex.extract(qa.disease_text, qa.comed, qa.max_candidates, None, qa.require_group, qa.exclude_group, qa.exclude_text,
                        patient_diseases=qa.patient_disease)
        nodes = sg.query.get("matched_disease_nodes") or []
        pdn = sg.query.get("patient_disease_nodes") or {}
        unk = [c for c in qa.patient_condition if c not in rules.conditions]
        problem = (not nodes or not sg.query.get("matching_drugs") or sg.unresolved or unk
                   or any(not v for v in pdn.values()))
        bad += bool(problem)
        print(f"{'!! ' if problem else '   '}{q['id']} | {len(nodes)} | {sg.query.get('matching_drugs', 0)} | "
              f"{', '.join(sg.unresolved) or '-'} | {', '.join(f'{k}: {len(v)}' for k, v in pdn.items()) or '-'} | {', '.join(unk) or '-'}")
    print(f"{bad} of {len(data['queries'])} queries need attention (marked !!)")


def cmd_batch(a):
    """Run many queries (JSON list) with the same settings; write batch.md / batch.csv / batch.json."""
    from . import batch
    from importlib.resources import files
    src = Path(a.queries) if a.queries else files("drugarg").joinpath("data/queries.json")
    data = json.loads(src.read_text(encoding="utf-8"))
    queries = data["queries"] if isinstance(data, dict) else data
    if a.only:
        queries = [q for q in queries if any(o in q["id"] for o in a.only)]
    ex, rules = load(a)
    bad = sorted({c for q in queries for c in q.get("patient_condition", []) if c not in rules.conditions})
    if bad:
        sys.exit(f"unknown condition(s) in queries: {bad}; known: {', '.join(rules.conditions)}")
    res = batch.run_batch(ex, rules, a, context_from(a), queries, do_extract)
    out = Path(a.out)
    batch.write(out, res)
    s = res["summary"]
    print(f"\n{s['queries']} queries ({s['failed']} failed). Disagreements with the filter: "
          + ", ".join(f"{k.replace('disagree_', '')} {v}" for k, v in s["disagreements"].items()))
    print(f"necessity: {s['necessity']}")
    print(f"context-dependent drugs: {len(s['context_dependent_drugs'])}; KG-only rejections: {s['kg_only_rejections']}")
    print(f"outputs in {out}/ (batch.md, batch.csv, batch.json)")


def cmd_primekg_find(a):
    from .primekg import PrimeKGExtractor
    ex = PrimeKGExtractor(a.db)
    rows = ex.find_diseases(a.text)
    if not rows:
        print(f"no disease node contains '{a.text}'")
    for idx, did, name, k in rows:
        print(f"{k:>6} drug edges  {name}")


def cmd_primekg_text(a):
    from .primekg import PrimeKGExtractor
    ex = PrimeKGExtractor(a.db)
    for n in a.drugs:
        r = ex.indication_text(n)
        if not r:
            print(f"{n}: not found"); continue
        name, dbid, txt = r
        print(f"--- {name} ({dbid})\n{(txt or '(no indication text stored)')[:1500]}\n")


def cmd_primekg_info(a):
    from .primekg import PrimeKGExtractor
    info = PrimeKGExtractor(a.db).describe()
    print(json.dumps(info, indent=1, ensure_ascii=False)[:4000])


def cmd_run(a):
    ex, rules = load(a)
    ctx = context_from(a)
    sg, F, R, base, expl, stats = pipeline(ex, rules, a, ctx)
    ans = export.answers_json(F, R, base, expl, ctx, sg)
    out = Path(a.out)
    export.write_all(out, {
        "subgraph.json": sg.to_dict(), "subgraph.ttl": export.turtle(sg),
        "arggraph.json": export.arggraph_json(F, R), "arggraph.dot": export.dot(F, R),
        "answers.json": ans, "run.json": stats,
        "demo_dataset.json": export.demo_dataset(sg, F, rules),
        "report.md": export.report(expl, ans, {k: v for k, v in stats.items() if k != "queries"}),
    })
    print(f"{len(sg.candidates)} candidates, {len(sg.ddis)} KG interactions with {len(sg.comeds)} co-medication(s)"
          + (f"; unresolved: {', '.join(sg.unresolved)}" if sg.unresolved else ""))
    print(f"accepted {len(ans['accepted'])} · pick one {len(ans['alternatives'])} · rejected {len(ans['rejected'])} · review {len(ans.get('review', []))}"
          f" · rule filter rejects {len(ans['filter_rejected'])}")
    print(f"outputs in {out}/ (report.md, answers.json, arggraph.json/.dot, subgraph.ttl, demo_dataset.json)")


def cmd_eval(a):
    """Paper-style evaluation: bare / condition / condition+comed / full with mitigations, one extraction."""
    ex, rules = load(a)
    t0 = time.perf_counter()
    sg = do_extract(ex, a)
    t_ex = time.perf_counter() - t0
    from copy import deepcopy
    sg_bare = deepcopy(sg); sg_bare.comeds = []; sg_bare.ddis = []; sg_bare.kg_contra = []
    sg_cond = deepcopy(sg); sg_cond.comeds = []; sg_cond.ddis = []
    from dataclasses import replace
    c0 = context_from(a)
    none = {k: False for k in c0.mitigations}
    off = replace(c0, mitigations=none, duplication=False, necessity=False)
    runs = [
        ("bare", sg_bare, replace(off, conditions=[])),
        ("condition", sg_cond, off),
        ("condition+comed", sg, off),
        ("+mitigations", sg, replace(c0, duplication=False, necessity=False)),
        ("+mitigations+duplication", sg, replace(c0, duplication=True, necessity=False)),
        ("+necessity", sg, replace(c0, duplication=True, necessity=True)),
    ]
    rows = []
    bare_acc = None
    for name, g, ctx in runs:
        F = af.build(g, ctx, rules); R = af.solve(F); base = af.filter_baseline(F)
        uses = list(R.status)
        rej = [u for u in uses if R.status[u] == "rejected"]
        attributed = sum(1 for u in rej if any(F.args[x].t in ("CI", "DDI") and R.lab[x] == "in" for x in R.attackers[u]))
        flips = sum(1 for u in rej if af.counterfactual(F, u))
        acc = sum(1 for u in uses if R.status[u] == "accepted")
        bare_acc = acc if bare_acc is None else bare_acc
        reps = [af.solve(F).seconds for _ in range(20)]
        prov = provenance(F)
        kg_obj = sum(v for k, v in prov.items() if "KG" in k and "not in KG" not in k)
        dd_obj = sum(v for k, v in prov.items() if "DDInter" in k)
        all_obj = sum(prov.values())
        rows.append({
            "run": name, "arguments": len(F.args) - len(F.supports), "attacks": len(F.attacks),
            "objections_from_kg": f"{kg_obj}/{all_obj}",
            "ddinter_severity": f"{dd_obj}/{all_obj}",
            "accepted": acc, "pick_one": sum(1 for u in uses if R.status[u] == "alternative"), "rejected": len(rej),
            "filter_rejected": sum(1 for v in base.values() if v == "rejected"),
            "disagree_with_filter": sum(1 for u in uses if (R.status[u] == "rejected") != (base[u] == "rejected")),
            "shrinkage_vs_bare": bare_acc - acc,
            "defeat_attribution": round(attributed / len(rej), 3) if rej else None,
            "counterfactual_flip_rate": round(flips / len(rej), 3) if rej else None,
            "semantics_ms_median": round(sorted(reps)[len(reps) // 2] * 1000, 3),
        })
    cols = list(rows[0])
    print("| " + " | ".join(cols) + " |"); print("|" + "---|" * len(cols))
    for r in rows:
        print("| " + " | ".join("" if r[c] is None else str(r[c]) for c in cols) + " |")
    print(f"\nextraction: {t_ex:.2f}s over {len(ex.ep.log)} queries; {len(sg.candidates)} candidates; {len(sg.ddis)} KG DDIs")
    if a.out:
        export.write_all(Path(a.out), {"eval.json": {"rows": rows, "extraction_seconds": t_ex, "queries": ex.ep.log}})


def main(argv=None):
    # Windows consoles with legacy code pages (e.g. cp1253) cannot print some symbols
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    from . import __version__
    p = argparse.ArgumentParser(prog="drugarg", description="Query-driven argumentation over Bio2RDF DrugBank")
    p.add_argument("--version", action="version", version=f"drugarg {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)
    pp = sub.add_parser("probe", help="show the predicates an endpoint uses"); common(pp)
    pp.add_argument("--drug", default="DB01050"); pp.set_defaults(fn=cmd_probe)
    pr = sub.add_parser("run", help="extract, build the AF, solve, write outputs"); common(pr); query_args(pr)
    pr.add_argument("-o", "--out", default="out"); pr.set_defaults(fn=cmd_run)
    pi = sub.add_parser("primekg-index", help="build the SQLite index from PrimeKG kg.csv (+ drug_features.csv)")
    pi.add_argument("kg"); pi.add_argument("features", nargs="?")
    pi.add_argument("-o", "--out", default="primekg.sqlite"); pi.set_defaults(fn=cmd_primekg_index)
    pd_ = sub.add_parser("ddinter-index", help="build a severity index from DDInter ddinter_downloads_code_*.csv")
    pd_.add_argument("paths", nargs="+", help="folder(s) or CSV files"); pd_.add_argument("-o", "--out", default="ddinter.sqlite")
    pd_.set_defaults(fn=cmd_ddinter_index)
    ps = sub.add_parser("ddinter-show", help="debug one pair: fetch/parse DDInter management advice")
    ps.add_argument("db"); ps.add_argument("drug_a"); ps.add_argument("drug_b")
    ps.add_argument("--fetch", action="store_true", help="re-fetch even if cached")
    ps.add_argument("--save-html", metavar="FILE", help="save the raw page (to check the parser)")
    ps.set_defaults(fn=cmd_ddinter_show)
    pl = sub.add_parser("export-mgmt", help="write the DDInter management-text labelling sheets (blind sheet + key)")
    pl.add_argument("db"); pl.add_argument("-o", "--out", default="labels")
    pl.set_defaults(fn=cmd_export_mgmt)
    pq = sub.add_parser("ddinter-reparse", help="re-run the parser over cached pages (offline)")
    pq.add_argument("db"); pq.set_defaults(fn=cmd_ddinter_reparse)
    pb = sub.add_parser("batch", help="evaluate many queries (default set: data/queries.json)"); common(pb)
    pb.add_argument("queries", nargs="?", help="JSON file with {\"queries\": [{id, disease_text, comed, ...}]}")
    pb.add_argument("--only", nargs="*", help="run only queries whose id contains one of these strings")
    pb.add_argument("-o", "--out", default="batch")
    # the per-query fields come from the file; the remaining options are shared by all queries
    for args, kw in [(("--max-candidates",), dict(type=int, default=200)),
                     (("--no-weak-review",), dict(action="store_true")),
                     (("--alt-scope",), dict(choices=["query", "node"], default="query")),
                     (("--legacy-harm-tags",), dict(action="store_true")), (("--no-094-rules",), dict(action="store_true")),
                     (("--as-0.9.3",), dict(dest="as_093", action="store_true")), (("--offlabel",), dict(action="store_true")),
                     (("--corroborate-indication",), dict(action="store_true")),
                     (("--exclude-text",), dict(nargs="*", default=[])),
                     (("--require-group",), dict(nargs="*", default=["approved"])),
                     (("--exclude-group",), dict(nargs="*", default=["withdrawn", "nutraceutical", "illicit"])),
                     (("--threshold",), dict(choices=["minor", "moderate", "major"], default="moderate")),
                     (("--mitigation",), dict(action="append", choices=["monitor", "ppi", "dose", "timing"])),
                     (("--no-mitigations",), dict(action="store_true")), (("--no-duplication",), dict(action="store_true")),
                     (("--no-necessity",), dict(action="store_true")), (("--no-same-harm",), dict(action="store_true")),
                     (("--no-curated-indications",), dict(action="store_true")),
                     (("--untyped-ddi",), dict(choices=["lenient", "strict", "ignore", "ddinter-silent"], default="strict")),
                     (("--rules",), dict())]:
        pb.add_argument(*args, **kw)
    pb.set_defaults(fn=cmd_batch, patient_condition=[], patient_disease=[], disease_text=[], comed=[])
    pc = sub.add_parser("check-queries", help="pre-freeze check: do the queries resolve? (counts only, no verdicts)")
    pc.add_argument("queries"); pc.add_argument("--primekg", required=True)
    pc.set_defaults(fn=cmd_check_queries, sparql=None, endpoint=None, ddinter=None)
    pf = sub.add_parser("primekg-find", help="list PrimeKG disease nodes containing a text (to choose --patient-disease)")
    pf.add_argument("db"); pf.add_argument("text"); pf.set_defaults(fn=cmd_primekg_find)
    pt = sub.add_parser("primekg-text", help="show the DrugBank indication text stored for drugs (checks --corroborate-indication)")
    pt.add_argument("db"); pt.add_argument("drugs", nargs="+"); pt.set_defaults(fn=cmd_primekg_text)
    pn = sub.add_parser("primekg-info", help="check a PrimeKG index"); pn.add_argument("db"); pn.set_defaults(fn=cmd_primekg_info)
    pe = sub.add_parser("eval", help="paper-style evaluation table"); common(pe); query_args(pe)
    pe.add_argument("-o", "--out"); pe.set_defaults(fn=cmd_eval)
    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
