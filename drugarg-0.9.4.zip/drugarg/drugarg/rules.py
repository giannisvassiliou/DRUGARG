"""Curated rules: groups, condition contraindications, DDI severity and mitigation."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Optional

SEV = {"minor": 0, "moderate": 1, "major": 2}
DEFAULT = Path(__file__).parent / "data" / "rules.json"


class Rules:
    def __init__(self, data: dict) -> None:
        self.d = data
        self.mitigations: Dict[str, str] = data.get("mitigations", {})
        self.conditions: Dict[str, str] = data.get("conditions", {})
        self.groups = {g: (re.compile(v["category_regex"], re.I) if v.get("category_regex") else None,
                           set(v.get("ids", [])),
                           re.compile(v["exclude_regex"], re.I) if v.get("exclude_regex") else None,
                           set(v.get("exclude_ids", [])))
                       for g, v in data.get("groups", {}).items()}
        self.sev_rules = [(re.compile(r["pattern"], re.I), r["severity"]) for r in data.get("severity_rules", [])]
        self.mit_rules = [(re.compile(r["pattern"], re.I), r["mitigation"]) for r in data.get("mitigation_rules", [])]
        self.default_sev = data.get("default_severity", "moderate")

    @classmethod
    def load(cls, path: Optional[str] = None, drop_since: Optional[str] = None) -> "Rules":
        d = json.loads(Path(path or DEFAULT).read_text(encoding="utf-8"))
        if drop_since:   # reproduce an earlier version: drop entries marked {"since": drop_since}
            d = {k: ([x for x in v if not (isinstance(x, dict) and x.get("since") == drop_since)] if isinstance(v, list) else v)
                 for k, v in d.items()}
        return cls(d)

    def group_of(self, drug_id: str, categories: List[str]) -> str:
        for g, (rx, ids, ex, ex_ids) in self.groups.items():
            if drug_id in ex_ids:
                continue
            if drug_id in ids:
                return g
            if rx and any(rx.search(c) for c in categories) and not (ex and any(ex.search(c) for c in categories)):
                return g
        return ""

    def match(self, selector: str, drug_id: str, group: str, categories: List[str]) -> bool:
        if selector.startswith("grp:"):
            return group == selector[4:]
        if selector.startswith("cat:"):
            rx = re.compile(selector[4:], re.I)
            return any(rx.search(c) for c in categories)
        return selector.upper() == drug_id

    def contraindications(self, drug_id: str, group: str, cats: List[str], conditions: List[str]) -> List[dict]:
        return [r for r in self.d.get("contraindications", [])
                if r["condition"] in conditions and self.match(r["drugs"], drug_id, group, cats)]

    def classify_ddi(self, a: dict, b: dict, text: str) -> dict:
        """Severity/mitigation for a DDI. Curated overrides win; otherwise text heuristics.

        a, b: {id, group, categories}. Returns {severity, mitigation, source, effect}.
        """
        for o in self.d.get("ddi_overrides", []):
            for x, y in ((a, b), (b, a)):
                if self.match(o["a"], x["id"], x["group"], x["categories"]) and \
                   self.match(o["b"], y["id"], y["group"], y["categories"]):
                    return {"severity": o["severity"], "mitigation": o.get("mitigation"),
                            "source": "curated", "effect": o.get("effect") or text}
        if not text:  # interaction asserted by the KG without any description (e.g. PrimeKG drug_drug)
            return {"severity": self.d.get("untyped_ddi_severity", self.default_sev),
                    "mitigation": self.d.get("untyped_ddi_mitigation"), "source": "KG (severity unknown)",
                    "effect": "interaction asserted in the KG, no severity given"}
        sev = None
        for rx, s in self.sev_rules:
            if rx.search(text or "") and (sev is None or SEV[s] > SEV[sev]):
                sev = s
        mit = next((m for rx, m in self.mit_rules if rx.search(text or "")), None)
        return {"severity": sev or self.default_sev, "mitigation": mit,
                "source": "text-heuristic" if sev else "default", "effect": text}

    def kg_contra_policy(self, drug_id: str, group: str, cats: List[str], disease: str) -> dict:
        """KG contraindications carry no absolute/relative grade. Default: absolute, unless a
        kg_contraindication_rules entry (disease regex + drug selector) says otherwise."""
        for r in self.d.get("kg_contraindication_rules", []):
            if re.search(r["disease_regex"], disease, re.I) and self.match(r.get("drugs", drug_id), drug_id, group, cats):
                return {"kind": r["kind"], "mitigation": r.get("mitigation"), "note": r.get("note", "")}
        return {"kind": self.d.get("kg_contraindication_default", "absolute"), "mitigation": None, "note": ""}
