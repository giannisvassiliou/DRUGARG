"""Batch evaluation over many queries: where does argumentation differ from a filter, and why."""
from __future__ import annotations

import csv
import json
import time
from argparse import Namespace
from copy import copy
from dataclasses import replace
from pathlib import Path
from typing import Dict, List

from . import af

KG_ONLY = {"KG", "KG (severity unknown)"}   # objections asserted by the KG with no published or curated support

COLUMNS = ["id", "candidates", "objections", "ddinter_pairs", "management_pairs",
           "filter_rejected", "af_severity_only_rejected", "af_management_rejected", "af_necessity_rejected",
           "disagree_severity_only", "disagree_management", "disagree_necessity",
           "pick_one", "conditional_mitigations", "necessity_overruled", "necessity_held", "necessity_held_mitigations",
           "necessity_flips", "necessity_review", "weak_evidence_review", "cumulative_harm_rejections", "cumulative_harm_decisive", "cumulative_harm_decisive_review", "counterfactual_acceptable", "kg_edges_not_confirmed_by_ddinter", "excluded",
           "kg_only_rejections", "seconds", "error"]


def _query_args(base: Namespace, q: dict) -> Namespace:
    a = copy(base)
    a.disease_text = list(q["disease_text"])
    a.comed = list(q.get("comed", []))
    a.patient_condition = list(q.get("patient_condition", []))
    a.patient_disease = list(q.get("patient_disease", []))
    a.exclude_text = list(q.get("exclude_text", base.exclude_text or []))
    a.exclude_drug = list(q.get("exclude_drugs", []))
    return a


def _rejected(R) -> set:
    return {u for u, s in R.status.items() if s == "rejected"}


def _disagree(R, base) -> int:
    """'review' is a deferral to the clinician, not a verdict, so it never counts as a disagreement."""
    return sum(R.status[u] != "review" and (R.status[u] == "rejected") != (base[u] == "rejected") for u in R.status)


def run_one(ex, rules, a: Namespace, ctx: af.Context, do_extract) -> dict:
    t0 = time.perf_counter()
    sg = do_extract(ex, a)
    F_sev = af.build(sg, replace(ctx, use_management=False, necessity=False), rules)
    F_man = af.build(sg, replace(ctx, necessity=False), rules)
    F_nec = af.build(sg, replace(ctx, necessity=True), rules)
    R_sev, R_man, R_nec = af.solve(F_sev), af.solve(F_man), af.solve(F_nec)
    base = af.filter_baseline(F_nec)
    name = lambda uid: F_nec.args[uid].label

    overruled, held, review, held_mits = [], [], [], 0
    ok = ("accepted", "alternative")
    for mid, alts in F_nec.alternatives.items():
        target = mid[len("MIT:"):]
        d = F_nec.args[mid].drug
        drug = name(f"USE:{d}")
        pair = f"{drug} + {F_nec.args[target].with_}"
        if R_nec.lab.get(mid) == "in":
            held_mits += 1
            if R_nec.status.get(f"USE:{d}") in ok:
                held.append(pair)
        elif R_nec.lab.get(target) == "in":
            winners = [name(f"USE:{x}") for x in alts if R_nec.status.get(f"USE:{x}") in ok]
            if not winners:
                if R_nec.status.get(f"USE:{d}") != "review":
                    continue          # rejected for another reason (e.g. one mitigation per harm): not a review case
                weak = [name(f"USE:{x}") for x in alts if R_nec.lab.get(f"ALT:{x}") == "in"]
                review.append({"drug": pair, "status": R_nec.status.get(f"USE:{d}"),
                               "alternatives_blocked_only_by_weak_evidence": weak[:8], "n": len(weak)})
                continue
            cf = af.alternative_counterfactual(F_nec, mid)
            overruled.append({"drug": pair, "alternatives_accepted": len(winners), "e.g.": winners[:3],
                              "acceptable_only_if_all_unavailable": (cf[0] if cf and cf[1] not in ("rejected",) else None),
                              "mitigation_holds_if_all_unavailable": (cf[0] if cf else None),
                              "of_alternatives": len(alts)})
    held = sorted(set(held))
    flips = [{"drug": name(u), "without_necessity": R_man.status[u], "with_necessity": R_nec.status[u]}
             for u in R_nec.status if R_nec.status[u] != R_man.status.get(u)]

    weak_rev = [{"drug": name(u), "objections": [af.describe(F_nec.args[x]) for x in R_nec.attackers.get(u, [])
                                                  if F_nec.args[x].source in KG_ONLY and R_nec.lab.get(x) == "in"][:3]}
                for u, w in R_nec.review_why.items() if "weak evidence" in w]
    kg_only = []
    for u in _rejected(R_nec):
        eff = [x for x in R_nec.attackers.get(u, []) if F_nec.args[x].t in ("CI", "DDI") and R_nec.lab.get(x) == "in"]
        if eff and all(F_nec.args[x].source in KG_ONLY for x in eff):
            kg_only.append({"drug": name(u), "objections": [af.describe(F_nec.args[x]) for x in eff][:3]})

    cov = sg.query.get("ddinter_coverage") or {}
    row = {
        "id": "", "candidates": len(sg.candidates),
        "objections": sum(1 for x in F_nec.args.values() if x.t in ("CI", "DDI")),
        "ddinter_pairs": cov.get("pairs_with_ddinter_level", 0), "management_pairs": cov.get("pairs_with_management", 0),
        "filter_rejected": sum(v == "rejected" for v in base.values()),
        "af_severity_only_rejected": len(_rejected(R_sev)), "af_management_rejected": len(_rejected(R_man)),
        "af_necessity_rejected": len(_rejected(R_nec)),
        "disagree_severity_only": _disagree(R_sev, base), "disagree_management": _disagree(R_man, base),
        "disagree_necessity": _disagree(R_nec, base),
        "pick_one": sum(s == "alternative" for s in R_nec.status.values()),
        "conditional_mitigations": len(F_nec.alternatives), "necessity_overruled": len(overruled),
        "necessity_held": len(held), "necessity_held_mitigations": held_mits,
        "counterfactual_acceptable": sum(1 for o in overruled if o["acceptable_only_if_all_unavailable"]),
        "necessity_review": sum("necessity" in w for w in R_nec.review_why.values()),
        "weak_evidence_review": sum("weak evidence" in w for w in R_nec.review_why.values()),
        "cumulative_harm_rejections": len({a.drug for a in F_nec.args.values()
                                           if a.t == "CUM" and R_nec.status.get(f"USE:{a.drug}") == "rejected"}),
        "kg_edges_not_confirmed_by_ddinter": len(F_nec.silent),
        "excluded": len(sg.query.get("excluded_drugs") or []), "necessity_flips": len(flips), "kg_only_rejections": len(kg_only),
        "seconds": round(time.perf_counter() - t0, 3),
        "error": "; ".join(w for w in (
            "no candidates matched" if not sg.candidates else "",
            f"unresolved co-medication(s): {', '.join(sg.unresolved)}" if sg.unresolved else "",
            *sg.query.get("comedication_warnings", []),
            sg.query.get("candidates_truncated", ""),
            *[f"patient disease '{t}' matched no KG node" for t, v in (sg.query.get("patient_disease_nodes") or {}).items() if not v],
        ) if w),
    }
    cum_ids = {a.id for a in F_nec.args.values() if a.t == "CUM"}
    decisive, decisive_rev = [], []
    if cum_ids:
        R_nocum = af.solve(F_nec, removed=cum_ids)
        # decisive: without the cumulative-risk argument the drug would be acceptable;
        # decisive_review: it would only reach 'review' (its remaining support is weak evidence)
        decisive = sorted(name(u) for u in _rejected(R_nec) if R_nocum.status.get(u) in ("accepted", "alternative"))
        decisive_rev = sorted(name(u) for u in _rejected(R_nec) if R_nocum.status.get(u) == "review")
    row["cumulative_harm_decisive"] = len(decisive)
    row["cumulative_harm_decisive_review"] = len(decisive_rev)
    cum = [{"drug": name(f"USE:{a.drug}"), "harm": a.label, "objections": a.detail}
           for a in F_nec.args.values() if a.t == "CUM"]
    detail = {"overruled": overruled, "held": held, "review": review, "cumulative_harm": cum,
              "cumulative_harm_decisive": decisive, "cumulative_harm_decisive_review": decisive_rev, "flips": flips, "kg_only_rejections": kg_only,
              "weak_evidence_review": weak_rev,
              "unresolved_comeds": sg.unresolved, "comedication_resolution": sg.query.get("comedication_resolution"), "matched_disease_nodes": sg.query.get("matched_disease_nodes"),
              "patient_disease_nodes": sg.query.get("patient_disease_nodes"),
              "ddinter_unmatched": cov.get("unmatched", []),
              "corroboration": sg.query.get("corroboration"),
              "excluded_drugs": sg.query.get("excluded_drugs"),
              "curated_indications": sg.query.get("curated_indications"),
              "not_confirmed_by_ddinter": [f"{name('USE:' + d_)} + {sg.drugs.get(m_, {}).get('name', m_)}" for d_, m_ in F_nec.silent][:30]}
    return {"row": row, "detail": detail}


def run_batch(ex, rules, base_args: Namespace, ctx: af.Context, queries: List[dict], do_extract, log=print) -> dict:
    rows, details = [], {}
    for i, q in enumerate(queries, 1):
        a = _query_args(base_args, q)
        log(f"[{i}/{len(queries)}] {q['id']}")
        try:
            res = run_one(ex, rules, a, replace(ctx, conditions=list(a.patient_condition)), do_extract)
            res["row"]["id"] = q["id"]
            rows.append(res["row"]); details[q["id"]] = res["detail"]
            r = res["row"]
            log(f"    {r['candidates']} candidates · disagree {r['disagree_severity_only']}/{r['disagree_management']}"
                f"/{r['disagree_necessity']} (severity/+management/+necessity) · necessity overruled {r['necessity_overruled']}"
                f", held {r['necessity_held']} · KG-only rejections {r['kg_only_rejections']} · weak-evidence review {r['weak_evidence_review']}")
        except (Exception, SystemExit) as e:  # one bad query must not stop the batch
            rows.append({**{c: "" for c in COLUMNS}, "id": q["id"], "error": str(e)[:200]})
            log(f"    error: {e}")
    return {"rows": rows, "details": details, "summary": summarize(rows, details)}


def summarize(rows: List[dict], details: Dict[str, dict]) -> dict:
    ok = [r for r in rows if r["candidates"] != ""]
    tot = lambda k: sum(r[k] for r in ok)
    held_in: Dict[str, List[str]] = {}
    over_in: Dict[str, List[str]] = {}
    for qid, d in details.items():
        for x in sorted(set(d["held"])):
            held_in.setdefault(x, []).append(qid)
        for x in sorted({o["drug"] for o in d["overruled"]}):
            over_in.setdefault(x, []).append(qid)
    context_dependent = {dname: {"accepted_in": held_in[dname], "overruled_in": over_in[dname]}
                         for dname in sorted(set(held_in) & set(over_in))}
    return {
        "queries": len(rows), "failed": len(rows) - len(ok),
        "warnings": sum(bool(r["error"]) for r in ok),
        "candidates": tot("candidates"), "objections": tot("objections"),
        "queries_with_disagreement": {k: sum(r[k] > 0 for r in ok) for k in
                                      ("disagree_severity_only", "disagree_management", "disagree_necessity")},
        "disagreements": {k: tot(k) for k in ("disagree_severity_only", "disagree_management", "disagree_necessity")},
        "necessity": {"conditional_mitigations": tot("conditional_mitigations"), "overruled": tot("necessity_overruled"),
                      "held": tot("necessity_held"), "review": tot("necessity_review"),
                      "verdict_flips": tot("necessity_flips"),
                      "queries_where_it_fired": sum(r["conditional_mitigations"] > 0 for r in ok),
                      "overruled_but_acceptable_if_alternatives_unavailable": tot("counterfactual_acceptable")},
        "kg_edges_not_confirmed_by_ddinter": tot("kg_edges_not_confirmed_by_ddinter"),
        "cumulative_harm_rejections": tot("cumulative_harm_rejections"),
        "cumulative_harm_decisive": tot("cumulative_harm_decisive"),
        "cumulative_harm_decisive_review": tot("cumulative_harm_decisive_review"),
        "smallest_counterfactual": min((len(o["acceptable_only_if_all_unavailable"]) for d in details.values()
                                        for o in d["overruled"] if o.get("acceptable_only_if_all_unavailable")), default=None),
        "excluded_candidates": tot("excluded"),
        "context_dependent_drugs": context_dependent,
        "kg_only_rejections": tot("kg_only_rejections"),
        "weak_evidence_review": tot("weak_evidence_review"),
        "truncated_queries": sum("truncated" in r["error"] for r in ok),
        "pick_one": tot("pick_one"),
    }


def write(out: Path, res: dict) -> None:
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "batch.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader(); w.writerows(res["rows"])
    (out / "batch.json").write_text(json.dumps(res, indent=1, ensure_ascii=False), encoding="utf-8")
    (out / "batch.md").write_text(markdown(res), encoding="utf-8")


def markdown(res: dict) -> str:
    s = res["summary"]
    short = ["id", "candidates", "filter_rejected", "disagree_severity_only", "disagree_management", "disagree_necessity",
             "pick_one", "conditional_mitigations", "necessity_overruled", "necessity_held", "necessity_review",
             "necessity_flips", "cumulative_harm_rejections", "cumulative_harm_decisive", "kg_only_rejections",
             "weak_evidence_review", "error"]
    L = ["# DrugArg batch", "",
         f"{s['queries']} queries ({s['failed']} failed, {s['warnings']} with warnings in the error column), {s['candidates']} candidates, {s['objections']} objections.", "",
         "Disagreements with the rule filter (total, queries affected): "
         + "; ".join(f"{k.replace('disagree_', '')} {s['disagreements'][k]} in {s['queries_with_disagreement'][k]}"
                     for k in s["disagreements"]), "",
         f"Necessity: {s['necessity']['conditional_mitigations']} 'avoid unless necessary' mitigations in "
         f"{s['necessity']['queries_where_it_fired']} queries; overruled {s['necessity']['overruled']}, held "
         f"{s['necessity']['held']}, sent to review {s['necessity'].get('review', 0)} (alternatives blocked only by "
         f"unrated KG evidence), verdict flips {s['necessity']['verdict_flips']}.", "",
         f"Rejected with a one-mitigation-per-harm objection: {s.get('cumulative_harm_rejections', 0)}; "
         f"of these, acceptable without it (decisive): {s.get('cumulative_harm_decisive', 0)}; "
         f"'review' without it: {s.get('cumulative_harm_decisive_review', 0)}.", "",
         f"Rejections resting only on KG edges without published or curated support: {s['kg_only_rejections']}. "
         f"KG interaction edges dropped as not confirmed by DDInter (ddinter-silent policy): {s.get('kg_edges_not_confirmed_by_ddinter', 0)}. "
         f"Candidates excluded after review: {s.get('excluded_candidates', 0)}.", "",
         f"Sent to review because every effective objection is an unrated KG edge (0.9.4): {s.get('weak_evidence_review', 0)}. "
         f"Queries whose candidate list was truncated: {s.get('truncated_queries', 0)}.", "",
         f"Overruled 'avoid unless necessary' advice that would make the drug acceptable only if a set of alternatives were all unavailable: "
         f"{s['necessity'].get('overruled_but_acceptable_if_alternatives_unavailable', 0)} (smallest such set: "
         f"{s.get('smallest_counterfactual')} alternatives).", "",
         "| " + " | ".join(short) + " |", "|" + "---|" * len(short)]
    for r in res["rows"]:
        L.append("| " + " | ".join(str(r.get(c, "")) for c in short) + " |")
    if s["context_dependent_drugs"]:
        L += ["", "## Same interaction, different verdict (necessity)", ""]
        for dname, v in s["context_dependent_drugs"].items():
            L.append(f"- **{dname}**: mitigation holds in {', '.join(v['accepted_in'])}; overruled in {', '.join(v['overruled_in'])}")
    L += ["", "## Per query", ""]
    for qid, d in res["details"].items():
        bits = []
        if d["held"]:
            bits.append("necessity held, drug accepted (no acceptable alternative): " + ", ".join(d["held"]))
        if d["overruled"]:
            bits.append("necessity overruled: " + "; ".join(
                f"{x['drug']} ({x['alternatives_accepted']} alternatives, e.g. {', '.join(x['e.g.'])}"
                + (f"; acceptable only if all {len(x['acceptable_only_if_all_unavailable'])} of these were unavailable: "
                   f"{', '.join(x['acceptable_only_if_all_unavailable'][:6])}"
                   + (" …" if len(x['acceptable_only_if_all_unavailable']) > 6 else "")
                   if x.get('acceptable_only_if_all_unavailable') else "")
                + ")" for x in d["overruled"]))
        if d.get("review"):
            bits.append("needs review (DDInter: avoid unless necessary; every alternative is rejected, some only on unrated KG "
                        "evidence): " + "; ".join(f"{x['drug']} (e.g. {', '.join(x['alternatives_blocked_only_by_weak_evidence'][:3])})"
                                                  for x in d["review"]))
        if d.get("cumulative_harm_decisive"):
            bits.append("rejected only by one mitigation per harm: " + ", ".join(d["cumulative_harm_decisive"]))
        if d.get("cumulative_harm_decisive_review"):
            bits.append("one mitigation per harm turns 'review' into rejected: " + ", ".join(d["cumulative_harm_decisive_review"]))
        if d.get("cumulative_harm"):
            bits.append("one mitigation per harm: " + "; ".join(f"{x['drug']} — {x['harm']}: {x['objections']}"
                                                               for x in d["cumulative_harm"][:8])
                        + (" …" if len(d["cumulative_harm"]) > 8 else ""))
        if d["flips"]:
            bits.append("flips: " + "; ".join(f"{x['drug']} {x['without_necessity']}→{x['with_necessity']}" for x in d["flips"]))
        if d["kg_only_rejections"]:
            bits.append("KG-only rejections: " + "; ".join(f"{x['drug']} ({x['objections'][0]})" for x in d["kg_only_rejections"][:8])
                        + (" …" if len(d["kg_only_rejections"]) > 8 else ""))
        if d.get("weak_evidence_review"):
            bits.append("review, unrated KG evidence only: " + "; ".join(f"{x['drug']} ({x['objections'][0] if x['objections'] else 'necessity'})"
                                                                       for x in d["weak_evidence_review"][:8])
                        + (" …" if len(d["weak_evidence_review"]) > 8 else ""))
        if d.get("curated_indications"):
            bits.append("curated indications added: " + "; ".join(d["curated_indications"]))
        if d.get("excluded_drugs"):
            bits.append("excluded after review: " + "; ".join(f"{e['name']} ({e['reason']})" for e in d["excluded_drugs"]))
        if d.get("corroboration") and d["corroboration"]["dropped"]:
            bits.append("dropped (DrugBank indication text does not mention the disease): " + ", ".join(d["corroboration"]["dropped"][:15]))
        if d["unresolved_comeds"]:
            bits.append("unresolved co-medications: " + ", ".join(d["unresolved_comeds"]))
        if d.get("patient_disease_nodes") is not None:
            bits.append(f"patient disease nodes: {d['patient_disease_nodes']}")
        if bits:
            L += [f"### {qid}", ""] + [f"- {b}" for b in bits] + [""]
    return "\n".join(L) + "\n"
