"""DDInter (Xiong et al., NAR 2022; Tian et al., NAR 2025): interaction levels and management advice.

Bulk download: ddinter_downloads_code_<ATC letter>.csv with columns
DDInterID_A, Drug_A, DDInterID_B, Drug_B, Level   (Level: Major / Moderate / Minor / Unknown)
License: CC BY-NC-SA 4.0 (non-commercial; cite DDInter; do not redistribute fetched pages).

Management advice is not in the bulk files. It is on the checker result page
    https://ddinter2.scbdd.com/checker/result/<DDInterID_A>-<DDInterID_B>/
which `fetch_management` reads for the pairs a run needs (polite: one request per second, cached
in the index together with the raw HTML, so the parse can be re-run offline).
"""
from __future__ import annotations

import csv
import glob
import html as htmllib
import os
import re
import sqlite3
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

SALTS = r"(sodium|potassium|calcium|magnesium|hydrochloride|hcl|hydrobromide|sulfate|sulphate|mesylate|maleate|" \
        r"tartrate|succinate|acetate|citrate|phosphate|besylate|fumarate|carbonate|cation|medoxomil|cilexetil|dihydrate|monohydrate)"
_SALT_RX = re.compile(rf"\s+{SALTS}\b", re.I)
SYNONYMS = {"acetylsalicylic acid": "aspirin", "paracetamol": "acetaminophen", "lithium": "lithium"}
LEVELS = {"major": "major", "moderate": "moderate", "minor": "minor"}
RESULT_URL = "https://ddinter2.scbdd.com/checker/result/{a}-{b}/"


def norm(name: str) -> str:
    n = re.sub(r"\s+", " ", (name or "").strip().lower())
    n = SYNONYMS.get(n, n)
    n = _SALT_RX.sub("", n).strip()
    return SYNONYMS.get(n, n)


# ---------------------------------------------------------------- management text -> mitigation
_AVOID = re.compile(r"\b(contraindicated|should (\w+ )?not be (used|given|coadministered|co-administered|combined|administered)|"
                    r"must not|(is|are) (generally )?not recommended|should (\w+ )?be avoided|(is|are) (best|preferably) avoided|"
                    r"avoid (the )?(concomitant|combination|coadministration|co-administration|use))", re.I)
_SOFT = re.compile(r"\b(should (\w+ )?be (used|administered|given|prescribed) .{0,80}?only if|only if (the )?(potential |expected )?"
                   r"benefits? (outweighs?|justif\w*|exceeds?))|\b(preferably|generally|ideally|whenever possible|if possible)\b"
                   r"(?=[^.]{0,40}\bavoid)", re.I)
_CONDITIONAL = re.compile(r"\b(if (the )?(combination|coadministration|co-administration|concomitant use|these agents|"
                          r"both|they|it)\b|if (\w+ ){0,4}(is|are) (used|necessary|required|coadministered|prescribed|given)|"
                          r"when (\w+ ){0,4}(is|are) (used|coadministered|prescribed) together|unless|only if)", re.I)
_DOSE = re.compile(r"\b(dose|dosage)s? (adjustment|reduction|modification|titration)|"
                   r"(adjust|reduc|lower|decreas|modif|titrat)\w* (the )?(dose|dosage)|"
                   r"(dose|dosage)s?\b[^.;]{0,40}?\b(may|should|might|must|will)( need to)? be (adjusted|reduced|lowered|decreased|modified|titrated)|"
                   r"(dose|dosage)s? (adjusted|reduced|lowered|decreased|modified|titrated)\b|"
                   r"(empiric |empirical )?(dose |dosage )?reductions? (of|in) (the )?(both drugs|dose|dosage|\w+ dos)", re.I)
_TIMING = re.compile(r"\b(separat\w+ (the )?(administration|doses|dosing|times)|"
                     r"(administer|give|take)\w* .{0,60}?\b\d+\s*(to\s*\d+\s*)?hours? (before|after|apart))", re.I)
_MONITOR = re.compile(r"\b(monitor\w*|observ\w+ (closely|for)|check\w* (the )?(inr|levels?|serum|blood)|"
                      r"close (clinical )?(monitoring|observation|surveillance)|laboratory (evidence|testing))", re.I)


def management_profile(text: str) -> dict:
    """Read DDInter management advice.

    mitigation: the action that answers the interaction (dose > timing > monitor), or None.
    avoid_preferred: the advice prefers not to combine the drugs but allows it with that action
    ("should preferably be avoided ... if used together, monitor"; "only if benefit outweighs risk").
    Such a mitigation holds only when no acceptable alternative exists (af.build adds that attack).
    An unconditional avoid gives mitigation None."""
    t = " ".join((text or "").split())
    if not t:
        return {"mitigation": None, "avoid_preferred": False, "reason": "no management text"}
    avoid, soft, cond = _AVOID.search(t), _SOFT.search(t), _CONDITIONAL.search(t)
    if avoid and not cond and not soft:
        return {"mitigation": None, "avoid_preferred": False, "reason": f"avoid: '{avoid.group(0)}'"}
    for key, rx in (("dose", _DOSE), ("timing", _TIMING), ("monitor", _MONITOR)):
        m = rx.search(t)
        if m:
            pref = bool(avoid or soft)
            hedge = (avoid or soft).group(0) if pref else ""
            return {"mitigation": key, "avoid_preferred": pref,
                    "reason": f"{key}: '{m.group(0)}'" + (f"; avoid if an alternative exists: '{hedge}'" if pref else "")}
    if avoid or soft:
        return {"mitigation": None, "avoid_preferred": False, "reason": f"avoid: '{(avoid or soft).group(0)}'"}
    return {"mitigation": None, "avoid_preferred": False, "reason": "no actionable advice recognised"}


def classify_management(text: str) -> Tuple[Optional[str], str]:
    p = management_profile(text)
    return p["mitigation"], p["reason"]


def _text(html: str) -> str:
    h = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", html)
    h = re.sub(r"(?i)<br\s*/?>|</(p|div|li|tr|td|th|h\d|section|table)>", "\n", h)
    h = re.sub(r"(?s)<[^>]+>", " ", h)
    h = htmllib.unescape(h)
    return "\n".join(" ".join(line.split()) for line in h.splitlines() if line.strip())


def parse_result_page(html: str) -> List[dict]:
    """Extract every (severity, drug names, interaction, management) block from a checker result page."""
    txt = _text(html)
    blocks = []
    for m in re.finditer(r"(?s)(Major|Moderate|Minor|Unknown)\s*\n(.{1,200}?)\n(?:See more details\s*\n)?"
                         r"Interaction:\s*(.*?)\n\s*Management:\s*(.*?)(?=\n(?:Major|Moderate|Minor|Unknown)\s*\n|\n[A-Z][^\n]{0,40}\(\d+\)|\Z)",
                         txt):
        mgmt = re.split(r"\n(?:Interactions with|Drug-(?:disease|food)|Graph results)", m.group(4))[0]
        blocks.append({"level": m.group(1).lower(), "drugs": m.group(2).strip(),
                       "interaction": " ".join(m.group(3).split()), "management": " ".join(mgmt.split())})
    if not blocks:  # fall back to the first Interaction/Management labels anywhere on the page
        i = re.search(r"(?s)Interaction:\s*(.*?)\n\s*Management:\s*(.*?)(?:\n\n|\Z)", txt)
        if i:
            blocks.append({"level": "", "drugs": "", "interaction": " ".join(i.group(1).split()),
                           "management": " ".join(i.group(2).split()[:400])})
    return blocks


# ---------------------------------------------------------------- index
def build_index(paths: Iterable[str], out: str) -> dict:
    files: List[str] = []
    for p in paths:
        files += sorted(glob.glob(os.path.join(p, "ddinter_downloads_code_*.csv"))) if os.path.isdir(p) else [p]
    if not files:
        raise SystemExit("no DDInter files found (expected ddinter_downloads_code_*.csv)")
    keep_mgmt = []
    if Path(out).exists():  # keep previously fetched management pages across rebuilds
        try:
            old = sqlite3.connect(out)
            keep_mgmt = old.execute("SELECT * FROM mgmt").fetchall()
            old.close()
        except sqlite3.Error:
            pass
        Path(out).unlink()
    db = sqlite3.connect(out)
    db.executescript("CREATE TABLE ddi(a TEXT, b TEXT, level TEXT, PRIMARY KEY(a, b));"
                     "CREATE TABLE names(n TEXT PRIMARY KEY, raw TEXT, ddid TEXT);" + MGMT_SCHEMA)
    rank = {"unknown": 0, "minor": 1, "moderate": 2, "major": 3}
    best: Dict[Tuple[str, str], str] = {}
    names: Dict[str, Tuple[str, str]] = {}
    levels: Dict[str, int] = {}
    for f in files:
        with open(f, newline="", encoding="utf-8-sig") as fh:
            r = csv.DictReader(fh)
            need = {"Drug_A", "Drug_B", "Level"}
            if not need <= set(r.fieldnames or []):
                raise SystemExit(f"{f}: expected columns {sorted(need)}, found {r.fieldnames}")
            for row in r:
                a, b = norm(row["Drug_A"]), norm(row["Drug_B"])
                lv = (row["Level"] or "unknown").strip().lower()
                levels[lv] = levels.get(lv, 0) + 1
                names[a] = (row["Drug_A"], row.get("DDInterID_A", ""))
                names[b] = (row["Drug_B"], row.get("DDInterID_B", ""))
                k = tuple(sorted((a, b)))
                if rank.get(lv, 0) >= rank.get(best.get(k, "unknown"), 0):  # keep the most severe record per pair
                    best[k] = lv
    db.executemany("INSERT INTO ddi VALUES (?,?,?)", [(a, b, lv) for (a, b), lv in best.items()])
    db.executemany("INSERT INTO names VALUES (?,?,?)", [(n, raw, i) for n, (raw, i) in names.items()])
    if keep_mgmt:
        db.executemany(f"INSERT OR REPLACE INTO mgmt VALUES ({','.join('?' * len(keep_mgmt[0]))})", keep_mgmt)
    db.commit(); db.close()
    return {"files": [os.path.basename(f) for f in files], "pairs": len(best), "drugs": len(names),
            "rows_by_level": levels, "management_pages_kept": len(keep_mgmt)}


MGMT_SCHEMA = ("CREATE TABLE IF NOT EXISTS mgmt(a TEXT, b TEXT, url TEXT, status INTEGER, html TEXT, level TEXT, "
               "interaction TEXT, management TEXT, fetched REAL, PRIMARY KEY(a, b));")


class DDInter:
    def __init__(self, path: str) -> None:
        if not Path(path).exists():
            raise SystemExit(f"{path} not found; build it with: drugarg ddinter-index <folder with ddinter_downloads_code_*.csv>")
        self.db = sqlite3.connect(path)
        self.db.executescript(MGMT_SCHEMA)
        self.path = path
        cols = [r[1] for r in self.db.execute("PRAGMA table_info(names)")]
        self.has_ids = "ddid" in cols

    def known(self, name: str) -> bool:
        return self.db.execute("SELECT 1 FROM names WHERE n=?", (norm(name),)).fetchone() is not None

    def ddid(self, name: str) -> Optional[str]:
        if not self.has_ids:
            return None
        row = self.db.execute("SELECT ddid FROM names WHERE n=?", (norm(name),)).fetchone()
        return row[0] if row and row[0] else None

    def level(self, name_a: str, name_b: str) -> Optional[str]:
        a, b = sorted((norm(name_a), norm(name_b)))
        row = self.db.execute("SELECT level FROM ddi WHERE a=? AND b=?", (a, b)).fetchone()
        return row[0] if row else None

    # -------------------------------------------------- management pages
    def _key(self, ida: str, idb: str) -> Tuple[str, str]:
        return tuple(sorted((ida, idb), key=lambda s: int(re.sub(r"\D", "", s) or 0)))  # type: ignore[return-value]

    def management(self, ida: str, idb: str) -> Optional[dict]:
        a, b = self._key(ida, idb)
        row = self.db.execute("SELECT url, status, level, interaction, management FROM mgmt WHERE a=? AND b=?", (a, b)).fetchone()
        if not row:
            return None
        return {"url": row[0], "status": row[1], "level": row[2], "interaction": row[3], "management": row[4]}

    def fetch_management(self, pairs: List[Tuple[str, str]], delay: float = 1.0, timeout: float = 30.0,
                         refresh: bool = False, log=print) -> dict:
        """Fetch checker result pages for (DDInterID, DDInterID) pairs not yet cached."""
        import requests
        s = requests.Session()
        s.headers.update({"User-Agent": "drugarg/0.5 research prototype (cached, 1 request/s)"})
        stats = {"cached": 0, "fetched": 0, "failed": 0, "no_text": 0}
        for ida, idb in pairs:
            a, b = self._key(ida, idb)
            if not refresh and self.management(a, b) and self.management(a, b)["status"] == 200:
                stats["cached"] += 1
                continue
            url = RESULT_URL.format(a=b, b=a)  # the site orders the pair as it likes; both orders work
            try:
                r = s.get(url, timeout=timeout)
                status, html = r.status_code, r.text
            except Exception as e:
                log(f"  {a}-{b}: request failed ({e})")
                stats["failed"] += 1
                time.sleep(delay)
                continue
            blocks = parse_result_page(html) if status == 200 else []
            blk = blocks[0] if blocks else {"level": "", "interaction": "", "management": ""}
            if status == 200 and not blk["management"]:
                stats["no_text"] += 1
            self.db.execute("INSERT OR REPLACE INTO mgmt VALUES (?,?,?,?,?,?,?,?,?)",
                            (a, b, url, status, html, blk["level"], blk["interaction"], blk["management"], time.time()))
            self.db.commit()
            stats["fetched" if status == 200 else "failed"] += 1
            log(f"  {a}-{b}: {status} {blk['level'] or '-'} | {blk['management'][:90]}")
            time.sleep(delay)
        return stats

    def reparse(self) -> int:
        """Re-run the parser over cached HTML (after a parser fix), without network."""
        n = 0
        for a, b, html in self.db.execute("SELECT a, b, html FROM mgmt WHERE status=200").fetchall():
            blocks = parse_result_page(html or "")
            blk = blocks[0] if blocks else {"level": "", "interaction": "", "management": ""}
            self.db.execute("UPDATE mgmt SET level=?, interaction=?, management=? WHERE a=? AND b=?",
                            (blk["level"], blk["interaction"], blk["management"], a, b))
            n += 1
        self.db.commit()
        return n

    # -------------------------------------------------- run integration
    def annotate(self, sg, fetch: bool = False, delay: float = 1.0, log=print) -> dict:
        """Attach DDInter levels (and cached/fetched management advice) to every candidate x co-medication pair."""
        names = {i: d["name"] for i, d in sg.drugs.items()}
        involved = [c["id"] for c in sg.candidates] + list(sg.comeds)
        matched = {i for i in involved if self.known(names.get(i, i))}
        sg.ddinter_known = sorted(matched)
        sg.ddinter, sg.ddinter_mgmt = {}, {}
        want: List[Tuple[str, str]] = []
        for c in sg.candidates:
            for m in sg.comeds:
                if c["id"] == m:
                    continue
                lv = self.level(names.get(c["id"], c["id"]), names.get(m, m))
                if not lv:
                    continue
                sg.ddinter[f"{c['id']}|{m}"] = lv
                ia, ib = self.ddid(names.get(c["id"], "")), self.ddid(names.get(m, ""))
                if ia and ib and lv in ("major", "moderate"):  # minor pairs never become objections
                    want.append((ia, ib))
        fetched = None
        if fetch and not self.has_ids:
            log("DDInter: this index has no DDInter IDs, cannot fetch management advice; rebuild it with ddinter-index")
        if fetch and want:
            log(f"DDInter: fetching management advice for {len(want)} pair(s) (cached pages are reused)")
            fetched = self.fetch_management(want, delay=delay, log=log)
        n_mgmt = 0
        for c in sg.candidates:
            for m in sg.comeds:
                k = f"{c['id']}|{m}"
                if k not in sg.ddinter:
                    continue
                ia, ib = self.ddid(names.get(c["id"], "")), self.ddid(names.get(m, ""))
                info = self.management(ia, ib) if ia and ib else None
                if info and info["management"]:
                    prof = management_profile(info["management"])
                    sg.ddinter_mgmt[k] = dict(prof, management=info["management"], url=info["url"],
                                              interaction=info.get("interaction") or "")
                    n_mgmt += 1
        cov = {"ddinter": self.path, "drug_names_matched": f"{len(matched)}/{len(set(involved))}",
               "unmatched": sorted(names.get(i, i) for i in set(involved) - matched),
               "pairs_with_ddinter_level": len(sg.ddinter), "pairs_with_management": n_mgmt,
               "index_has_ids": self.has_ids, "fetch": fetched}
        sg.query["ddinter_coverage"] = cov
        return cov
