"""Query-driven, schema-guided subgraph extraction from Bio2RDF DrugBank.

Default vocabulary follows the Bio2RDF DrugBank namespaces (drugbank:, drugbank_vocabulary:,
drugbank_resource:). Releases differ in a few predicate names, so every predicate used here is
configurable (see Vocab) and `drugarg probe` prints what your endpoint actually uses.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

from .sparql import Endpoint

DB_NS = "http://bio2rdf.org/drugbank:"
DBID = re.compile(r"^DB\d{5}$", re.I)
SUFFIX = re.compile(r"\s*\[[^\]]*\]\s*$")  # Bio2RDF labels end with " [drugbank:DB00001]"
DDI_PREFIX = re.compile(r"^DDI between .+? and .+? - ", re.I)  # Release 3 titles: "DDI between A and B - <text>"


@dataclass
class Vocab:
    drug_class: str = "http://bio2rdf.org/drugbank_vocabulary:Drug"
    indication: str = "http://bio2rdf.org/drugbank_vocabulary:indication"
    category: str = "http://bio2rdf.org/drugbank_vocabulary:category"
    atc: str = "http://bio2rdf.org/drugbank_vocabulary:x-atc"
    group: str = "http://bio2rdf.org/drugbank_vocabulary:group"
    group_value_prefix: str = "http://bio2rdf.org/drugbank_vocabulary:"
    # property path; both spellings occur across Bio2RDF releases
    ddi_path: str = ("<http://bio2rdf.org/drugbank_vocabulary:ddi-interactor-in>|"
                     "<http://bio2rdf.org/drugbank_vocabulary:is-ddi-interactor-in>")
    title: str = "http://purl.org/dc/terms/title"
    description: str = "http://purl.org/dc/terms/description"
    label: str = "http://www.w3.org/2000/01/rdf-schema#label"

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> "Vocab":
        v = cls()
        for k, val in (d or {}).items():
            if hasattr(v, k):
                setattr(v, k, val)
        return v


def clean(s: str) -> str:
    return SUFFIX.sub("", s or "").strip()


def label_from_iri(s: str) -> str:
    """Bio2RDF R3 categories are bare IRIs such as drugbank_vocabulary:Analgesics,-Non-Narcotic."""
    if not s.startswith("http"):
        return s
    local = re.split(r"[:/#]", s)[-1]
    return local.replace(",-", ", ").replace("_", " ")


def dbid(uri_or_id: str) -> str:
    s = uri_or_id.rsplit(":", 1)[-1] if uri_or_id.startswith("http") else uri_or_id
    return s.upper()


def iri(db: str) -> str:
    return f"<{DB_NS}{db}>"


def lit(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


@dataclass
class Subgraph:
    query: dict
    drugs: Dict[str, dict] = field(default_factory=dict)          # id -> {name, categories[]}
    candidates: List[dict] = field(default_factory=list)          # {id, indication}
    comeds: List[str] = field(default_factory=list)               # resolved ids
    unresolved: List[str] = field(default_factory=list)           # comed names not found
    ddis: List[dict] = field(default_factory=list)                # {a, b, resource, text}
    kg_contra: List[dict] = field(default_factory=list)           # {drug, disease_id, disease} (PrimeKG)
    ddinter: Dict[str, str] = field(default_factory=dict)          # "cand|comed" -> DDInter level
    ddinter_mgmt: Dict[str, dict] = field(default_factory=dict)    # "cand|comed" -> management advice + mitigation
    ddinter_known: List[str] = field(default_factory=list)         # drug ids DDInter covers (for the ddinter-silent policy)

    def to_dict(self) -> dict:
        return asdict(self)


class Extractor:
    def __init__(self, ep: Endpoint, vocab: Optional[Vocab] = None, chunk: int = 40) -> None:
        self.ep, self.v, self.chunk = ep, vocab or Vocab(), chunk

    # -- queries ---------------------------------------------------------------
    def _gv(self, g: str) -> str:
        return f"<{self.v.group_value_prefix}{g.strip().capitalize()}>"

    def q_candidates(self, keywords: List[str], limit: int, require: List[str] = (), exclude: List[str] = ()) -> str:
        v = self.v
        conds = " || ".join(f"CONTAINS(LCASE(STR(?ind)), {lit(k.lower())})" for k in keywords)
        req = "".join(f"\n  FILTER EXISTS {{ ?drug <{v.group}> {self._gv(g)} }}" for g in require)
        exc = (f"\n  FILTER NOT EXISTS {{ ?drug <{v.group}> ?g . VALUES ?g {{ {' '.join(self._gv(g) for g in exclude)} }} }}"
               if exclude else "")
        return f"""SELECT DISTINCT ?drug ?title ?ind WHERE {{
  ?drug a <{v.drug_class}> ; <{v.indication}> ?i .
  OPTIONAL {{ ?i <{v.description}> ?d1 }}
  OPTIONAL {{ ?i <{v.label}> ?d2 }}
  BIND(COALESCE(?d1, ?d2, STR(?i)) AS ?ind)
  FILTER({conds}){req}{exc}
  OPTIONAL {{ ?drug <{v.title}> ?t1 }}
  OPTIONAL {{ ?drug <{v.label}> ?t2 }}
  BIND(COALESCE(?t1, ?t2, STR(?drug)) AS ?title)
}} LIMIT {int(limit)}"""

    def q_resolve(self, name: str) -> str:
        v, n = self.v, name.lower().strip()
        return f"""SELECT DISTINCT ?drug ?t WHERE {{
  ?drug a <{v.drug_class}> .
  {{ ?drug <{v.title}> ?t }} UNION {{ ?drug <{v.label}> ?t }}
  FILTER(LCASE(STR(?t)) = {lit(n)} || STRSTARTS(LCASE(STR(?t)), {lit(n + " [")}))
}} LIMIT 5"""

    def q_titles(self, ids: List[str]) -> str:
        v = self.v
        return f"""SELECT ?drug ?title WHERE {{
  VALUES ?drug {{ {' '.join(iri(i) for i in ids)} }}
  OPTIONAL {{ ?drug <{v.title}> ?t1 }}
  OPTIONAL {{ ?drug <{v.label}> ?t2 }}
  BIND(COALESCE(?t1, ?t2) AS ?title)
}}"""

    def q_ddis(self, cands: List[str], comeds: List[str]) -> str:
        v = self.v
        return f"""SELECT DISTINCT ?d ?m ?x ?text WHERE {{
  VALUES ?d {{ {' '.join(iri(i) for i in cands)} }}
  VALUES ?m {{ {' '.join(iri(i) for i in comeds)} }}
  ?d {v.ddi_path} ?x .
  ?m {v.ddi_path} ?x .
  FILTER(?d != ?m)
  OPTIONAL {{ ?x <{v.description}> ?a }}
  OPTIONAL {{ ?x <{v.title}> ?t }}
  OPTIONAL {{ ?x <{v.label}> ?b }}
  BIND(COALESCE(?a, ?t, ?b, "") AS ?text)
}}"""

    def q_categories(self, ids: List[str]) -> str:
        v = self.v
        return f"""SELECT DISTINCT ?drug ?cat WHERE {{
  VALUES ?drug {{ {' '.join(iri(i) for i in ids)} }}
  ?drug <{v.category}> ?c .
  OPTIONAL {{ ?c <{v.title}> ?a }}
  OPTIONAL {{ ?c <{v.label}> ?b }}
  BIND(COALESCE(?a, ?b, STR(?c)) AS ?cat)
}}"""

    def q_atc(self, ids: List[str]) -> str:
        return f"""SELECT DISTINCT ?drug ?atc WHERE {{
  VALUES ?drug {{ {' '.join(iri(i) for i in ids)} }}
  ?drug <{self.v.atc}> ?atc .
}}"""

    # -- pipeline --------------------------------------------------------------
    def resolve(self, names: List[str]) -> (List[str], List[str]):
        ids, missing = [], []
        for n in names:
            if DBID.match(n.strip()):
                ids.append(n.strip().upper())
                continue
            rows = self.ep.select(self.q_resolve(n), tag=f"resolve:{n}")
            if rows:
                ids.append(dbid(sorted(r["drug"] for r in rows)[0]))
            else:
                missing.append(n)
        return ids, missing

    def _chunks(self, xs: List[str]):
        for i in range(0, len(xs), self.chunk):
            yield xs[i:i + self.chunk]

    @staticmethod
    def relevance(text: str, keywords: List[str]) -> tuple:
        """Rank indications that lead with the disease ("For the treatment of rheumatoid arthritis")
        above texts that mention it in passing. Lower is better."""
        t = (text or "").lower()
        pos = [t.find(k.lower()) for k in keywords if k.lower() in t]
        first = min(pos) if pos else 10 ** 6
        hits = sum(t.count(k.lower()) for k in keywords)
        return (first // 40, -hits, len(t))

    def extract(self, disease_text: List[str], comed_names: List[str], max_candidates: int = 50,
                extra_candidates: Optional[List[str]] = None, require_groups: List[str] = ("approved",),
                exclude_groups: List[str] = ("withdrawn", "nutraceutical", "illicit"),
                exclude_text: List[str] = ()) -> Subgraph:
        require_groups = [g for g in require_groups if g.lower() != "none"]
        exclude_groups = [g for g in exclude_groups if g.lower() != "none"]
        sg = Subgraph(query={"disease_text": disease_text, "comedications": comed_names,
                             "max_candidates": max_candidates, "require_groups": list(require_groups),
                             "exclude_groups": list(exclude_groups)})
        rows = self.ep.select(self.q_candidates(disease_text, 5000, require_groups, exclude_groups), tag="candidates")
        if exclude_text:  # a match counts only if the keyword survives after removing excluded phrases
            rx = re.compile("|".join(re.escape(x) for x in exclude_text), re.I)
            rows = [r for r in rows if any(k.lower() in rx.sub(" ", r.get("ind", "")).lower() for k in disease_text)]
        sg.query["exclude_text"] = list(exclude_text)
        best: Dict[str, dict] = {}
        for r in rows:  # one row per (drug, indication); keep the most relevant indication text
            i = dbid(r["drug"])
            if i not in best or self.relevance(r.get("ind", ""), disease_text) < self.relevance(best[i].get("ind", ""), disease_text):
                best[i] = r
        rows = sorted(best.values(), key=lambda r: (self.relevance(r.get("ind", ""), disease_text), dbid(r["drug"])))
        sg.query["matching_drugs"] = len(rows)
        seen = {}
        for r in rows:
            i = dbid(r["drug"])
            if i not in seen:
                seen[i] = {"id": i, "indication": clean(r.get("ind", ""))[:400]}
                sg.drugs[i] = {"name": clean(r.get("title", i)), "categories": []}
            if len(seen) >= max_candidates:
                break
        sg.candidates = list(seen.values())
        for e in extra_candidates or []:
            if e not in seen:
                sg.candidates.append({"id": e, "indication": "added explicitly"})
                sg.drugs.setdefault(e, {"name": e, "categories": []})

        sg.comeds, sg.unresolved = self.resolve(comed_names)
        need = [i for i in sg.comeds + [c["id"] for c in sg.candidates] if sg.drugs.get(i, {}).get("name", i) == i]
        for ch in self._chunks(need):
            for r in self.ep.select(self.q_titles(ch), tag="titles"):
                if r.get("title"):
                    sg.drugs.setdefault(dbid(r["drug"]), {"categories": []})["name"] = clean(r["title"])
        for i in sg.comeds:
            sg.drugs.setdefault(i, {"name": i, "categories": []})

        all_ids = list(sg.drugs)
        for ch in self._chunks(all_ids):
            for r in self.ep.select(self.q_categories(ch), tag="categories"):
                d = sg.drugs.get(dbid(r["drug"]))
                cat = label_from_iri(clean(r.get("cat", "")))
                if d is not None and cat and cat not in d["categories"]:
                    d["categories"].append(cat)
            try:
                for r in self.ep.select(self.q_atc(ch), tag="atc"):
                    d = sg.drugs.get(dbid(r["drug"]))
                    code = "ATC " + re.split(r"[:/#]", r["atc"])[-1].upper()
                    if d is not None and code not in d["categories"]:
                        d["categories"].append(code)
            except RuntimeError:
                pass  # ATC links are optional

        cand_ids = [c["id"] for c in sg.candidates]
        if sg.comeds:
            seen_pairs = set()
            for ch in self._chunks(cand_ids):
                for r in self.ep.select(self.q_ddis(ch, sg.comeds), tag="ddis"):
                    a, b = dbid(r["d"]), dbid(r["m"])
                    if (a, b) in seen_pairs:
                        continue
                    seen_pairs.add((a, b))
                    sg.ddis.append({"a": a, "b": b, "resource": r.get("x", ""), "text": DDI_PREFIX.sub("", clean(r.get("text", "")))})
        return sg

    def probe(self, drug: str = "DB01050") -> dict:
        """Report the predicates the endpoint uses for one drug, its indication resource,
        one complete DDI resource, and its categories."""
        v = self.v
        q1 = f"SELECT ?p (COUNT(*) AS ?n) (SAMPLE(?o) AS ?example) WHERE {{ {iri(drug)} ?p ?o }} GROUP BY ?p"
        q2 = f"SELECT ?x WHERE {{ {iri(drug)} {v.ddi_path} ?x }} ORDER BY ?x LIMIT 1"
        q3 = f"SELECT ?i ?p ?o WHERE {{ {iri(drug)} <{v.indication}> ?i . ?i ?p ?o }} LIMIT 25"
        q4 = f"SELECT ?c ?p ?o WHERE {{ {iri(drug)} <{v.category}> ?c . OPTIONAL {{ ?c ?p ?o }} }} LIMIT 25"
        x = self.ep.select(q2, "probe:ddi-pick")
        ddi = []
        if x:
            ddi = self.ep.select(f"SELECT ?x ?p ?o WHERE {{ BIND(<{x[0]['x']}> AS ?x) ?x ?p ?o }} LIMIT 40", "probe:ddi")
        return {"drug_predicates": self.ep.select(q1, "probe:drug"),
                "indication_resource": self.ep.select(q3, "probe:indication"),
                "ddi_resource": ddi,
                "categories": self.ep.select(q4, "probe:category")}


def apply_exclusions(sg: Subgraph, items) -> List[dict]:
    """Drop reviewed indication errors from the candidates. items: names/ids or {"name": ..., "reason": ...}."""
    norm = [i if isinstance(i, dict) else {"name": str(i), "reason": ""} for i in (items or [])]
    keys = {e["name"].strip().lower(): e for e in norm}
    done = []
    keep = []
    for c in sg.candidates:
        nm = sg.drugs.get(c["id"], {}).get("name", "").lower()
        e = keys.get(nm) or keys.get(c["id"].lower())
        if e:
            done.append({"name": sg.drugs.get(c["id"], {}).get("name", c["id"]), "id": c["id"], "reason": e.get("reason", "")})
        else:
            keep.append(c)
    sg.candidates = keep
    sg.query["excluded_drugs"] = done
    return done
