"""DrugArg: query-driven argumentation over Bio2RDF DrugBank."""
__version__ = "0.9.4"
