"""Outputs: argument graph JSON, answers JSON, DOT, extracted triples (Turtle), a readable report,
and a dataset JSON that the DrugArg demo page can load directly ("Load dataset")."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

from .af import Framework, Result, describe
from .extract import Subgraph
from .rules import Rules


def arggraph_json(F: Framework, R: Result) -> dict:
    return {
        "arguments": [dict(vars(a), grounded=R.lab.get(a.id), status=R.status.get(a.id)) for a in F.args.values()],
        "attacks": F.attacks, "supports": F.supports,
        "preferred_extensions": R.preferred,
    }


def answers_json(F: Framework, R: Result, base: Dict[str, str], expl: List[dict], ctx, sg: Subgraph) -> dict:
    by = lambda s: [e["name"] for e in expl if e["status"] == s]
    return {
        "query": sg.query, "context": vars(ctx),
        "accepted": by("accepted"), "alternatives": by("alternative"), "rejected": by("rejected"), "review": by("review"),
        "filter_rejected": [F.args[u].label for u, v in base.items() if v == "rejected"],
        "already_taking": F.taking, "matching_drugs": sg.query.get("matching_drugs"), "unresolved_comedications": sg.unresolved,
        "explanations": expl,
    }


def dot(F: Framework, R: Result) -> str:
    col = {"accepted": "#17694b", "alternative": "#9a5300", "rejected": "#c8371e", "review": "#6b4fa0"}
    L = ["digraph AF {", "  rankdir=LR; node [shape=box, style=\"rounded,filled\", fontname=Helvetica, fontsize=10];"]
    for a in F.args.values():
        if a.t == "USE":
            c = col[R.status.get(a.id, "rejected")]
            L.append(f'  "{a.id}" [label="{a.label}", color="{c}", fillcolor="white", penwidth=2];')
        elif a.t == "IND":
            L.append(f'  "{a.id}" [label="indicated", color="#bbbbbb", fillcolor="white", fontcolor="#777777"];')
        else:
            fill = "#e6ebfb" if a.t in ("MIT", "ALT") else ("#fbe3dd" if R.lab.get(a.id) == "in" else "white")
            lab = (f"{a.kind} CI\\n{a.label}" if a.t == "CI" else f"{a.sev} DDI\\n{a.label}" if a.t == "DDI" else
                   f"{a.label}\\navailable" if a.t == "ALT" else f"cumulative\\n{a.label}" if a.t == "CUM" else a.label)
            L.append(f'  "{a.id}" [label="{lab}", fillcolor="{fill}"];')
    for s, t in F.attacks:
        style = "dashed" if R.lab.get(s) == "out" else "solid"
        L.append(f'  "{s}" -> "{t}" [style={style}, color="#c8371e"];')
    for s, t in F.supports:
        L.append(f'  "{s}" -> "{t}" [style=dotted, color="#999999", arrowhead=empty];')
    L.append("}")
    return "\n".join(L)


def turtle(sg: Subgraph) -> str:
    esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
    L = ["@prefix drugbank: <http://bio2rdf.org/drugbank:> .",
         "@prefix dbv: <http://bio2rdf.org/drugbank_vocabulary:> .",
         "@prefix dct: <http://purl.org/dc/terms/> .",
         "@prefix ex: <http://example.org/drugarg/> .", ""]
    for i, d in sg.drugs.items():
        L.append(f'drugbank:{i} dct:title "{esc(d["name"])}" .')
        for c in d["categories"]:
            L.append(f'drugbank:{i} ex:categoryLabel "{esc(c)}" .')
    for c in sg.candidates:
        L.append(f'drugbank:{c["id"]} ex:indicationText "{esc(c["indication"])}" .')
    for k in getattr(sg, "kg_contra", []):
        L.append(f'drugbank:{k["drug"]} ex:contraindicatedIn ex:disease_{k["disease_id"]} . '
                 f'ex:disease_{k["disease_id"]} dct:title "{esc(k["disease"])}" .')
    for x in sg.ddis:
        r = f"<{x['resource']}>" if x["resource"].startswith("http") else f"ex:ddi_{x['a']}_{x['b']}"
        L += [f"drugbank:{x['a']} dbv:ddi-interactor-in {r} .",
              f"drugbank:{x['b']} dbv:ddi-interactor-in {r} .",
              f'{r} dct:description "{esc(x["text"])}" .']
    return "\n".join(L) + "\n"


def demo_dataset(sg: Subgraph, F: Framework, rules: Rules, disease_key: str = "query") -> dict:
    """Dataset in the DrugArg demo page format; DDIs are pair-specific with severities already classified."""
    drugs = [[i, d["name"], (d["categories"][0] if d["categories"] else ""), F.groups.get(i, "")]
             for i, d in sg.drugs.items()]
    contra = []
    for r in rules.d.get("contraindications", []):
        sel = r["drugs"]
        targets = [sel] if not sel.startswith("cat:") else \
            [i for i, d in sg.drugs.items() if rules.match(sel, i, F.groups.get(i, ""), d["categories"])]
        contra += [[t, r["condition"], r["kind"], r.get("note", ""), r.get("mitigation")] for t in targets]
    conditions = [[k, v] for k, v in rules.conditions.items()]
    for k in getattr(sg, "kg_contra", []):
        key = f"kg_{k['disease_id']}"
        if key not in [c[0] for c in conditions]:
            conditions.append([key, k["disease"]])
        pol = rules.kg_contra_policy(k["drug"], F.groups.get(k["drug"], ""), sg.drugs[k["drug"]]["categories"], k["disease"])
        contra.append([k["drug"], key, pol["kind"], pol["note"] or "KG contraindication", pol.get("mitigation")])
    ddi = []
    for c in sg.candidates:
        for m in sg.comeds:
            if m == c["id"]:
                continue
            x = next((x for x in sg.ddis if x["a"] == c["id"] and x["b"] == m), None)
            info = rules.classify_ddi({"id": c["id"], "group": F.groups.get(c["id"], ""), "categories": sg.drugs[c["id"]]["categories"]},
                                      {"id": m, "group": F.groups.get(m, ""), "categories": sg.drugs.get(m, {}).get("categories", [])},
                                      x["text"] if x else "")
            if x or info["source"] == "curated":
                ddi.append([c["id"], m, info["severity"], (info["effect"] or "")[:160], info.get("mitigation")])
    return {
        "drugs": drugs,
        "diseases": {disease_key: {"name": " / ".join(sg.query["disease_text"]).title(),
                                   "cands": [[c["id"], c["indication"][:200]] for c in sg.candidates]}},
        "conditions": conditions,
        "comeds": sg.comeds,
        "contra": contra, "ddi": ddi,
        "mitigations": {k: v.split(" (")[0] for k, v in rules.mitigations.items()},
    }


def report(expl: List[dict], answers: dict, stats: dict) -> str:
    L = [f"# DrugArg report: {', '.join(answers['query']['disease_text'])}", "",
         f"drugarg {stats.get('drugarg_version', '?')} · {stats.get('endpoint', '')}", "",
         f"Co-medications: {', '.join(answers['query']['comedications']) or 'none'}; "
         f"conditions: {', '.join(answers['context']['conditions'] + answers['query'].get('patient_diseases', [])) or 'none'}.", "",
         f"{answers.get('matching_drugs')} drugs pass the approval filters and match the disease "
         f"({'indication edges' if answers['query'].get('backend') == 'PrimeKG' else 'indication text'}); "
         f"the {len(expl)} most relevant are candidates.", "",
         *([f"Disease nodes matched ({len(answers['query']['matched_disease_nodes'])}): "
            + "; ".join(answers['query']['matched_disease_nodes'][:25])
            + (" …" if len(answers['query']['matched_disease_nodes']) > 25 else ""), ""]
           if answers['query'].get('matched_disease_nodes') else []),
         *([f"Patient condition nodes: " + "; ".join(f"{k} → {', '.join(v) or 'NONE'}" for k, v in answers['query']['patient_disease_nodes'].items()), ""]
           if answers['query'].get('patient_disease_nodes') else []),
         *([f"Co-medications resolved: " + "; ".join(f"{k} → {v}" for k, v in answers['query']['comedication_resolution'].items()), ""]
           if answers['query'].get('comedication_resolution') else []),
         *([f"DDInter: drug names matched {answers['query']['ddinter_coverage']['drug_names_matched']}, "
            f"pairs with a DDInter level {answers['query']['ddinter_coverage']['pairs_with_ddinter_level']}, "
            f"with management advice {answers['query']['ddinter_coverage'].get('pairs_with_management', 0)}"
            + (f"; unmatched: {', '.join(answers['query']['ddinter_coverage']['unmatched'][:15])}" if answers['query']['ddinter_coverage']['unmatched'] else ""), ""]
           if answers['query'].get('ddinter_coverage') else []),
         f"Interactions without severity or management text: {answers['context'].get('untyped_ddi', 'lenient')} policy.", "",
         *([f"Curated indications added (not in PrimeKG): " + "; ".join(answers['query']['curated_indications']), ""]
           if answers['query'].get('curated_indications') else []),
         *([f"Excluded candidates (reviewed indication errors): " + "; ".join(f"{e['name']} ({e.get('reason') or 'no reason given'})" for e in answers['query']['excluded_drugs']), ""]
           if answers['query'].get('excluded_drugs') else []),
         f"Objections by source: " + (", ".join(f"{k} {v}" for k, v in stats.get("objection_sources", {}).items()) or "none") + ".", "",
         f"Accepted {len(answers['accepted'])} · pick one {len(answers['alternatives'])} · "
         f"rejected {len(answers['rejected'])} · needs review {len(answers.get('review', []))} · rule filter rejects {len(answers['filter_rejected'])}.", "",
         "| Drug | Argumentation | Filter | Why |", "|---|---|---|---|"]
    for e in expl:
        why = []
        if e["effective_objections"]:
            why.append("defeated by " + "; ".join(e["effective_objections"]))
        for a in e["answered_objections"]:
            why.append(f"answered: {a['objection']} → {', '.join(a['answered_by'])}")
        if e["competes_with"]:
            peers = [e["name"]] + e["competes_with"]
            why.append("choose one of: " + (", ".join(peers) if len(peers) <= 6 else f"{len(peers)} same-class options ({e.get('group')})"))
        if e["counterfactual"]:
            why.append("would stand without: " + " and ".join(e["counterfactual"]))
        for o in e.get("overruled_mitigations", []):
            why.append(f"mitigation overruled: {o['mitigation']} is advised only when the combination cannot be avoided; "
                       + (f"{o['n_alternatives']} alternative(s) accepted, e.g. {', '.join(o['because_accepted'][:4])}"
                          if o['n_alternatives'] else
                          "no alternative is acceptable, but " + ", ".join(o.get('blocked_only_by_weak_evidence', [])[:4])
                          + " are rejected only on unrated KG evidence"))
            cf = o.get("counterfactual")
            if cf and o['n_alternatives']:
                why.append(("would be acceptable" if cf["status"] not in ("rejected",) else "the mitigation would hold (drug still rejected for other reasons)")
                           + f" only if all {len(cf['unavailable'])} of these (of {cf.get('of_alternatives', '?')} alternatives) were unavailable: "
                           + ", ".join(cf['unavailable'][:8]) + (" …" if len(cf['unavailable']) > 8 else ""))
        if e["status"] == "review":
            r = e.get("review_reason", "necessity")
            if "weak evidence" in r:
                why.append("NEEDS REVIEW: every objection that stands is an unrated KG edge (no DDInter severity, no "
                           "published advice, no curated rule); check those edges before deciding")
            if "necessity" in r:
                why.append("NEEDS REVIEW: the objection stands only because the alternatives are blocked by unrated KG edges; "
                           "check those edges before deciding")
        if e.get("notes"):
            why.append("note: " + "; ".join(e["notes"]))
        if e["ignored_below_threshold"]:
            why.append("ignored: " + "; ".join(e["ignored_below_threshold"]))
        mark = " ≠" if e["differs_from_filter"] else ""
        grp = f", {e['group']}" if e.get("group") else ""
        ind = e.get("indication", "").replace("PrimeKG ", "")
        L.append(f"| {e['name']} ({e['drug']}{grp})<br><small>{ind[:120]}</small> | {e['status']}{mark} | {e['filter']} | {'<br>'.join(why) or 'no objection'} |")
    L += ["", "## Run statistics", "", "```", json.dumps(stats, indent=1), "```"]
    return "\n".join(L) + "\n"


def write_all(out: Path, files: Dict[str, object]) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for name, content in files.items():
        p = out / name
        p.write_text(content if isinstance(content, str) else json.dumps(content, indent=1, ensure_ascii=False), encoding="utf-8")
