"""Argumentation-framework construction and semantics.

Arguments: USE (candidate treatment), IND (indication evidence, support only), CI (condition
contraindication), DDI (interaction with a co-medication), MIT (an available mitigation).
Attacks: CI/DDI -> USE; MIT -> relative CI or non-major DDI; USE <-> USE for therapeutic
duplication (same group). Supports IND -> USE are reported but are not part of the Dung AF.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from itertools import combinations
from typing import Dict, List, Optional, Set, Tuple

import re

from .rules import SEV, Rules
from .extract import Subgraph


# Objections asserted by the KG with no severity, published advice or curated rule behind them.
WEAK = {"KG", "KG (severity unknown)"}

# Adverse outcomes recognised in condition labels, KG effect text and DDInter interaction/management text.
LEGACY_HARMS = {"hyperkalaemia": r"hyperkal|potassium"}   # 0.9.3 tag, kept for --legacy-harm-tags

HARMS = {
    "bleeding": r"bleed|h(a)?emorrhag|anticoagulant effect|antiplatelet|ulcer|\binr\b|prothrombin time",
    "QT prolongation": r"\bqt\b|qtc|torsade",
    # 0.9.4: "potassium" alone also matched potassium LOSS (e.g. loop diuretic + digoxin); the direction is now explicit
    "hyperkalaemia": r"hyperkal|(increas|rais|elevat|retain)\w* (the )?(serum |blood |plasma )?potassium|potassium[- ]sparing|potassium (retention|supplement)",
    "hypokalaemia": r"hypokal|(decreas|lower|reduc|deplet)\w* (the )?(serum |blood |plasma )?potassium|potassium (loss|depletion|wasting)",
    "serotonin toxicity": r"serotonin syndrome|serotonergic|serotonin toxicity",
    "renal injury": r"renal (failure|impairment|injury|toxicity|insufficiency|dysfunction)|nephrotox|kidney (injury|failure|disease)|deteriorat\w* (of )?renal function|\begfr\b",
    "CNS/respiratory depression": r"respiratory depression|cns depress|sedation",
    "myelosuppression": r"myelosuppress|bone marrow|neutropen|leukopen|pancytopen|agranulocyt",
}


_ACTIVE = dict(HARMS)


def use_legacy_harm_tags(on: bool) -> None:
    """Reproduce the 0.9.3 harm tags (one undirected potassium tag)."""
    _ACTIVE.clear()
    _ACTIVE.update({k: v for k, v in HARMS.items() if k != "hypokalaemia"} if on else HARMS)
    if on:
        _ACTIVE.update(LEGACY_HARMS)


def harms_of(*texts: str) -> List[str]:
    t = " ".join(x for x in texts if x).lower()
    return [h for h, rx in _ACTIVE.items() if re.search(rx, t)]


@dataclass
class Context:
    conditions: List[str] = field(default_factory=list)
    threshold: str = "moderate"              # minimum DDI severity that becomes an attack
    mitigations: Dict[str, bool] = field(default_factory=lambda: {"monitor": True, "ppi": False, "dose": True, "timing": True})
    duplication: bool = True
    untyped_ddi: str = "lenient"             # lenient: moderate + monitorable; strict: moderate, no mitigation; ignore
    use_management: bool = True              # DDInter management advice decides mitigability when available
    management_mitigates_major: bool = False # let published advice mitigate a major interaction too
    necessity: bool = True                   # "avoid unless necessary" mitigations are overruled by an acceptable alternative
    same_harm: bool = True                   # two objections for the same harm, one of them mitigated, reject the drug
    weak_review: bool = False                # 0.9.4 (CLI default on): a rejection resting only on unrated KG edges becomes 'review'
    alt_scope: str = "node"                  # 0.9.4 CLI default "query": alternatives = any candidate of the query; "node" = share a disease node (0.9.3)


@dataclass
class Arg:
    id: str
    t: str
    drug: str
    label: str
    detail: str = ""
    kind: str = ""        # CI: absolute|relative
    sev: str = ""         # DDI severity
    source: str = ""      # DDI: curated|text-heuristic|default
    with_: str = ""       # DDI partner name
    key: str = ""         # MIT key
    harms: List[str] = field(default_factory=list)   # CI/DDI: adverse outcomes named in its text


@dataclass
class Framework:
    args: Dict[str, Arg] = field(default_factory=dict)
    attacks: List[Tuple[str, str]] = field(default_factory=list)
    supports: List[Tuple[str, str]] = field(default_factory=list)
    ignored: Dict[str, List[str]] = field(default_factory=dict)
    taking: List[str] = field(default_factory=list)
    groups: Dict[str, str] = field(default_factory=dict)
    alternatives: Dict[str, List[str]] = field(default_factory=dict)   # conditional MIT id -> candidates that overrule it
    silent: List[Tuple[str, str]] = field(default_factory=list)        # KG DDIs dropped under the ddinter-silent policy
    weak_review: bool = False

    def add(self, a: Arg) -> Arg:
        self.args[a.id] = a
        return a

    def uses(self) -> List[Arg]:
        return [a for a in self.args.values() if a.t == "USE"]


def build(sg: Subgraph, ctx: Context, rules: Rules) -> Framework:
    F = Framework(weak_review=ctx.weak_review)
    name = lambda i: sg.drugs.get(i, {}).get("name", i)
    cats = lambda i: sg.drugs.get(i, {}).get("categories", [])
    grp = {i: rules.group_of(i, cats(i)) for i in sg.drugs}
    F.groups = grp
    ppi_on = ctx.mitigations.get("ppi", False) or any(
        "proton pump" in c.lower() for m in sg.comeds for c in cats(m))

    def mit_on(k: Optional[str]) -> bool:
        return bool(k) and (ppi_on if k == "ppi" else ctx.mitigations.get(k, False))

    def add_mit(target: Arg, k: str, detail: str = "mitigation available in this context", source: str = "") -> None:
        m = F.add(Arg(id=f"MIT:{target.id}", t="MIT", drug=target.drug, label=rules.mitigations.get(k, k), key=k,
                      detail=detail, source=source))
        F.attacks.append((m.id, target.id))

    conditional: Dict[str, str] = {}        # MIT id -> drug, for mitigations DDInter allows only without alternatives
    ddi_by_pair: Dict[Tuple[str, str], dict] = {}
    for x in sg.ddis:
        ddi_by_pair[(x["a"], x["b"])] = x
    thr = SEV[ctx.threshold]
    cand_ids = []
    for c in sg.candidates:
        d = c["id"]
        if d in sg.comeds:
            F.taking.append(name(d))
            continue
        cand_ids.append(d)
        u = F.add(Arg(id=f"USE:{d}", t="USE", drug=d, label=name(d), detail=", ".join(cats(d)[:2])))
        i = F.add(Arg(id=f"IND:{d}", t="IND", drug=d, label="Indicated", detail=c["indication"]))
        F.supports.append((i.id, u.id))
        F.ignored[u.id] = []
        for r in rules.contraindications(d, grp[d], cats(d), ctx.conditions):
            a = F.add(Arg(id=f"CI:{d}:{r['condition']}", t="CI", drug=d,
                          label=rules.conditions.get(r["condition"], r["condition"]),
                          kind=r["kind"], detail=r.get("note", ""), source="curated"))
            a.harms = harms_of(a.label, a.detail)
            F.attacks.append((a.id, u.id))
            if r["kind"] == "relative" and mit_on(r.get("mitigation")):
                add_mit(a, r["mitigation"])
        for kc in [k for k in getattr(sg, "kg_contra", []) if k["drug"] == d]:
            pol = rules.kg_contra_policy(d, grp[d], cats(d), kc["disease"])
            a = F.add(Arg(id=f"CI:{d}:kg:{kc['disease_id']}", t="CI", drug=d, label=kc["disease"], kind=pol["kind"],
                          detail=pol["note"] or "contraindication edge in the KG",
                          source="KG" + (" + curated grading" if pol["note"] else "")))
            a.harms = harms_of(a.label, a.detail)
            F.attacks.append((a.id, u.id))
            if pol["kind"] == "relative" and mit_on(pol.get("mitigation")):
                add_mit(a, pol["mitigation"])
        for m in sg.comeds:
            if m == d:
                continue
            x = ddi_by_pair.get((d, m))
            dl = (getattr(sg, "ddinter", {}) or {}).get(f"{d}|{m}")
            has_dl = dl in SEV
            # curated overrides also fire without a KG-asserted interaction (e.g. class duplication)
            info = rules.classify_ddi({"id": d, "group": grp[d], "categories": cats(d)},
                                      {"id": m, "group": grp.get(m, ""), "categories": cats(m)},
                                      x["text"] if x else "")
            if not x and info["source"] != "curated" and not has_dl:
                continue
            curated = info["source"] == "curated"
            default_mit = not curated and not (x and x["text"])      # mitigation not backed by any text or rule
            if has_dl:                                               # a published severity beats curated/heuristic ones
                info = dict(info, severity=dl, effect=info["effect"] if (curated or (x and x["text"])) else f"DDInter level {dl}")
                source = "KG + DDInter severity" if x else "DDInter (not in KG)"
                if curated:                                          # the mitigation decision still comes from a curated rule
                    source += ", curated mitigability"
            elif info["source"] == "KG (severity unknown)":
                if ctx.untyped_ddi == "ignore":
                    F.ignored[u.id].append(f"interaction with {name(m)} without severity (ignored by policy)")
                    continue
                known = set(getattr(sg, "ddinter_known", []) or [])
                if ctx.untyped_ddi == "ddinter-silent" and d in known and m in known and dl is None:
                    F.ignored[u.id].append(f"KG interaction with {name(m)} not confirmed by DDInter "
                                           f"(DDInter covers both drugs and records none)")
                    F.silent.append((d, m))
                    continue
                source = "KG (severity unknown)"
            elif curated:
                source = "KG + curated severity" if x else "curated (not in KG)"
            else:
                source = info["source"]
            if default_mit and ctx.untyped_ddi in ("strict", "ddinter-silent"):
                info = dict(info, mitigation=None)
            mg = (getattr(sg, "ddinter_mgmt", {}) or {}).get(f"{d}|{m}") if ctx.use_management else None
            if mg:                                                   # published management advice decides mitigability
                info = dict(info, mitigation=mg["mitigation"])
                source = source.replace(", curated mitigability", "") + " + DDInter management"
            if SEV[info["severity"]] < thr:
                F.ignored[u.id].append(f"{info['severity']} interaction with {name(m)}" + (" (DDInter)" if has_dl else ""))
                continue
            a = F.add(Arg(id=f"DDI:{d}:{m}", t="DDI", drug=d, label=name(m), with_=name(m),
                          sev=info["severity"], source=source,
                          detail=info["effect"] or "interaction asserted in the KG"))
            a.harms = harms_of(info["effect"] or "", (x or {}).get("text", ""),
                               (mg or {}).get("interaction", ""), (mg or {}).get("management", ""))
            F.attacks.append((a.id, u.id))
            major_ok = info["severity"] != "major" or (mg is not None and ctx.management_mitigates_major)
            if mg and not mg["mitigation"]:
                F.ignored[u.id].append(f"DDInter management for {name(m)} gives no mitigation ({mg['reason']})")
            if major_ok and mit_on(info.get("mitigation")):
                if mg:
                    add_mit(a, info["mitigation"], detail=f"DDInter management: {mg['management'][:300]}",
                            source=f"DDInter management ({mg['reason']})")
                    if mg.get("avoid_preferred"):
                        conditional[f"MIT:{a.id}"] = d
                else:
                    add_mit(a, info["mitigation"])
    if ctx.same_harm:
        # One mitigation per harm: if two objections concern the same adverse outcome, at least one of them is
        # severe (a contraindication or a major interaction) and at least one is answered only by a mitigation,
        # the mitigations do not add up to safety. An unattacked argument records the cumulative risk.
        mitigated = {t for s_, t in F.attacks if F.args[s_].t == "MIT"}
        for d in cand_ids:
            # only supported objections count: an unrated KG edge cannot add to a cumulative risk
            objs = [a for a in F.args.values() if a.drug == d and a.t in ("CI", "DDI") and a.source not in WEAK]
            for h in _ACTIVE:
                hs = [a for a in objs if h in a.harms]
                if (len(hs) >= 2 and any(a.id in mitigated for a in hs)
                        and any(a.t == "CI" or a.sev == "major" for a in hs)):
                    c = F.add(Arg(id=f"CUM:{d}:{h}", t="CUM", drug=d, label=h, source="cumulative-risk rule",
                                  detail="; ".join(f"{a.label}" + (f" ({a.sev})" if a.sev else "") for a in hs)))
                    F.attacks.append((c.id, f"USE:{d}"))
    if ctx.necessity and conditional:
        # A mitigation that DDInter allows only when the combination cannot be avoided is attacked by every
        # other candidate for the same disease that does not itself depend on such a mitigation. The attacker
        # is ALT:x ("x is available"), not USE:x: ALT:x is defeated only by supported objections to x
        # (published, curated or graded), so an unrated KG edge cannot make an alternative unavailable.
        # When the mitigation falls only to alternatives that are themselves rejected on weak evidence,
        # the drug is reported as 'review' instead of being accepted or rejected.
        dis = {c["id"]: set(c.get("diseases") or []) for c in sg.candidates}
        needs = set(conditional.values())
        for mid, d in conditional.items():
            alts = [x for x in cand_ids if x != d and x not in needs
                    and (ctx.alt_scope == "query" or not dis[d] or not dis[x] or dis[d] & dis[x])]
            F.alternatives[mid] = alts
            for x in alts:
                aid = f"ALT:{x}"
                if aid not in F.args:
                    F.add(Arg(id=aid, t="ALT", drug=x, label=name(x), detail="available alternative"))
                    F.attacks += [(o.id, aid) for o in F.args.values()
                                  if o.drug == x and o.t in ("CI", "DDI", "CUM") and o.source not in WEAK]
                F.attacks.append((aid, mid))
    if ctx.duplication:
        for a, b in combinations(cand_ids, 2):
            if grp[a] and grp[a] == grp[b]:
                F.attacks += [(f"USE:{a}", f"USE:{b}"), (f"USE:{b}", f"USE:{a}")]
    return F


@dataclass
class Result:
    lab: Dict[str, str]
    attackers: Dict[str, List[str]]
    preferred: Optional[List[List[str]]]
    status: Dict[str, str]
    undecided: int
    seconds: float
    review_why: Dict[str, str] = field(default_factory=dict)   # USE id -> "weak evidence" | "necessity" | both


def solve(F: Framework, removed: Optional[Set[str]] = None, max_leaves: int = 200000, review: bool = True) -> Result:
    t0 = time.perf_counter()
    removed = removed or set()
    act = [a for a in F.args if F.args[a].t != "IND" and a not in removed]
    on = set(act)
    edges = [(s, t) for s, t in F.attacks if s in on and t in on]
    atk: Dict[str, List[str]] = {a: [] for a in act}
    for s, t in edges:
        atk[t].append(s)
    lab: Dict[str, str] = {}
    changed = True
    while changed:
        changed = False
        for a in act:
            if a in lab:
                continue
            if all(lab.get(b) == "out" for b in atk[a]):
                lab[a] = "in"; changed = True
            elif any(lab.get(b) == "in" for b in atk[a]):
                lab[a] = "out"; changed = True
    U = [a for a in act if a not in lab]
    for a in U:
        lab[a] = "undec"
    g_in = [a for a in act if lab[a] == "in"]
    pref = _preferred(U, g_in, atk, edges, max_leaves)
    status = {}
    for u in F.uses():
        if u.id in removed:
            continue
        if lab[u.id] == "in":
            status[u.id] = "accepted"
        elif pref is not None and any(u.id in S for S in pref):
            status[u.id] = "alternative"
        elif pref is None and lab[u.id] == "undec":
            status[u.id] = "undecided"   # preferred enumeration skipped (search budget exceeded)
        else:
            status[u.id] = "rejected"
    why: Dict[str, str] = {}
    if review and (F.alternatives or F.weak_review):
        for uid in [u for u, v in status.items() if v == "rejected"]:
            rm, reasons = review_removal(F, uid, lab, atk, status)
            if rm and solve(F, removed | rm, max_leaves, review=False).status.get(uid) != "rejected":
                status[uid] = "review"
                why[uid] = " + ".join(sorted(reasons))
    return Result(lab, atk, pref, status, len(U), time.perf_counter() - t0, why)


def review_removal(F: Framework, uid: str, lab, atk, status):
    """Weak evidence decides nothing on its own. Every effective objection to uid must be either
    (a) an unrated KG edge (when F.weak_review), or (b) a DDI whose 'avoid unless necessary' mitigation was
    overruled only by alternatives that are themselves rejected. Returns (arguments to remove, reasons);
    the caller re-solves without them and reports 'review' only if the drug would then not be rejected."""
    objs = [x for x in atk.get(uid, []) if F.args[x].t in ("CI", "DDI", "CUM") and lab.get(x) == "in"]
    if not objs:
        return set(), set()
    out: Set[str] = set()
    reasons: Set[str] = set()
    for o in objs:
        if F.weak_review and F.args[o].source in WEAK:
            out.add(o); reasons.add("weak evidence")
            continue
        alts = weak_overrule(F, uid, lab, atk, status, only=o)
        if not alts:
            return set(), set()
        out |= alts; reasons.add("necessity")
    return out, reasons


def weak_overrule(F: Framework, uid: str, lab, atk, status, only: Optional[str] = None) -> Set[str]:
    """If every effective objection to uid (or just `only`) is a DDI whose 'avoid unless necessary' mitigation was
    overruled only by alternatives that are themselves rejected (on weak evidence, since ALT survived), return those ALT ids."""
    objs = [only] if only else [x for x in atk.get(uid, []) if F.args[x].t in ("CI", "DDI", "CUM") and lab.get(x) == "in"]
    out: Set[str] = set()
    if not objs:
        return out
    for o in objs:
        mids = [m for m in atk.get(o, []) if m in F.alternatives and lab.get(m) != "in"]
        if not mids:
            return set()
        for m in mids:
            live = [x for x in atk.get(m, []) if lab.get(x) in ("in", "undec")]
            if any(status.get("USE:" + x[4:]) in ("accepted", "alternative") for x in live):
                return set()           # a genuinely acceptable alternative exists: the overrule stands
            out |= set(live)
    return out


def _preferred(U: List[str], g_in: List[str], atk: Dict[str, List[str]], edges, max_leaves: int):
    """Preferred extensions = maximal admissible sets. Every preferred extension contains the grounded
    extension, so only subsets of the undecided arguments are searched, and only conflict-free ones
    (a clique of k mutually exclusive options has k+1 such subsets, not 2^k)."""
    conflict: Dict[str, Set[str]] = {a: set() for a in U}
    for s_, t in edges:
        if s_ in conflict and t in conflict:
            conflict[s_].add(t); conflict[t].add(s_)
    base = set(g_in)
    adm: List[frozenset] = []
    leaves = [0]

    def admissible(S: Set[str]) -> bool:
        return all(any(c in S for c in atk[b]) for x in S for b in atk[x])

    def rec(i: int, chosen: Set[str]) -> bool:
        if i == len(U):
            leaves[0] += 1
            if leaves[0] > max_leaves:
                return False
            S = base | chosen
            if admissible(S):
                adm.append(frozenset(chosen))
            return True
        a = U[i]
        if a not in conflict[a] and not (conflict[a] & chosen):
            chosen.add(a)
            ok = rec(i + 1, chosen)
            chosen.discard(a)
            if not ok:
                return False
        return rec(i + 1, chosen)

    if not rec(0, set()):
        return None
    adm.sort(key=len, reverse=True)
    maxi: List[frozenset] = []
    for A in adm:
        if not any(A < M for M in maxi) and A not in maxi:
            maxi.append(A)
    return [sorted(base | set(M)) for M in maxi]


def filter_baseline(F: Framework, removed: Optional[Set[str]] = None) -> Dict[str, str]:
    """Drop a candidate if any active contraindication or DDI targets it (no mitigations, no duplication)."""
    removed = removed or set()
    out = {}
    for u in F.uses():
        if u.id in removed:
            continue
        hit = any(t == u.id and s not in removed and F.args[s].t in ("CI", "DDI") for s, t in F.attacks)
        out[u.id] = "rejected" if hit else "accepted"
    return out


def counterfactual(F: Framework, uid: str, removed: Optional[Set[str]] = None) -> Optional[List[str]]:
    """Smallest set (size 1, then 2) of direct attackers whose removal lifts a rejected option."""
    removed = set(removed or ())
    direct = solve(F, removed, review=False).attackers.get(uid, [])
    for k in (1, 2):
        if k == 2 and len(direct) > 8:
            break
        for combo in combinations(direct, k):
            if solve(F, removed | set(combo), review=False).status.get(uid) != "rejected":
                return list(combo)
    return None


def alternative_counterfactual(F: Framework, mid: str, removed: Optional[Set[str]] = None, max_iter: int = 4):
    """For an overruled 'avoid unless necessary' mitigation: a minimal set of alternatives that would all have to be
    unavailable for the mitigation to hold, and the drug's status then. Returns (names, status, n_alternatives)."""
    removed = set(removed or ())
    gone: List[str] = []
    R = solve(F, removed, review=False)
    for _ in range(max_iter):
        blockers = [x for x in R.attackers.get(mid, []) if R.lab.get(x) in ("in", "undec")]
        if not blockers:
            break
        gone += blockers
        R = solve(F, removed | set(gone), review=False)
    if R.lab.get(mid) != "in":
        return None
    for x in list(gone):                     # drop alternatives whose unavailability is not needed
        trial = [y for y in gone if y != x]
        if solve(F, removed | set(trial), review=False).lab.get(mid) == "in":
            gone = trial
    R = solve(F, removed | set(gone))
    uid = f"USE:{F.args[mid].drug}"
    return [F.args[x].label for x in gone], R.status.get(uid, "rejected"), len(F.alternatives.get(mid, []))


def describe(a: Arg) -> str:
    if a.t == "CI":
        return f"{a.kind} contraindication: {a.label} ({a.detail}) [{a.source}]"
    if a.t == "DDI":
        return f"{a.sev} interaction with {a.with_} ({a.detail}) [{a.source}]"
    if a.t == "CUM":
        return f"cumulative risk of {a.label}: {a.detail} (one mitigation per harm) [{a.source}]"
    if a.t == "MIT":
        if a.source:  # published advice: quote it so the reader can check the mapping
            txt = a.detail.replace("DDInter management: ", "")
            return f"{a.label} [DDInter management: \"{txt[:200]}{'…' if len(txt) > 200 else ''}\"]"
        return a.label
    return a.label


def _alt_cf(F, m, removed):
    if m not in F.alternatives:
        return None
    r = alternative_counterfactual(F, m, removed)
    return {"unavailable": r[0], "status": r[1], "of_alternatives": r[2]} if r else None


def explain(F: Framework, R: Result, base: Dict[str, str], removed: Optional[Set[str]] = None) -> List[dict]:
    out = []
    for u in F.uses():
        if u.id not in R.status:
            continue
        s = R.status[u.id]
        attackers = [F.args[x] for x in R.attackers.get(u.id, [])]
        objections = [a for a in attackers if a.t != "USE"]
        peers = [a for a in attackers if a.t == "USE"]
        e = {
            "drug": u.drug, "name": u.label, "group": F.groups.get(u.drug, ""), "status": s, "filter": base[u.id],
            "differs_from_filter": (s == "rejected") != (base[u.id] == "rejected"),
            "indication": F.args[f"IND:{u.drug}"].detail,
            "effective_objections": [describe(a) for a in objections if R.lab[a.id] == "in"],
            "answered_objections": [
                {"objection": describe(a),
                 "answered_by": [describe(F.args[m]) for m in R.attackers.get(a.id, []) if R.lab.get(m) == "in"]}
                for a in objections if R.lab[a.id] == "out"],
            "competes_with": [p.label for p in peers if R.status.get(p.id) != "rejected"],
            "overruled_mitigations": [
                {"objection": describe(a), "mitigation": describe(F.args[m]),
                 "because_accepted": [F.args[x].label for x in R.attackers.get(m, [])
                                      if R.status.get("USE:" + x[4:]) in ("accepted", "alternative")][:6],
                 "n_alternatives": sum(R.status.get("USE:" + x[4:]) in ("accepted", "alternative")
                                       for x in R.attackers.get(m, [])),
                 "blocked_only_by_weak_evidence": [F.args[x].label for x in R.attackers.get(m, [])
                                                   if R.lab.get(x) == "in" and R.status.get("USE:" + x[4:]) == "rejected"][:6],
                 "counterfactual": _alt_cf(F, m, removed)}
                for a in objections if R.lab[a.id] == "in"
                for m in R.attackers.get(a.id, []) if F.args[m].t == "MIT" and R.lab.get(m) != "in"],
            "notes": [x for x in F.ignored.get(u.id, []) if x.startswith("DDInter management")],
            "preferred_extensions_containing": (sum(u.id in S for S in R.preferred) if R.preferred else None),
            "ignored_below_threshold": [x for x in F.ignored.get(u.id, []) if not x.startswith("DDInter management")],
            "counterfactual": None,
            "review_reason": R.review_why.get(u.id, ""),
        }
        if s in ("rejected", "review"):
            cf = counterfactual(F, u.id, removed)
            e["counterfactual"] = [describe(F.args[x]) for x in cf] if cf else None
        out.append(e)
    return out
