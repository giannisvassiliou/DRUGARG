"""PrimeKG backend (Chandak, Huang & Zitnik, Scientific Data 2023).

kg.csv columns: relation, display_relation, x_index, x_id, x_type, x_name, x_source,
                y_index, y_id, y_type, y_name, y_source
Relations used here: indication, off-label use, contraindication (drug-disease), drug_drug.
drug_features.csv: node_index plus DrugBank text features (group, category, atc_1..atc_4, ...).

`drugarg primekg-index` streams these (8M rows) once into a small SQLite file; the extractor
then answers the same pipeline questions as the Bio2RDF extractor, plus KG contraindications.
"""
from __future__ import annotations

import csv
import re
import sqlite3
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

from .extract import Extractor, Subgraph

DRUG_DISEASE = {"indication", "off-label use", "contraindication"}
FEATURES = ["group", "category", "atc_1", "atc_2", "atc_3", "atc_4", "indication", "description"]

csv.field_size_limit(min(sys.maxsize, 2 ** 31 - 1))


def build_index(kg_csv: str, drug_features_csv: Optional[str], out: str, progress: bool = True) -> dict:
    t0 = time.perf_counter()
    if Path(out).exists():
        Path(out).unlink()
    db = sqlite3.connect(out)
    db.executescript("""
      CREATE TABLE node(idx TEXT PRIMARY KEY, id TEXT, type TEXT, name TEXT, source TEXT);
      CREATE TABLE dd(drug TEXT, disease TEXT, rel TEXT, PRIMARY KEY(drug, disease, rel));
      CREATE TABLE ddi(a TEXT, b TEXT, display TEXT, PRIMARY KEY(a, b));
      CREATE TABLE feat(idx TEXT PRIMARY KEY, grp TEXT, category TEXT, atc_1 TEXT, atc_2 TEXT, atc_3 TEXT,
                        atc_4 TEXT, indication TEXT, description TEXT);
      CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT);
    """)
    counts: Dict[str, int] = {}
    nodes: Dict[str, tuple] = {}
    dd, ddi = [], []

    def flush(force: bool = False) -> None:
        if force or len(ddi) >= 200_000:
            db.executemany("INSERT OR IGNORE INTO ddi VALUES (?,?,?)", ddi); ddi.clear()
        if force or len(dd) >= 200_000:
            db.executemany("INSERT OR IGNORE INTO dd VALUES (?,?,?)", dd); dd.clear()

    with open(kg_csv, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        missing = {"relation", "x_index", "x_id", "x_type", "x_name", "y_index", "y_id", "y_type", "y_name"} - set(r.fieldnames or [])
        if missing:
            raise SystemExit(f"{kg_csv} lacks PrimeKG columns {sorted(missing)}; found {r.fieldnames}")
        for n, row in enumerate(r, 1):
            rel = row["relation"]
            counts[rel] = counts.get(rel, 0) + 1
            if progress and n % 1_000_000 == 0:
                print(f"  {n:,} rows read ({time.perf_counter() - t0:.0f}s)", file=sys.stderr)
            if rel not in DRUG_DISEASE and rel != "drug_drug":
                continue
            for s in ("x", "y"):
                if row[f"{s}_type"] in ("drug", "disease"):
                    nodes[row[f"{s}_index"]] = (row[f"{s}_id"], row[f"{s}_type"], row[f"{s}_name"], row.get(f"{s}_source", ""))
            if rel == "drug_drug":
                a, b = sorted((row["x_index"], row["y_index"]))
                ddi.append((a, b, row.get("display_relation", "")))
            else:
                drug, dis = (row["x_index"], row["y_index"]) if row["x_type"] == "drug" else (row["y_index"], row["x_index"])
                dd.append((drug, dis, rel))
            flush()
    flush(force=True)
    db.executemany("INSERT INTO node VALUES (?,?,?,?,?)", [(k, *v) for k, v in nodes.items()])
    nfeat = 0
    if drug_features_csv:
        with open(drug_features_csv, newline="", encoding="utf-8") as f:
            r = csv.DictReader(f)
            rows = []
            for row in r:
                rows.append((row.get("node_index", ""), *[row.get(k, "") or "" for k in FEATURES]))
            db.executemany("INSERT OR REPLACE INTO feat VALUES (?,?,?,?,?,?,?,?,?)", rows)
            nfeat = len(rows)
    db.executescript("""
      CREATE INDEX node_name ON node(type, name COLLATE NOCASE);
      CREATE INDEX node_id ON node(id);
      CREATE INDEX dd_dis ON dd(disease, rel);
      CREATE INDEX ddi_b ON ddi(b);
    """)
    n_dd = db.execute("SELECT COUNT(*) FROM dd").fetchone()[0]
    n_ddi = db.execute("SELECT COUNT(*) FROM ddi").fetchone()[0]
    stats = {"relations": counts, "drug_disease_edges": n_dd, "drug_drug_pairs": n_ddi,
             "nodes": len(nodes), "drug_features": nfeat, "seconds": round(time.perf_counter() - t0, 1)}
    db.executemany("INSERT INTO meta VALUES (?,?)", [("source", str(Path(kg_csv).resolve())), ("stats", repr(stats))])
    db.commit()
    db.close()
    return stats


_PART_OF = re.compile(r"\bis part of (.*?)\.?$", re.I | re.S)
_RELATED = re.compile(r"\bis pharmacologically related to (.*?)\.?$", re.I | re.S)
_IS = re.compile(r"^.*?\bis (.*?)\.?$", re.I | re.S)


def parse_categories(text: str) -> List[str]:
    """PrimeKG: 'Ibuprofen is part of A ; B ; C.'  (older dumps: 'A; B' or 'A|B')."""
    if not text:
        return []
    m = _PART_OF.search(text)
    body = m.group(1) if m else text
    return [c.strip().rstrip(".") for c in re.split(r"\s*[;|]\s*", body) if c.strip()]


def parse_atc(text: str) -> str:
    """PrimeKG: 'X is pharmacologically related to <ATC level names joined by and>.'
    Kept as one lower-case string (names contain 'and', so it is not split)."""
    if not text:
        return ""
    m = _RELATED.search(text)
    return (m.group(1) if m else text).strip().rstrip(".").lower()


def parse_group(text: str) -> str:
    """PrimeKG: 'Glucosamine is approved and investigational.' -> 'approved and investigational'."""
    if not text:
        return ""
    m = _IS.match(text.strip())
    return (m.group(1) if m else text).lower()


class _Log:
    """Mimics Endpoint.log/name so reports and run.json look the same for both backends."""

    def __init__(self, name: str) -> None:
        self.name, self.log = name, []

    def timed(self, tag: str, fn):
        t0 = time.perf_counter()
        rows = fn()
        self.log.append({"tag": tag, "seconds": time.perf_counter() - t0, "rows": len(rows)})
        return rows


CORROBORATION_STOPWORDS = {"type", "disease", "disorder", "syndrome", "with", "acute", "chronic"}

NAME_SYNONYMS = {
    "aspirin": "Acetylsalicylic acid", "asa": "Acetylsalicylic acid", "paracetamol": "Acetaminophen",
    "frusemide": "Furosemide", "albuterol": "Salbutamol", "adrenaline": "Epinephrine", "noradrenaline": "Norepinephrine",
    "lignocaine": "Lidocaine", "glyceryl trinitrate": "Nitroglycerin", "gtn": "Nitroglycerin",
    "hctz": "Hydrochlorothiazide", "co-trimoxazole": "Sulfamethoxazole", "ciclosporin": "Cyclosporine",
    "bendrofluazide": "Bendroflumethiazide", "amoxycillin": "Amoxicillin", "colecalciferol": "Cholecalciferol",
}


class PrimeKGExtractor:
    def __init__(self, db_path: str) -> None:
        if not Path(db_path).exists():
            raise SystemExit(f"{db_path} not found; build it with: drugarg primekg-index kg.csv drug_features.csv -o {db_path}")
        self.db = sqlite3.connect(db_path)
        self.ep = _Log(f"primekg:{db_path}")
        self.last_match = "exact"

    def q(self, tag: str, sql: str, args=()) -> list:
        return self.ep.timed(tag, lambda: self.db.execute(sql, args).fetchall())

    def match_diseases(self, terms: List[str], exclude: List[str] = (), exact_first: bool = False) -> List[tuple]:
        """Disease nodes whose name contains a term; a node is dropped if it contains an excluded phrase.
        exact_first: if a node is named exactly <term>, <term> disease or <term> (disease), use only those (patient conditions)."""
        out = {}
        rx = re.compile("|".join(re.escape(x) for x in exclude), re.I) if exclude else None
        for t in terms:
            rows = self.q(f"diseases:{t}", "SELECT idx, id, name FROM node WHERE type='disease' "
                          "AND name LIKE ? COLLATE NOCASE", (f"%{t}%",))
            if exact_first:
                exact = [r for r in rows if r[2].lower() in (t.lower(), t.lower() + " disease", t.lower() + " (disease)")]
                rows = exact or rows
            for idx, did, name in rows:
                if rx and rx.search(name):
                    continue
                out[idx] = (idx, did, name)
        return list(out.values())

    def find_diseases(self, text: str, limit: int = 40) -> List[tuple]:
        """Disease nodes whose name contains text, with how many drug edges each has (to pick patient-disease names)."""
        rows = self.q(f"find:{text}", "SELECT n.idx, n.id, n.name, (SELECT COUNT(*) FROM dd WHERE dd.disease = n.idx) AS k "
                      "FROM node n WHERE n.type='disease' AND n.name LIKE ? COLLATE NOCASE ORDER BY k DESC LIMIT ?",
                      (f"%{text}%", limit))
        return rows

    def indication_text(self, name: str) -> Optional[tuple]:
        r = self._drug_by_name_or_id(name)
        if not r:
            return None
        row = self.db.execute("SELECT indication FROM feat WHERE idx=?", (r[0],)).fetchone()
        return r[2], r[1], (row[0] if row else None)

    def _indication_texts(self, idxs: List[str]) -> Dict[str, str]:
        res: Dict[str, str] = {}
        for ch in range(0, len(idxs), 500):
            part = idxs[ch:ch + 500]
            ph = ",".join("?" * len(part))
            for idx, txt in self.q("indication-text", f"SELECT idx, indication FROM feat WHERE idx IN ({ph})", part):
                if txt:
                    res[idx] = txt.lower()
        return res

    def _features(self, idxs: List[str]) -> Dict[str, dict]:
        res = {}
        for ch in range(0, len(idxs), 500):
            part = idxs[ch:ch + 500]
            ph = ",".join("?" * len(part))
            for row in self.q("features", f"SELECT idx, grp, category, atc_1, atc_2, atc_3, atc_4 FROM feat WHERE idx IN ({ph})", part):
                res[row[0]] = {"group": parse_group(row[1] or ""), "categories": parse_categories(row[2] or ""),
                               "atc": [x for x in (parse_atc(a) for a in row[3:7] if a) if x]}
        return res

    def _drug_by_name_or_id(self, s: str) -> Optional[tuple]:
        s = s.strip()
        s = NAME_SYNONYMS.get(s.lower(), s)   # common/British names -> DrugBank names
        self.last_match = "exact"
        if re.match(r"^DB\d{5}$", s, re.I):
            rows = self.q(f"resolve:{s}", "SELECT idx, id, name FROM node WHERE type='drug' AND id = ? COLLATE NOCASE", (s,))
            return rows[0] if rows else None
        for how, pattern in (("exact", s), ("prefix", f"{s} %"), ("prefix", f"{s}%"), ("substring", f"%{s}%")):
            rows = self.q(f"resolve:{s}", "SELECT idx, id, name FROM node WHERE type='drug' AND name LIKE ? COLLATE NOCASE", (pattern,))
            if rows:
                self.last_match = how
                return sorted(rows, key=lambda r: (len(r[2]), r[2]))[0]
        return None

    def extract(self, disease_text: List[str], comed_names: List[str], max_candidates: int = 50,
                extra_candidates=None, require_groups: List[str] = ("approved",),
                exclude_groups: List[str] = ("withdrawn", "nutraceutical", "illicit"),
                exclude_text: List[str] = (), patient_diseases: List[str] = (),
                include_offlabel: bool = False, corroborate: bool = False) -> Subgraph:
        require_groups = [g for g in require_groups if g.lower() != "none"]
        exclude_groups = [g for g in exclude_groups if g.lower() != "none"]
        sg = Subgraph(query={"disease_text": disease_text, "comedications": comed_names, "max_candidates": max_candidates,
                             "require_groups": require_groups, "exclude_groups": exclude_groups,
                             "exclude_text": list(exclude_text), "patient_diseases": list(patient_diseases),
                             "backend": "PrimeKG"})
        dis = self.match_diseases(disease_text, exclude_text)
        sg.query["matched_disease_nodes"] = [d[2] for d in dis]
        rels = ("indication", "off-label use") if include_offlabel else ("indication",)
        by_drug: Dict[str, List[str]] = {}
        dmap = {d[0]: d for d in dis}
        for ch in range(0, len(dis), 500):
            part = [d[0] for d in dis[ch:ch + 500]]
            ph = ",".join("?" * len(part))
            for drug, disease, rel in self.q("candidates", f"SELECT drug, disease, rel FROM dd WHERE rel IN ({','.join('?' * len(rels))}) "
                                             f"AND disease IN ({ph})", (*rels, *part)):
                by_drug.setdefault(drug, []).append(f"{rel}: {dmap[disease][2]}")
        feats = self._features(list(by_drug))
        nodes = {r[0]: r for r in self.q("drug-nodes", "SELECT idx, id, name FROM node WHERE type='drug'")} if by_drug else {}

        def ok(idx: str) -> bool:
            g = feats.get(idx, {}).get("group", "").lower()
            if require_groups and not all(x.lower() in g for x in require_groups):
                return False
            return not any(x.lower() in g for x in exclude_groups)

        # documented curated additions where PrimeKG lacks an indication edge (rules.json: curated_indications)
        for ci in getattr(self, "curated_indications", None) or []:
            hit = [d for d in dis if re.search(ci["disease_regex"], d[2], re.I)]
            row = self.q(f"curated:{ci['drug']}", "SELECT idx, id, name FROM node WHERE type='drug' AND id=?", (ci["drug"],))
            if not hit or not row:
                continue
            i = row[0][0]
            new = i not in by_drug
            by_drug.setdefault(i, []).extend(f"curated indication: {d[2]}" for d in hit)
            nodes = nodes or {}
            nodes.setdefault(i, row[0])
            feats.update({k: v for k, v in self._features([i]).items() if k not in feats})
            if new:
                sg.query.setdefault("curated_indications", []).append(f"{row[0][2]} ({ci['drug']}): {ci.get('note', '')}")
        kept = [i for i in by_drug if ok(i)]
        if corroborate:
            # keep a KG indication edge only if the drug's own DrugBank indication text mentions the disease
            stems = sorted({w[:7] for t in disease_text for w in re.findall(r"[a-z]+", t.lower())
                            if len(w) >= 4 and w not in CORROBORATION_STOPWORDS})
            texts = self._indication_texts(kept)
            dropped = [i for i in kept if texts.get(i) and not any(st in texts[i] for st in stems)]
            kept = [i for i in kept if i not in dropped]
            sg.query["corroboration"] = {"stems": stems, "dropped": sorted(nodes[i][2] for i in dropped),
                                         "kept_without_text": sorted(nodes[i][2] for i in kept if not texts.get(i))}
        sg.query["matching_drugs"] = len(kept)
        if len(kept) > max_candidates:
            sg.query["candidates_truncated"] = f"candidate list truncated: kept {max_candidates} of {len(kept)} matching drugs"
        # most specific first: drugs indicated for more of the matched disease nodes, then by name
        kept.sort(key=lambda i: (-len(by_drug[i]), nodes[i][2].lower()))
        idx_of: Dict[str, str] = {}
        for i in kept[:max_candidates]:
            _, dbid, name = nodes[i]
            idx_of[dbid] = i
            f = feats.get(i, {})
            cats = f.get("categories", []) + [f"ATC {a}" for a in f.get("atc", [])]
            sg.drugs[dbid] = {"name": name, "categories": cats}
            src = "curated " if any(x.startswith("curated") for x in by_drug[i]) else "PrimeKG "
            sg.candidates.append({"id": dbid, "indication": src + "; ".join(sorted(set(by_drug[i]))[:4]),
                                  "diseases": sorted({x.split(": ", 1)[-1] for x in by_drug[i]})})

        for n in comed_names:
            r = self._drug_by_name_or_id(n)
            if not r:
                sg.unresolved.append(n)
                continue
            idx, dbid, name = r
            idx_of[dbid] = idx
            sg.comeds.append(dbid)
            sg.query.setdefault("comedication_resolution", {})[n] = f"{name} ({dbid})"
            if self.last_match == "substring":   # e.g. aspirin -> Nitroaspirin: almost certainly not what was meant
                sg.query.setdefault("comedication_warnings", []).append(
                    f"'{n}' matched only inside another name: {name}; give the DrugBank name or id")
            f = self._features([idx]).get(idx, {})
            cats = f.get("categories", []) + [f"ATC {a}" for a in f.get("atc", [])]
            sg.drugs.setdefault(dbid, {"name": name, "categories": cats})

        # drug-drug interactions between candidates and co-medications (pairs stored once, sorted by index)
        cidx = {idx_of[c["id"]]: c["id"] for c in sg.candidates}
        midx = {idx_of[m]: m for m in sg.comeds}
        if cidx and midx:
            ph_c, ph_m = ",".join("?" * len(cidx)), ",".join("?" * len(midx))
            rows = self.q("ddis", f"SELECT a, b, display FROM ddi WHERE (a IN ({ph_c}) AND b IN ({ph_m})) OR (b IN ({ph_c}) AND a IN ({ph_m}))",
                          (*cidx, *midx, *cidx, *midx))
            for a, b, disp in rows:
                c, m = (cidx.get(a), midx.get(b)) if a in cidx and b in midx else (cidx.get(b), midx.get(a))
                if c and m and c != m:
                    sg.ddis.append({"a": c, "b": m, "resource": f"primekg:drug_drug/{a}-{b}", "text": ""})

        # KG contraindications: candidate drug -> a disease node matching a patient condition
        pat = self.match_diseases(list(patient_diseases), exact_first=True) if patient_diseases else []
        sg.query["patient_disease_nodes"] = {t: [p[2] for p in pat if t.lower() in p[2].lower()] for t in patient_diseases}
        if pat and cidx:
            pm = {p[0]: p for p in pat}
            ph_c, ph_p = ",".join("?" * len(cidx)), ",".join("?" * len(pm))
            for drug, disease, _ in self.q("contraindications", f"SELECT drug, disease, rel FROM dd WHERE rel='contraindication' "
                                           f"AND drug IN ({ph_c}) AND disease IN ({ph_p})", (*cidx, *pm)):
                sg.kg_contra.append({"drug": cidx[drug], "disease_id": pm[disease][1], "disease": pm[disease][2]})
        return sg

    def describe(self) -> dict:
        meta = dict(self.db.execute("SELECT k, v FROM meta").fetchall())
        sample = self.db.execute("SELECT n.name, f.grp, f.category, f.atc_3 FROM node n JOIN feat f ON f.idx=n.idx "
                                 "WHERE n.type='drug' AND n.name IN ('Ibuprofen','Lisinopril','Glucosamine') ").fetchall()
        return {"meta": meta, "sample_drug_features": sample,
                "counts": {r: self.db.execute("SELECT COUNT(*) FROM dd WHERE rel=?", (r,)).fetchone()[0] for r in DRUG_DISEASE}}
