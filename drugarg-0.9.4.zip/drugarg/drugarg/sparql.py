"""SPARQL access: a remote HTTP endpoint (Bio2RDF / local Virtuoso) or a local RDF file via rdflib.

Both return a list of bindings, each a dict {var: str}. Unbound variables are absent.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Dict, List, Optional

Bindings = List[Dict[str, str]]


class Endpoint:
    """Common interface; records per-query wall-clock time in self.log."""

    def __init__(self) -> None:
        self.log: List[dict] = []

    def _run(self, query: str) -> Bindings:  # pragma: no cover - abstract
        raise NotImplementedError

    def select(self, query: str, tag: str = "") -> Bindings:
        t0 = time.perf_counter()
        rows = self._run(query)
        self.log.append({"tag": tag, "seconds": time.perf_counter() - t0, "rows": len(rows)})
        return rows

    @property
    def name(self) -> str:  # pragma: no cover
        return self.__class__.__name__


class HTTPEndpoint(Endpoint):
    """SPARQL 1.1 protocol over HTTP with retries and an optional on-disk cache.

    The cache makes runs reproducible against flaky public endpoints: the same
    query text is answered from disk on later runs (delete the folder to refresh).
    """

    def __init__(self, url: str, timeout: float = 60.0, retries: int = 3,
                 cache_dir: Optional[str] = None, method: str = "GET") -> None:
        super().__init__()
        import requests  # imported lazily so the rdflib path needs no network deps

        self.url, self.timeout, self.retries, self.method = url, timeout, retries, method.upper()
        self.cache = Path(cache_dir) if cache_dir else None
        if self.cache:
            self.cache.mkdir(parents=True, exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/sparql-results+json",
                                     "User-Agent": "drugarg/0.1 (research prototype)"})
        self.failures = 0

    @property
    def name(self) -> str:
        return self.url

    def _key(self, query: str) -> Path:
        h = hashlib.sha256((self.url + "\n" + query).encode()).hexdigest()[:24]
        return self.cache / f"{h}.json"  # type: ignore[operator]

    def _run(self, query: str) -> Bindings:
        if self.cache and self._key(query).exists():
            return json.loads(self._key(query).read_text(encoding="utf-8"))
        last: Optional[Exception] = None
        for attempt in range(self.retries):
            try:
                if self.method == "POST":
                    r = self.session.post(self.url, data={"query": query}, timeout=self.timeout)
                else:
                    r = self.session.get(self.url, params={"query": query, "format": "json"},
                                         timeout=self.timeout)
                r.raise_for_status()
                data = r.json()
                rows = [{k: v["value"] for k, v in b.items()} for b in data["results"]["bindings"]]
                if self.cache:
                    self._key(query).write_text(json.dumps(rows), encoding="utf-8")
                return rows
            except Exception as e:  # network errors, timeouts, bad JSON, HTTP 5xx
                last = e
                self.failures += 1
                time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"SPARQL query failed after {self.retries} attempts at {self.url}: {last}")


class RDFLibEndpoint(Endpoint):
    """Runs the same SPARQL over a local RDF dump (Turtle, N-Triples, N-Quads, ...)."""

    def __init__(self, *paths: str) -> None:
        super().__init__()
        import rdflib

        self.paths = paths
        self.graph = rdflib.ConjunctiveGraph() if any(p.endswith((".nq", ".trig")) for p in paths) else rdflib.Graph()
        for p in paths:
            self.graph.parse(p)

    @property
    def name(self) -> str:
        return "file:" + ",".join(self.paths)

    def _run(self, query: str) -> Bindings:
        res = self.graph.query(query)
        out: Bindings = []
        for row in res:
            d = {}
            for var in res.vars:
                v = row[var]
                if v is not None:
                    d[str(var)] = str(v)
            out.append(d)
        return out
