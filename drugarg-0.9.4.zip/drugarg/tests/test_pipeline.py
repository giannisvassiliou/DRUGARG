"""End-to-end over a Bio2RDF-shaped fixture through rdflib (same SPARQL as the live endpoint)."""
import json
from pathlib import Path

from drugarg import af
from drugarg.cli import main
from drugarg.extract import Extractor
from drugarg.rules import Rules
from drugarg.sparql import RDFLibEndpoint

FIX = str(Path(__file__).parent / "fixtures" / "mini_bio2rdf.ttl")


def extract(comeds):
    return Extractor(RDFLibEndpoint(FIX)).extract(["arthritis"], comeds, 20)


def test_extraction():
    sg = extract(["warfarin", "Sertraline", "DB00440", "notadrug"])
    ids = {c["id"] for c in sg.candidates}
    assert ids == {"DB01050", "DB00788", "DB00482", "DB00563", "DB00316", "DB00635", "DB01009", "DB00065"}  # not HCTZ, rofecoxib, vitamin E
    assert sg.drugs["DB00482"]["name"] == "Celecoxib"           # label suffix stripped
    assert sg.comeds == ["DB00682", "DB01104", "DB00440"] and sg.unresolved == ["notadrug"]
    pairs = {(x["a"], x["b"]) for x in sg.ddis}
    assert ("DB01050", "DB01104") in pairs                       # older predicate spelling
    assert ("DB00316", "DB00682") in pairs
    assert "Anti-Inflammatory Agents, Non-Steroidal" in sg.drugs["DB01050"]["categories"]


def test_warfarin_case():
    sg = extract(["warfarin"])
    F = af.build(sg, af.Context(), Rules.load())
    R = af.solve(F)
    s = {F.args[u].label: v for u, v in R.status.items()}
    assert s["Ibuprofen"] == s["Naproxen"] == "rejected"         # major bleeding (text + curated)
    assert s["Celecoxib"] == "rejected"                          # curated NSAID+warfarin, no KG triple
    assert s["Prednisone"] == "accepted"                         # moderate, answered by monitoring
    assert s["Acetaminophen"] == "accepted"                      # minor, below threshold
    base = af.filter_baseline(F)
    assert base["USE:DB00635"] == "rejected"                     # the filter cannot use the mitigation
    ign = F.ignored["USE:DB00316"]
    assert ign and "minor" in ign[0]


def test_ulcer_sertraline_ppi():
    sg = extract(["sertraline"])
    ctx = af.Context(conditions=["c_ulcerhx"], mitigations={"monitor": True, "ppi": True, "dose": True}, same_harm=False)
    F = af.build(sg, ctx, Rules.load())
    R = af.solve(F)
    s = {F.args[u].label: v for u, v in R.status.items()}
    assert s["Ibuprofen"] == s["Naproxen"] == s["Celecoxib"] == "alternative"
    assert s["Methotrexate"] == "accepted"


def test_ulcer_sertraline_ppi_same_harm():
    sg = extract(["sertraline"])
    ctx = af.Context(conditions=["c_ulcerhx"], mitigations={"monitor": True, "ppi": True, "dose": True})
    F = af.build(sg, ctx, Rules.load())
    cum = [a for a in F.args.values() if a.t == "CUM"]
    assert cum and all(a.label == "bleeding" for a in cum)
    s = {F.args[u].label: v for u, v in af.solve(F).status.items()}
    assert s["Ibuprofen"] == "rejected" and s["Methotrexate"] == "accepted"


def test_cli_run_writes_outputs(tmp_path, capsys):
    main(["run", "--rdf-file", FIX, "--disease-text", "arthritis", "--comed", "warfarin",
          "--comed", "trimethoprim", "--patient-condition", "c_ckd", "-o", str(tmp_path)])
    for f in ["report.md", "answers.json", "arggraph.json", "arggraph.dot", "subgraph.ttl", "demo_dataset.json", "run.json"]:
        assert (tmp_path / f).exists(), f
    ans = json.loads((tmp_path / "answers.json").read_text(encoding="utf-8"))
    assert "Methotrexate" in ans["rejected"]
    e = next(x for x in ans["explanations"] if x["name"] == "Methotrexate")
    assert e["counterfactual"] and len(e["counterfactual"]) == 2  # CKD and trimethoprim both needed
    import rdflib
    rdflib.Graph().parse(str(tmp_path / "subgraph.ttl"))         # valid Turtle


def test_cli_eval(capsys):
    main(["eval", "--rdf-file", FIX, "--disease-text", "arthritis", "--comed", "warfarin",
          "--patient-condition", "c_ulcerhx", "--mitigation", "monitor", "--mitigation", "ppi"])
    out = capsys.readouterr().out
    assert "| bare |" in out and "+mitigations+duplication" in out


def test_release3_category_iri_and_atc():
    sg = extract(["warfarin"])
    cats = sg.drugs["DB01009"]["categories"]
    assert "Anti-Inflammatory-Agents, Non-Steroidal" in cats and "ATC M01AE03" in cats
    assert Rules.load().group_of("DB01009", cats) == "NSAID"
    F = af.build(sg, af.Context(), Rules.load())
    assert af.solve(F).status["USE:DB01009"] == "rejected"      # NSAID + warfarin via group, no id list


def test_probe_runs(capsys):
    main(["probe", "--rdf-file", FIX])
    out = capsys.readouterr().out
    assert "Indication resource" in out and "dct:description" in out and "Drug-Drug-Interaction" in out


def test_release3_ddi_title_prefix_stripped():
    sg = extract(["warfarin"])
    x = next(x for x in sg.ddis if x["a"] == "DB01009")
    assert x["text"].startswith("Nonsteroidal Anti-Inflammatory Agents may enhance")
    assert Rules.load().classify_ddi({"id": "X", "group": "", "categories": []},
                                     {"id": "Y", "group": "", "categories": []}, x["text"])["severity"] == "moderate"
    # (ketoprofen + warfarin is still major overall: the curated NSAID+warfarin rule overrides the text)


def test_class_detection_is_strict():
    sg = extract([])
    r = Rules.load()
    g = {i: r.group_of(i, d["categories"]) for i, d in sg.drugs.items()}
    assert g["DB00563"] == ""        # methotrexate: "Abortifacient Agents, Nonsteroidal" + ATC L01
    assert g["DB00065"] == ""        # infliximab-like: NSAID tag but ATC L04
    assert g["DB01009"] == "NSAID"   # ketoprofen via category + ATC M01A


def test_relevance_ranking_and_group_filters():
    sg = Extractor(RDFLibEndpoint(FIX)).extract(["arthritis"], [], 3)
    assert [c["id"] for c in sg.candidates][0] in {"DB00065", "DB00482", "DB00563", "DB00788", "DB01009", "DB01050"}
    assert len(sg.candidates) == 3 and sg.query["matching_drugs"] == 8
    sg2 = Extractor(RDFLibEndpoint(FIX)).extract(["arthritis"], [], 50, None, ["none"], ["none"])
    assert {"DB00533", "DB00163"} <= {c["id"] for c in sg2.candidates}


def test_exclude_text_and_curated_class_interactions():
    sg = Extractor(RDFLibEndpoint(FIX)).extract(["arthritis"], ["sertraline"], 50, None, ["approved"],
                                                ["withdrawn"], ["juvenile", "rheumatoid arthritis"])
    # every fixture text that only mentions "rheumatoid arthritis" drops out unless it also says "arthritis" elsewhere
    assert "DB00065" not in {c["id"] for c in sg.candidates}
    r = Rules.load()
    info = r.classify_ddi({"id": "DB00788", "group": "NSAID", "categories": []},
                          {"id": "DB01104", "group": "SSRI", "categories": []}, "")
    assert info["source"] == "curated" and info["mitigation"] == "ppi"
    assert r.classify_ddi({"id": "X", "group": "", "categories": []}, {"id": "Y", "group": "", "categories": []},
                          "Thiazide Diuretics may decrease the excretion of Lithium.")["severity"] == "major"


def test_rules_fixes_from_real_bio2rdf_run():
    r = Rules.load()
    nsaid_cat = ["Anti-Inflammatory Agents, Non-Steroidal", "ATC M01AX05"]
    assert r.group_of("DB01296", nsaid_cat) == ""                      # glucosamine is not an NSAID
    assert r.group_of("DB04552", ["Anti-Inflammatory Agents, Non-Steroidal", "ATC M01AX02"]) == "NSAID"  # niflumic acid is
    none = {"id": "X", "group": "", "categories": []}
    steroid = r.classify_ddi(none, none, "Corticosteroids (Systemic) may enhance the anticoagulant effect of Warfarin.")
    assert steroid["severity"] == "moderate" and steroid["mitigation"] == "monitor"
    md = r.classify_ddi(none, none, "Methyldopa may enhance the adverse/toxic effect of Lithium.")
    assert md["mitigation"] == "monitor"
    assert r.classify_ddi(none, none, "Vitamin E may also increase the overall risk for bleeding.")["severity"] == "major"
    gout = r.contraindications("DB00310", "THIAZIDE", [], ["c_gout"])
    assert gout and gout[0]["kind"] == "relative"


def test_harm_tags_name_outcomes_not_mechanisms():
    h = af.harms_of
    assert "renal injury" not in h("ACE inhibitors may reduce the renal clearance of lithium")
    assert "renal injury" in h("may cause deterioration of renal function, including acute renal failure")
    assert "serotonin toxicity" not in h("SSRIs deplete platelet serotonin and may increase the anticoagulant effect")
    assert "serotonin toxicity" in h("risk of serotonin syndrome")
    assert "bleeding" in h("increased risk of bleeding")


def test_weak_objections_do_not_stack():
    sg = extract(["sertraline"])
    F = af.build(sg, af.Context(conditions=["c_ulcerhx"], mitigations={"monitor": True, "ppi": True, "dose": True}),
                 Rules.load())
    for a in F.args.values():
        if a.t == "CUM":
            objs = [o for o in F.args.values() if o.drug == a.drug and o.t in ("CI", "DDI") and "bleeding" in o.harms]
            assert sum(o.source not in af.WEAK for o in objs) >= 2
