import json
from argparse import Namespace
from pathlib import Path

from drugarg import af, batch
from drugarg.cli import main
from drugarg.ddinter import DDInter, build_index
from drugarg.primekg import PrimeKGExtractor, build_index as pk_index
from drugarg.rules import Rules

FIX = Path(__file__).parent / "fixtures"


def _dbs(t):
    pk_index(str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), str(t / "pk.sqlite"), progress=False)
    build_index([str(FIX / "ddinter")], str(t / "dd.sqlite"))
    return str(t / "pk.sqlite"), str(t / "dd.sqlite")


def test_batch_cli(tmp_path, capsys):
    pk, dd = _dbs(tmp_path)
    q = tmp_path / "q.json"
    q.write_text(json.dumps({"queries": [
        {"id": "a/warfarin", "disease_text": ["arthritis"], "comed": ["warfarin"]},
        {"id": "a/none", "disease_text": ["arthritis"]},
        {"id": "nothing", "disease_text": ["zzzz-no-such-disease"]}]}), encoding="utf-8")
    main(["batch", str(q), "--primekg", pk, "--ddinter", dd, "-o", str(tmp_path / "b")])
    res = json.loads((tmp_path / "b" / "batch.json").read_text(encoding="utf-8"))
    rows = {r["id"]: r for r in res["rows"]}
    assert rows["a/warfarin"]["filter_rejected"] >= 3 and rows["a/none"]["filter_rejected"] == 0
    assert res["summary"]["queries"] == 3
    md = (tmp_path / "b" / "batch.md").read_text(encoding="utf-8")
    assert "| a/warfarin |" in md and "Necessity:" in md


def test_context_dependent_drug_detected(tmp_path):
    pk, dd = _dbs(tmp_path)
    advice = {"mitigation": "monitor", "avoid_preferred": True, "reason": "t", "management": "m", "url": "u"}

    def extract(ex, a):
        sg = ex.extract(a.disease_text, a.comed, 50)
        DDInter(dd).annotate(sg)
        sg.ddinter_mgmt["DB00635|DB00682"] = advice
        if "NOALT" in a.exclude_text:              # second query: methotrexate not available
            sg.candidates = [c for c in sg.candidates if c["id"] != "DB00563"]
        return sg

    base = Namespace(exclude_text=[])
    res = batch.run_batch(PrimeKGExtractor(pk), Rules.load(), base, af.Context(), [
        {"id": "with-alt", "disease_text": ["arthritis"], "comed": ["warfarin"]},
        {"id": "no-alt", "disease_text": ["arthritis"], "comed": ["warfarin"], "exclude_text": ["NOALT"]}],
        extract, log=lambda *_: None)
    s = res["summary"]
    assert s["necessity"]["overruled"] == 1 and s["necessity"]["held"] == 1
    assert s["context_dependent_drugs"]["Prednisone + Warfarin"] == {"accepted_in": ["no-alt"], "overruled_in": ["with-alt"]}
    assert res["rows"][0]["necessity_flips"] == 1
    assert "Same interaction, different verdict" in batch.markdown(res)


def test_batch_applies_per_query_patient_condition(tmp_path):
    pk, dd = _dbs(tmp_path)
    base = Namespace(exclude_text=[])
    ex = PrimeKGExtractor(pk)
    q = [{"id": "plain", "disease_text": ["arthritis"], "comed": []},
         {"id": "ulcer", "disease_text": ["arthritis"], "comed": [], "patient_condition": ["c_ulcerhx"]}]
    res = batch.run_batch(ex, Rules.load(), base, af.Context(), q,
                          lambda e, a: e.extract(a.disease_text, a.comed, 50), log=lambda *_: None)
    rows = {r["id"]: r for r in res["rows"]}
    assert rows["ulcer"]["objections"] > rows["plain"]["objections"]      # curated ulcer contraindications fired


def test_corroborate_indication(tmp_path):
    import csv
    rows = list(csv.reader(open(FIX / "primekg_drug_features.csv", encoding="utf-8")))
    hdr = rows[0]; i = hdr.index("indication")
    for r in rows[1:]:
        if r[0] == "n1":
            r[i] = "Ibuprofen is indicated for rheumatoid arthritis and osteoarthritis."
    feats = tmp_path / "f.csv"
    with open(feats, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(rows)
    pk_index(str(FIX / "primekg_kg.csv"), str(feats), str(tmp_path / "p.sqlite"), progress=False)
    ex = PrimeKGExtractor(str(tmp_path / "p.sqlite"))
    sg = ex.extract(["arthritis"], [], 50, corroborate=True)
    ids = [c["id"] for c in sg.candidates]
    assert "DB01050" in ids and "DB00788" not in ids                     # naproxen's text says nothing about arthritis
    assert "Naproxen" in sg.query["corroboration"]["dropped"]


def test_batch_094_vs_as_093(tmp_path):
    """Both modes run; --as-0.9.3 has no weak-evidence review, 0.9.4 strict turns weak-only rejections into review."""
    pk, dd = _dbs(tmp_path)
    q = tmp_path / "q.json"
    q.write_text(json.dumps({"queries": [{"id": "a/warfarin", "disease_text": ["arthritis"], "comed": ["warfarin"]}]}),
                 encoding="utf-8")
    out = {}
    for tag, extra in (("new", []), ("old", ["--as-0.9.3"])):
        main(["batch", str(q), "--primekg", pk, "--untyped-ddi", "strict", "-o", str(tmp_path / tag), *extra])
        out[tag] = json.loads((tmp_path / tag / "batch.json").read_text(encoding="utf-8"))["rows"][0]
    af.use_legacy_harm_tags(False)
    assert out["old"]["weak_evidence_review"] == 0 and out["old"]["kg_only_rejections"] >= 1
    assert out["new"]["weak_evidence_review"] >= 1
    assert out["new"]["af_necessity_rejected"] < out["old"]["af_necessity_rejected"]


def test_check_queries_prints_counts_not_verdicts(tmp_path, capsys):
    pk, _ = _dbs(tmp_path)
    q = tmp_path / "q.json"
    q.write_text(json.dumps({"queries": [{"id": "ok", "disease_text": ["arthritis"], "comed": ["warfarin"]},
                                         {"id": "bad", "disease_text": ["arthritis"], "comed": ["nosuchdrug"]}]}), encoding="utf-8")
    main(["check-queries", str(q), "--primekg", pk])
    out = capsys.readouterr().out
    assert "1 of 2 queries need attention" in out and "!! bad" in out
    assert "accepted" not in out and "rejected" not in out
