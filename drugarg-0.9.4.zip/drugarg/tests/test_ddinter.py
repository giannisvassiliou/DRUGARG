"""DDInter severities on top of the PrimeKG fixture."""
import json
from pathlib import Path

import pytest

from drugarg import af
from drugarg.cli import main
from drugarg.ddinter import DDInter, build_index, norm
from drugarg.primekg import PrimeKGExtractor, build_index as pk_index
from drugarg.rules import Rules

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def dbs(tmp_path_factory):
    t = tmp_path_factory.mktemp("dd")
    pk_index(str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), str(t / "pk.sqlite"), progress=False)
    st = build_index([str(FIX / "ddinter")], str(t / "dd.sqlite"))
    assert st["pairs"] == 7 and len(st["files"]) == 2
    return str(t / "pk.sqlite"), str(t / "dd.sqlite")


def test_norm():
    assert norm("Lithium carbonate") == norm("Lithium cation") == "lithium"
    assert norm("Acetylsalicylic acid") == "aspirin" and norm("Candesartan cilexetil") == "candesartan"


def test_levels_and_most_severe_kept(dbs):
    dd = DDInter(dbs[1])
    assert dd.level("Prednisone", "Warfarin") == "moderate"      # Moderate beats Minor
    assert dd.level("lithium carbonate", "Lisinopril") == "moderate"


def test_ddinter_in_af(dbs):
    pk, ddb = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    cov = DDInter(ddb).annotate(sg)
    assert cov["pairs_with_ddinter_level"] == 4
    F = af.build(sg, af.Context(), Rules.load())
    R = af.solve(F)
    assert F.args["DDI:DB00635:DB00682"].source == "KG + DDInter severity"     # prednisone: was "severity unknown"
    assert F.args["DDI:DB00635:DB00682"].sev == "moderate"
    assert F.args["DDI:DB00482:DB00682"].source == "DDInter (not in KG), curated mitigability"       # celecoxib: no KG edge
    assert "DDI:DB01296:DB00682" not in F.args                                 # glucosamine: minor, below threshold
    assert any("(DDInter)" in s for s in F.ignored["USE:DB01296"])
    assert R.status["USE:DB00635"] == "accepted"
    # strict: DDInter moderate without management text is not mitigated
    R2 = af.solve(af.build(sg, af.Context(untyped_ddi="strict"), Rules.load()))
    assert R2.status["USE:DB00635"] == "rejected"


def test_cli_with_ddinter(dbs, tmp_path, capsys):
    pk, ddb = dbs
    main(["ddinter-index", str(FIX / "ddinter"), "-o", str(tmp_path / "x.sqlite")])
    assert "drug pairs" in capsys.readouterr().out
    main(["run", "--primekg", pk, "--ddinter", ddb, "--disease-text", "arthritis", "--comed", "warfarin", "-o", str(tmp_path)])
    rep = (tmp_path / "report.md").read_text(encoding="utf-8")
    assert "DDInter: drug names matched" in rep and "DDInter (not in KG)" in rep
    run = json.loads((tmp_path / "run.json").read_text(encoding="utf-8"))
    assert run["objection_sources"].get("DDI: KG + DDInter severity", 0) >= 1


def test_sulfasalazine_not_nsaid_and_curated_mitigability_labelled(dbs):
    r = Rules.load()
    cats = ["Anti-Inflammatory Agents, Non-Steroidal", "ATC intestinal antiinflammatory agents and antirheumatic agents"]
    assert r.group_of("DB00795", cats) == "" and r.group_of("DB99990", cats) == ""
    pk, ddb = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    DDInter(ddb).annotate(sg)
    F = af.build(sg, af.Context(), r)
    assert F.args["DDI:DB01050:DB00682"].source == "KG + DDInter severity, curated mitigability"
