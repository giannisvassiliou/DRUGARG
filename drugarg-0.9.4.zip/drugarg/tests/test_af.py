"""Semantics on hand-built frameworks with known answers."""
from drugarg.af import Arg, Framework, solve, filter_baseline, counterfactual


def fw(nodes, attacks):
    F = Framework()
    for n, t in nodes:
        F.add(Arg(id=n, t=t, drug=n, label=n))
    F.attacks = attacks
    return F


def test_reinstatement_by_mitigation():
    # MIT -> DDI -> USE : USE is defended, grounded accepts it; the filter rejects it
    F = fw([("U", "USE"), ("D", "DDI"), ("M", "MIT")], [("D", "U"), ("M", "D")])
    R = solve(F)
    assert R.lab == {"U": "in", "D": "out", "M": "in"}
    assert R.status["U"] == "accepted"
    assert filter_baseline(F)["U"] == "rejected"


def test_mutual_attack_gives_credulous_alternatives():
    F = fw([("A", "USE"), ("B", "USE")], [("A", "B"), ("B", "A")])
    R = solve(F)
    assert R.lab["A"] == R.lab["B"] == "undec"
    assert sorted(map(tuple, R.preferred)) == [("A",), ("B",)]
    assert R.status == {"A": "alternative", "B": "alternative"}


def test_odd_cycle_rejects_all():
    F = fw([("A", "USE"), ("B", "USE"), ("C", "USE")], [("A", "B"), ("B", "C"), ("C", "A")])
    R = solve(F)
    assert R.preferred == [[]]
    assert set(R.status.values()) == {"rejected"}


def test_clique_with_one_defeated_member():
    # A, B, C mutually exclusive; A also attacked by an unattacked DDI -> A out, B/C pick-one
    n = [("A", "USE"), ("B", "USE"), ("C", "USE"), ("D", "DDI")]
    at = [(x, y) for x in "ABC" for y in "ABC" if x != y] + [("D", "A")]
    R = solve(fw(n, at))
    assert R.status == {"A": "rejected", "B": "alternative", "C": "alternative"}


def test_counterfactual_two_attackers():
    F = fw([("U", "USE"), ("C", "CI"), ("D", "DDI")], [("C", "U"), ("D", "U")])
    assert sorted(counterfactual(F, "U")) == ["C", "D"]


def test_large_clique_is_fast_and_exact():
    import time
    names = [f"N{i}" for i in range(24)]
    F = fw([(n, "USE") for n in names], [(a, b) for a in names for b in names if a != b])
    t = time.perf_counter(); R = solve(F); dt = time.perf_counter() - t
    assert len(R.preferred) == 24 and all(len(S) == 1 for S in R.preferred)
    assert set(R.status.values()) == {"alternative"} and dt < 0.5


def test_budget_exceeded_reports_undecided():
    names = [f"N{i}" for i in range(6)]
    F = fw([(n, "USE") for n in names], [(a, b) for a in names for b in names if a != b])
    R = solve(F, max_leaves=2)
    assert R.preferred is None and set(R.status.values()) == {"undecided"}
