"""PrimeKG backend on a small fixture with PrimeKG's column layout (both edge directions stored)."""
import json
from pathlib import Path

import pytest

from drugarg import af
from drugarg.cli import main
from drugarg.primekg import PrimeKGExtractor, build_index
from drugarg.rules import Rules

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def db(tmp_path_factory):
    out = tmp_path_factory.mktemp("pk") / "primekg.sqlite"
    st = build_index(str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), str(out), progress=False)
    assert st["relations"]["drug_protein"] == 2          # read but not indexed
    assert st["drug_drug_pairs"] == 6                    # both directions collapsed to one pair
    return str(out)


def test_candidates_groups_and_ranking(db):
    sg = PrimeKGExtractor(db).extract(["arthritis"], [], 50)
    ids = [c["id"] for c in sg.candidates]
    assert "DB00533" not in ids                          # withdrawn
    assert ids[0] == "DB01050"                           # indicated for 2 matched diseases (RA + OA)
    assert set(ids) == {"DB01050", "DB00788", "DB00482", "DB00563", "DB01296", "DB00635"}
    assert any(c.startswith("ATC ") and "non-steroids" in c for c in sg.drugs["DB01050"]["categories"])
    r = Rules.load()
    groups = {i: r.group_of(i, d["categories"]) for i, d in sg.drugs.items()}
    assert groups["DB01050"] == groups["DB00788"] == groups["DB00482"] == "NSAID"
    assert groups["DB01296"] == "" and groups["DB00563"] == ""   # glucosamine, methotrexate


def test_exclude_text_and_offlabel(db):
    ex = PrimeKGExtractor(db)
    sg = ex.extract(["hypertension"], [], 50, exclude_text=["ocular hypertension"])
    assert {c["id"] for c in sg.candidates} == {"DB00722", "DB00999", "DB00335", "DB00381"}  # timolol (ocular) excluded
    sg2 = ex.extract(["psoriatic"], [], 50, include_offlabel=True)
    assert [c["id"] for c in sg2.candidates] == ["DB00635"]


def test_kg_contraindications_and_ddis(db):
    sg = PrimeKGExtractor(db).extract(["arthritis"], ["warfarin", "Sertraline"], 50,
                                      patient_diseases=["peptic ulcer", "kidney disease"])
    kc = {(k["drug"], k["disease"]) for k in sg.kg_contra}
    assert kc == {("DB01050", "peptic ulcer disease"), ("DB00788", "peptic ulcer disease"),
                  ("DB00482", "chronic kidney disease"), ("DB00563", "chronic kidney disease")}
    pairs = {(x["a"], x["b"]) for x in sg.ddis}
    assert pairs == {("DB01050", "DB00682"), ("DB00788", "DB00682"), ("DB00635", "DB00682"), ("DB01050", "DB01104")}
    F = af.build(sg, af.Context(mitigations={"monitor": True, "ppi": True, "dose": True}), Rules.load())
    R = af.solve(F)
    s = {F.args[u].label: v for u, v in R.status.items()}
    assert s["Celecoxib"] == "rejected" and s["Methotrexate"] == "rejected"   # KG contraindication (CKD), absolute
    assert s["Ibuprofen"] == s["Naproxen"] == "rejected"                     # NSAID + warfarin (curated major)
    assert s["Prednisone"] == "accepted"                                     # untyped KG DDI, monitored
    ci = F.args["CI:DB01050:kg:10"]
    assert ci.kind == "relative" and ci.source == "KG + curated grading"     # ulcer: graded relative, PPI answers it
    assert R.lab["CI:DB01050:kg:10"] == "out"
    assert F.args["CI:DB00482:kg:11"].source == "KG"
    assert F.args["DDI:DB00635:DB00682"].source == "KG (severity unknown)"
    assert F.args["DDI:DB01050:DB00682"].source == "KG + curated severity"


def test_cli_run_and_eval(db, tmp_path, capsys):
    main(["run", "--primekg", db, "--disease-text", "arthritis", "--comed", "sertraline", "--comed", "lisinopril",
          "--patient-disease", "peptic ulcer", "--mitigation", "monitor", "--mitigation", "ppi", "-o", str(tmp_path)])
    run = json.loads((tmp_path / "run.json").read_text(encoding="utf-8"))
    assert run["objection_sources"]["CI: KG + curated grading"] == 2
    ans = json.loads((tmp_path / "answers.json").read_text(encoding="utf-8"))
    # ulcer history (answered by the PPI) and the sertraline bleeding interaction concern the same harm:
    # one mitigation per harm rejects the non-selective NSAIDs, celecoxib (no ulcer objection) stays
    assert {"Ibuprofen", "Naproxen"} <= set(ans["rejected"]) and "Celecoxib" in ans["accepted"]
    e = next(x for x in ans["explanations"] if x["name"] == "Ibuprofen")
    assert any("cumulative risk of bleeding" in o for o in e["effective_objections"])
    assert "Objections by source" in (tmp_path / "report.md").read_text(encoding="utf-8")
    import rdflib
    rdflib.Graph().parse(str(tmp_path / "subgraph.ttl"))
    demo = json.loads((tmp_path / "demo_dataset.json").read_text(encoding="utf-8"))
    assert any(c[0] == "kg_10" for c in demo["conditions"])
    capsys.readouterr()
    main(["eval", "--primekg", db, "--disease-text", "arthritis", "--comed", "warfarin",
          "--patient-disease", "kidney disease"])
    out = capsys.readouterr().out
    assert "objections_from_kg" in out and "| condition |" in out


def test_index_cli(tmp_path, capsys):
    main(["primekg-index", str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), "-o", str(tmp_path / "x.sqlite")])
    assert "contraindication" in capsys.readouterr().out
    main(["primekg-info", str(tmp_path / "x.sqlite")])
    assert "Ibuprofen" in capsys.readouterr().out


def test_primekg_sentence_features():
    from drugarg.primekg import parse_categories, parse_atc, parse_group
    cats = parse_categories("Ibuprofen is part of Acids, Carbocyclic ; Anti-Inflammatory Agents, Non-Steroidal ; COX-2 Inhibitors.")
    assert cats == ["Acids, Carbocyclic", "Anti-Inflammatory Agents, Non-Steroidal", "COX-2 Inhibitors"]
    assert parse_group("Glucosamine is approved and investigational.") == "approved and investigational"
    atc = parse_atc("Ibuprofen is pharmacologically related to other cardiac preparations and antiinflammatory and antirheumatic products, non-steroids.")
    assert atc.endswith("non-steroids")
    r = Rules.load()
    assert r.group_of("DB99991", cats + ["ATC " + atc]) == "NSAID"           # not in any id list
    mtx_like = ["Anti-Inflammatory Agents, Non-Steroidal", "ATC antimetabolites and antineoplastic and immunomodulating agents"]
    assert r.group_of("DB99992", mtx_like) == ""                              # ATC L excludes it
    assert r.group_of("DB99993", ["ATC ace inhibitors, plain"]) == "RAAS"
    assert r.group_of("DB99994", ["ATC thiazides, plain"]) == "THIAZIDE"
    assert r.group_of("DB99995", ["ATC selective serotonin reuptake inhibitors"]) == "SSRI"


def test_regressions_from_real_primekg_run(tmp_path):
    db = str(tmp_path / "r.sqlite")
    build_index(str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), db, progress=False)
    ex = PrimeKGExtractor(db)
    r = Rules.load()
    # combination-product classes must not assign a class
    sg = ex.extract(["hypertension"], ["lithium"], 50, exclude_text=["ocular"])
    g = {i: r.group_of(i, d["categories"]) for i, d in sg.drugs.items()}
    assert g["DB00335"] == "" and g["DB00381"] == ""          # atenolol, amlodipine
    assert g["DB00722"] == "RAAS" and g["DB00999"] == "THIAZIDE"
    # "ocular" removes the ocular-hypertension node (and timolol with it)
    assert "ocular hypertension" not in sg.query["matched_disease_nodes"]
    assert "DB00373" not in {c["id"] for c in sg.candidates}
    # "lithium" resolves to Lithium carbonate
    assert sg.comeds == ["DB14509"] and sg.unresolved == []
    # patient "peptic ulcer" means the exact node, not "active peptic ulcer disease"
    sg2 = ex.extract(["arthritis"], [], 50, patient_diseases=["peptic ulcer"])
    assert sg2.query["patient_disease_nodes"]["peptic ulcer"] == ["peptic ulcer disease"]
    # an active ulcer, if given, is absolute for NSAIDs even with a PPI
    sg3 = ex.extract(["arthritis"], [], 50, patient_diseases=["active peptic ulcer"])
    F = af.build(sg3, af.Context(mitigations={"monitor": True, "ppi": True, "dose": True}), r)
    ci = F.args["CI:DB01050:kg:15"]
    assert ci.kind == "absolute" and af.solve(F).status["USE:DB01050"] == "rejected"


def test_untyped_ddi_policy(db):
    sg = PrimeKGExtractor(db).extract(["arthritis"], ["warfarin"], 50)
    st = {}
    for pol in ("lenient", "strict", "ignore"):
        F = af.build(sg, af.Context(untyped_ddi=pol), Rules.load())
        st[pol] = af.solve(F).status["USE:DB00635"]           # prednisone + warfarin: KG edge, no severity
    assert st == {"lenient": "accepted", "strict": "rejected", "ignore": "accepted"}


def test_lithium_class_covers_primekg_lithium_carbonate():
    r = Rules.load()
    thz = {"id": "DB00999", "group": "THIAZIDE", "categories": []}
    li = {"id": "DB14509", "group": r.group_of("DB14509", []), "categories": []}
    assert li["group"] == "LITHIUM"
    assert r.classify_ddi(thz, li, "")["severity"] == "major"
    assert r.classify_ddi({"id": "DB00722", "group": "RAAS", "categories": []}, li, "")["mitigation"] == "monitor"


def test_synonyms_and_substring_warning(tmp_path):
    from drugarg.primekg import PrimeKGExtractor, build_index
    import csv
    kg = tmp_path / "kg.csv"
    rows = list(csv.reader(open(FIX / "primekg_kg.csv", encoding="utf-8")))
    extra = [["drug_drug", "synergistic interaction", "n90", "DB00945", "drug", "Acetylsalicylic acid", "DrugBank",
              "n91", "DB09999", "drug", "Nitroaspirin", "DrugBank"]]
    with open(kg, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(rows + extra)
    build_index(str(kg), str(FIX / "primekg_drug_features.csv"), str(tmp_path / "p.sqlite"), progress=False)
    ex = PrimeKGExtractor(str(tmp_path / "p.sqlite"))
    sg = ex.extract(["arthritis"], ["aspirin", "naprox"], 50)
    assert sg.query["comedication_resolution"]["aspirin"].startswith("Acetylsalicylic acid")
    assert not sg.query.get("comedication_warnings")            # 'naprox' is a prefix match, fine
    sg = ex.extract(["arthritis"], ["roxen"], 50)
    assert "matched only inside another name" in sg.query["comedication_warnings"][0]
    assert [r[2] for r in ex.find_diseases("arthritis")][:1]


def test_curated_indication_adds_candidate(db):
    ex = PrimeKGExtractor(db)
    ex.curated_indications = [{"disease_regex": "^osteoarthritis$", "drug": "DB00722", "note": "test"}]
    sg = ex.extract(["arthritis"], [], 50)
    c = next(x for x in sg.candidates if x["id"] == "DB00722")
    assert c["indication"].startswith("curated") and c["diseases"] == ["osteoarthritis"]
    assert sg.query["curated_indications"] and "test" in sg.query["curated_indications"][0]
    ex.curated_indications = [{"disease_regex": "gout", "drug": "DB00722"}]       # no matching node: nothing added
    assert "DB00722" not in {x["id"] for x in ex.extract(["arthritis"], [], 50).candidates}


def test_ssri_group_excludes_snris_and_paracetamol_is_not_nsaid():
    r = Rules.load()
    assert r.group_of("DBX", ["Serotonin Uptake Inhibitors"]) == ""
    assert r.group_of("DBX", ["Selective Serotonin Reuptake Inhibitors"]) == "SSRI"
    assert r.group_of("DB00316", ["Anti-Inflammatory Agents, Non-Steroidal"]) == ""
    assert r.mitigations["monitor"] == "Monitoring"
    assert any(ci["drug"] == "DB00316" for ci in r.d["curated_indications"])


def test_weak_only_rejection_goes_to_review(db):
    """0.9.4: an unrated KG edge alone cannot reject; strict policy now gives 'review', and the reason is recorded."""
    sg = PrimeKGExtractor(db).extract(["arthritis"], ["warfarin"], 50)
    F = af.build(sg, af.Context(untyped_ddi="strict", weak_review=True), Rules.load())
    R = af.solve(F)
    assert R.status["USE:DB00635"] == "review" and R.review_why["USE:DB00635"] == "weak evidence"
    e = next(x for x in af.explain(F, R, af.filter_baseline(F)) if x["drug"] == "DB00635")
    assert e["review_reason"] == "weak evidence" and e["counterfactual"]
    # a supported objection is not softened: celecoxib + warfarin keeps its verdict
    R0 = af.solve(af.build(sg, af.Context(untyped_ddi="strict"), Rules.load()))
    for u, s in R0.status.items():
        if s == "rejected" and u not in R.review_why:
            assert R.status[u] == "rejected"


def test_potassium_tags_have_direction():
    assert af.harms_of("may decrease serum potassium and increase digoxin toxicity") == ["hypokalaemia"]
    assert af.harms_of("raises potassium") == ["hyperkalaemia"]
    assert af.harms_of("potassium-sparing diuretic") == ["hyperkalaemia"]
    af.use_legacy_harm_tags(True)
    try:
        assert af.harms_of("may decrease serum potassium") == ["hyperkalaemia"]     # the 0.9.3 inversion
    finally:
        af.use_legacy_harm_tags(False)


def test_094_rules_can_be_dropped():
    new = Rules.load()
    old = Rules.load(drop_since="0.9.4")
    hit = lambda r: r.contraindications("DB00313", "", [], ["c_preg"])
    assert hit(new) and not hit(old)                         # valproate in pregnancy
    assert new.contraindications("DB06594", "", [], ["c_liver"])


def test_patient_disease_exact_name_with_disease_suffix(tmp_path):
    """'dementia' must pick 'dementia (disease)', not also 'Lewy body dementia' (0.9.4 pre-freeze fix)."""
    from drugarg.primekg import PrimeKGExtractor
    ex = PrimeKGExtractor.__new__(PrimeKGExtractor)
    rows = [(1, "d1", "dementia (disease)"), (2, "d2", "Lewy body dementia")]
    ex.q = lambda key, sql, args: rows
    assert [r[2] for r in ex.match_diseases(["dementia"], exact_first=True)] == ["dementia (disease)"]
    assert len(ex.match_diseases(["dementia"])) == 2            # indication matching stays substring-based
