"""DDInter management advice: page parsing, classification, fetch cache, and its effect on the AF."""
import shutil
import sys
import types
from pathlib import Path

import pytest

from drugarg import af
from drugarg.cli import main
from drugarg.ddinter import DDInter, build_index, classify_management, parse_result_page
from drugarg.primekg import PrimeKGExtractor, build_index as pk_index
from drugarg.rules import Rules

FIX = Path(__file__).parent / "fixtures"
PAGE = (FIX / "ddinter_pages" / "result_prednisone_warfarin.html").read_text(encoding="utf-8")


@pytest.mark.parametrize("text,expected", [
    ("Close monitoring for clinical and laboratory evidence of altered anticoagulant response is recommended.", "monitor"),
    ("Coadministration should generally be avoided. If concomitant use is required, monitor INR closely.", "monitor"),
    ("The use of these agents together is contraindicated.", None),
    ("Concomitant use with strong CYP3A4 inhibitors should be avoided.", None),
    ("A dosage reduction of X may be required when used with Y.", "dose"),
    ("The dose of digoxin may need to be reduced; monitor serum levels.", "dose"),
    ("Administer the antacid at least 2 hours before or 4 hours after the quinolone.", "timing"),
    ("Separate the administration times by several hours.", "timing"),
    ("", None),
])
def test_classify(text, expected):
    assert classify_management(text)[0] == expected


def test_parse_fixture_page():
    b = parse_result_page(PAGE)
    assert len(b) == 1 and b[0]["level"] == "moderate"
    assert b[0]["interaction"].startswith("Corticosteroids") and "not this" not in b[0]["interaction"]
    assert b[0]["management"].startswith("Close monitoring") and "&" in b[0]["management"]
    assert "Interactions with diseases" not in b[0]["management"]


class FakeResp:
    def __init__(self, text, code=200):
        self.text, self.status_code = text, code


@pytest.fixture()
def dbs(tmp_path, monkeypatch):
    pk_index(str(FIX / "primekg_kg.csv"), str(FIX / "primekg_drug_features.csv"), str(tmp_path / "pk.sqlite"), progress=False)
    build_index([str(FIX / "ddinter")], str(tmp_path / "dd.sqlite"))
    calls = []

    class Session:
        headers = {}

        def get(self, url, timeout=None):
            calls.append(url)
            return FakeResp(PAGE if ("DDInter1490" in url and "DDInter1951" in url) else "<html>no result</html>")

    monkeypatch.setitem(sys.modules, "requests", types.SimpleNamespace(Session=Session))
    return str(tmp_path / "pk.sqlite"), str(tmp_path / "dd.sqlite"), calls


def test_ids_indexed_and_fetch_cached(dbs):
    _, ddb, calls = dbs
    dd = DDInter(ddb)
    assert dd.has_ids and dd.ddid("Warfarin") == "DDInter1951" and dd.ddid("prednisone") == "DDInter1490"
    st = dd.fetch_management([("DDInter1951", "DDInter1490")], delay=0, log=lambda *_: None)
    assert st["fetched"] == 1 and len(calls) == 1
    st = dd.fetch_management([("DDInter1490", "DDInter1951")], delay=0, log=lambda *_: None)
    assert st["cached"] == 1 and len(calls) == 1                         # pair order does not matter; no refetch
    assert dd.management("DDInter1951", "DDInter1490")["management"].startswith("Close monitoring")


def test_rebuild_keeps_fetched_pages(dbs):
    _, ddb, _ = dbs
    DDInter(ddb).fetch_management([("DDInter1951", "DDInter1490")], delay=0, log=lambda *_: None)
    st = build_index([str(FIX / "ddinter")], ddb)
    assert st["management_pages_kept"] == 1 and DDInter(ddb).management("DDInter1490", "DDInter1951")


def test_management_makes_strict_mitigation_published(dbs):
    pk, ddb, _ = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    cov = DDInter(ddb).annotate(sg, fetch=True, delay=0, log=lambda *_: None)
    assert cov["pairs_with_management"] == 1
    # strict policy: without management prednisone was rejected (see test_ddinter.py); now the advice defends it
    F = af.build(sg, af.Context(untyped_ddi="strict"), Rules.load())
    a = F.args["DDI:DB00635:DB00682"]
    assert a.source == "KG + DDInter severity + DDInter management"
    mit = F.args["MIT:DDI:DB00635:DB00682"]
    assert mit.key == "monitor" and mit.source.startswith("DDInter management")
    R = af.solve(F)
    assert R.status["USE:DB00635"] == "accepted"
    assert "DDInter management" in af.describe(mit)
    # turning management off restores the strict result
    R2 = af.solve(af.build(sg, af.Context(untyped_ddi="strict", use_management=False), Rules.load()))
    assert R2.status["USE:DB00635"] == "rejected"


def test_avoid_advice_removes_curated_mitigation(dbs):
    pk, ddb, _ = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    dd = DDInter(ddb)
    dd.annotate(sg)
    k = "DB00635|DB00682"
    sg.ddinter_mgmt[k] = {"mitigation": None, "reason": "avoid: 'contraindicated'", "management": "Contraindicated.", "url": "u"}
    F = af.build(sg, af.Context(), Rules.load())               # lenient would have made it monitorable
    assert "MIT:DDI:DB00635:DB00682" not in F.args
    assert af.solve(F).status["USE:DB00635"] == "rejected"


def test_cli_show(dbs, capsys):
    _, ddb, _ = dbs
    main(["ddinter-show", ddb, "prednisone", "warfarin"])
    out = capsys.readouterr().out
    assert "DDInter1490" in out and "Management:  Close monitoring" in out and "=> mitigation: monitor" in out


SALICYLATE = ("Until further data are available, products containing salicylates, especially if given chronically or in "
              "high dosages, should preferably be avoided in patients receiving anticoagulants. Close clinical and "
              "laboratory observation for bleeding complications is recommended if these agents are used together.")


@pytest.mark.parametrize("text,mit,pref", [
    (SALICYLATE, "monitor", True),
    ("NSAIDs should be administered with oral anticoagulants only if benefit outweighs risk. Monitor closely.", "monitor", True),
    ("Close monitoring of INR is recommended.", "monitor", False),
    ("This combination should generally be avoided.", None, False),
])
def test_avoid_preferred(text, mit, pref):
    from drugarg.ddinter import management_profile
    p = management_profile(text)
    assert p["mitigation"] == mit and p["avoid_preferred"] == pref


def _conditional_prednisone(dbs):
    pk, ddb, _ = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    DDInter(ddb).annotate(sg)
    sg.ddinter_mgmt["DB00635|DB00682"] = {"mitigation": "monitor", "avoid_preferred": True, "reason": "test",
                                         "management": SALICYLATE, "url": "u"}
    return sg


def test_necessity_overrules_mitigation_when_alternative_accepted(dbs):
    sg = _conditional_prednisone(dbs)
    F = af.build(sg, af.Context(), Rules.load())
    mid = "MIT:DDI:DB00635:DB00682"
    assert "DB00563" in F.alternatives[mid]                 # methotrexate shares rheumatoid arthritis
    assert "DB00482" not in F.alternatives[mid]             # celecoxib: osteoarthritis only, not an alternative
    R = af.solve(F)
    assert R.status["USE:DB00563"] == "accepted" and R.status["USE:DB00635"] == "rejected"
    e = next(x for x in af.explain(F, R, af.filter_baseline(F)) if x["drug"] == "DB00635")
    assert e["overruled_mitigations"] and "Methotrexate" in e["overruled_mitigations"][0]["because_accepted"]
    # the same advice without the necessity attack: monitoring answers the objection
    assert af.solve(af.build(sg, af.Context(necessity=False), Rules.load())).status["USE:DB00635"] == "accepted"


def test_necessity_mitigation_holds_without_alternative(dbs):
    sg = _conditional_prednisone(dbs)
    sg.candidates = [c for c in sg.candidates if c["id"] != "DB00563"]     # no acceptable RA alternative left
    R = af.solve(af.build(sg, af.Context(), Rules.load()))
    assert R.status["USE:DB00635"] == "accepted"            # ibuprofen and naproxen are rejected, so they overrule nothing


def test_eval_has_necessity_row(dbs, tmp_path, capsys):
    pk, ddb, _ = dbs
    main(["eval", "--primekg", pk, "--ddinter", ddb, "--disease-text", "arthritis", "--comed", "warfarin", "-o", str(tmp_path)])
    assert "+necessity" in capsys.readouterr().out


def test_lithium_ace_advice_is_dose():
    from drugarg.ddinter import management_profile
    t = ("Serum lithium levels should be monitored more closely whenever an ACE inhibitor is added, and the lithium "
         "dosage adjusted as necessary. Empiric reductions of both drugs may be appropriate during initial therapy.")
    assert management_profile(t)["mitigation"] == "dose"


def test_alternative_counterfactual(dbs):
    sg = _conditional_prednisone(dbs)
    F = af.build(sg, af.Context(), Rules.load())
    names, status, n = af.alternative_counterfactual(F, "MIT:DDI:DB00635:DB00682")
    assert names == ["Methotrexate"] and status == "accepted"
    R = af.solve(F)
    e = next(x for x in af.explain(F, R, af.filter_baseline(F)) if x["drug"] == "DB00635")
    assert e["overruled_mitigations"][0]["counterfactual"] == {"unavailable": ["Methotrexate"], "status": "accepted", "of_alternatives": n}


def test_ddinter_silent_policy(dbs):
    pk, ddb, _ = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], ["warfarin"], 50)
    DDInter(ddb).annotate(sg)
    x = {"a": "DB00563", "b": "DB00682", "resource": "test", "text": ""}   # methotrexate + warfarin: unrated, no DDInter record
    sg.ddis.append(x)
    sg.ddinter_known = sorted(set(sg.ddinter_known) | {x["a"], x["b"]})
    F_strict = af.build(sg, af.Context(untyped_ddi="strict"), Rules.load())
    F_silent = af.build(sg, af.Context(untyped_ddi="ddinter-silent"), Rules.load())
    assert f"DDI:{x['a']}:{x['b']}" in F_strict.args and f"DDI:{x['a']}:{x['b']}" not in F_silent.args
    assert (x["a"], x["b"]) in F_silent.silent


def test_exclusions(dbs):
    from drugarg.extract import apply_exclusions
    pk, _, _ = dbs
    sg = PrimeKGExtractor(pk).extract(["arthritis"], [], 50)
    done = apply_exclusions(sg, [{"name": "Glucosamine", "reason": "supplement"}, "DB00563"])
    ids = [c["id"] for c in sg.candidates]
    assert "DB01296" not in ids and "DB00563" not in ids and len(done) == 2
    assert sg.query["excluded_drugs"][0]["reason"] in ("supplement", "")


def test_weak_alternative_sends_to_review(dbs):
    """The only alternative is blocked by an unrated KG edge: the mitigation is not trusted and not overruled."""
    sg = _conditional_prednisone(dbs)
    keep = {"DB00635", "DB00563"}                       # prednisone (conditional) and methotrexate (its alternative)
    sg.candidates = [c for c in sg.candidates if c["id"] in keep]
    sg.ddis.append({"a": "DB00563", "b": "DB00682", "resource": "test", "text": ""})   # unrated, KG only
    F = af.build(sg, af.Context(untyped_ddi="strict"), Rules.load())
    R = af.solve(F)
    assert R.status["USE:DB00563"] == "rejected"
    assert R.lab["ALT:DB00563"] == "in"                 # rejected on weak evidence only: still counts as available
    assert R.status["USE:DB00635"] == "review"
    # with a supported objection to methotrexate the mitigation holds and prednisone is accepted
    sg.ddis[-1]["text"] = "increases the risk of bleeding"
    sg.ddinter["DB00563|DB00682"] = "major"
    R2 = af.solve(af.build(sg, af.Context(untyped_ddi="strict"), Rules.load()))
    assert R2.status["USE:DB00563"] == "rejected" and R2.status["USE:DB00635"] == "accepted"


def test_minimal_counterfactual_and_review_not_disagreement(dbs):
    from drugarg import batch
    sg = _conditional_prednisone(dbs)
    F = af.build(sg, af.Context(), Rules.load())
    r = af.alternative_counterfactual(F, "MIT:DDI:DB00635:DB00682")
    assert r and len(r[0]) <= r[2]
    class R: status = {"a": "review", "b": "accepted"}
    assert batch._disagree(R, {"a": "accepted", "b": "rejected"}) == 1


def test_export_mgmt(dbs, tmp_path, capsys):
    import csv
    pk, ddb, _ = dbs
    main(["ddinter-show", ddb, "prednisone", "warfarin"])          # caches one page through the fake session
    main(["export-mgmt", ddb, "-o", str(tmp_path / "lab")])
    blind = list(csv.reader(open(tmp_path / "lab" / "mgmt_texts_blind.csv", encoding="utf-8-sig")))
    key = list(csv.reader(open(tmp_path / "lab" / "mgmt_texts_key.csv", encoding="utf-8-sig")))
    assert len(blind) == len(key) >= 2 and blind[1][0] == key[1][0]
    assert not any("system" in h for h in blind[0])               # the blind sheet carries no system labels


def test_query_scope_alternatives(dbs):
    """0.9.4: with alt_scope='query' every candidate of the query is an alternative, not only those sharing a node."""
    sg = _conditional_prednisone(dbs)
    mid = "MIT:DDI:DB00635:DB00682"
    assert "DB00482" not in af.build(sg, af.Context(), Rules.load()).alternatives[mid]
    assert "DB00482" in af.build(sg, af.Context(alt_scope="query"), Rules.load()).alternatives[mid]
