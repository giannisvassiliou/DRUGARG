# DrugArg

Query-driven argumentation over Bio2RDF DrugBank. Given a disease keyword, a patient's conditions and
co-medications, DrugArg:

1. **extracts** a bounded subgraph from a SPARQL endpoint: candidate drugs whose DrugBank indication
   text matches the disease, their categories, and the KG-asserted interactions with the co-medications;
2. **builds** a Dung argumentation framework: `USE` arguments (candidate treatments), `IND` supports
   (indication evidence), `CI` (condition contraindications), `DDI` (interactions), `MIT` (mitigations
   that attack relative contraindications and non-major interactions), and mutual `USE↔USE` attacks
   for therapeutic duplication;
3. **solves** it under grounded semantics (skeptical) and preferred semantics (credulous, "pick one");
4. **compares** with a rule-filter baseline and **explains** every decision, including the smallest
   counterfactual (one or two objections) that would lift a rejected option.

## Install

```bash
pip install -e .            # HTTP endpoint only
pip install -e ".[test]"    # + rdflib (local RDF files) and pytest
```

## Two knowledge sources

| | Bio2RDF DrugBank (SPARQL) | PrimeKG (local SQLite index) |
|---|---|---|
| Candidates | indication **text** contains the disease keyword | `indication` (optionally `off-label use`) **edges** to disease nodes whose name contains the keyword |
| Contraindications | none in the KG; curated rules (`--patient-condition`) | `contraindication` **edges** to the patient's disease nodes (`--patient-disease`), plus curated rules |
| Interactions | `ddi-interactor-in` resources with a text description | `drug_drug` edges, no description or severity |
| Severity | curated pairs, else regex on the text | curated pairs, else `untyped_ddi_severity` (moderate, monitorable) |

Every objection in a report is tagged with its source (`KG`, `KG + curated grading`, `KG + curated severity`,
`KG (severity unknown)`, `text-heuristic`, `curated`, `curated (not in KG)`), and `run.json` /
the report header count them, so the paper can state how much of the reasoning the KG supports.

## PrimeKG

Download `kg.csv` and `drug_features.csv` from Harvard Dataverse (doi:10.7910/DVN/IXA7BM), e.g.

```bash
wget -O kg.csv https://dataverse.harvard.edu/api/access/datafile/6180620
```

then build the index once (a few minutes; ~100 MB):

```bash
drugarg primekg-index kg.csv drug_features.csv -o primekg.sqlite
drugarg primekg-info primekg.sqlite
drugarg run --primekg primekg.sqlite --disease-text arthritis \
  --comed sertraline --comed lisinopril --patient-disease "peptic ulcer" \
  --mitigation monitor --mitigation ppi --max-candidates 30 -o out/
```

`--patient-disease` is matched as a substring of PrimeKG disease names; the matched nodes are listed in
`answers.json` (`query.patient_disease_nodes`). PrimeKG contraindications carry no absolute/relative grade:
they are absolute unless `kg_contraindication_rules` in the rules file grades them (e.g. NSAIDs with a
peptic ulcer → relative, answerable by a PPI).

## DDInter severities (optional, either backend)

DDInter (ddinter2.scbdd.com, CC BY-NC-SA 4.0) publishes curated interaction levels (Major / Moderate / Minor).
Download the `ddinter_downloads_code_*.csv` files into one folder, then

```bash
drugarg ddinter-index ddinter_folder/ -o ddinter.sqlite
drugarg run --primekg primekg.sqlite --ddinter ddinter.sqlite --disease-text arthritis --comed warfarin -o out/
```

Pairs are matched to KG drugs by normalised name (salts and a few synonyms removed); the report states how many
names matched and lists the unmatched ones. A DDInter level replaces curated, text-derived and default severities
(tagged `KG + DDInter severity`, or `DDInter (not in KG)` when only DDInter knows the pair). The bulk files carry
levels but no management text, so without the step below whether a moderate DDInter interaction is mitigable
still follows `--untyped-ddi` (lenient: monitorable; strict: not mitigable).

### Management advice (published mitigations)

Each pair's checker page, `https://ddinter2.scbdd.com/checker/result/<DDInterID>-<DDInterID>/`, has an
`Interaction:` and a `Management:` paragraph. With `--ddinter-fetch` the run downloads the pages it needs
(only major/moderate pairs between its candidates and co-medications; one request per second; stored in
`ddinter.sqlite` with the raw HTML, so a second run is offline and rebuilding the index keeps them):

```bash
drugarg ddinter-show ddinter.sqlite prednisone warfarin --save-html pw.html   # check one pair first
drugarg run  --primekg primekg.sqlite --ddinter ddinter.sqlite --ddinter-fetch --untyped-ddi strict ... -o out/
drugarg ddinter-reparse ddinter.sqlite     # after a parser change, re-read cached pages without the network
```

The management text is mapped to a mitigation: unconditional "avoid / contraindicated / not recommended" -> no
mitigation (the objection stands); otherwise the most specific action named: dose adjustment -> `dose`,
separate administration times -> `timing`, monitoring -> `monitor`. The mapping overrides curated and default
mitigability (tag `... + DDInter management`) and the report quotes the advice next to the mitigation, so each
defeat can be checked against its source. Major interactions stay unmitigated unless `--management-mitigates-major`.
`--no-management` gives the severity-only result for comparison.

**Avoid unless necessary.** Some advice prefers not to combine the drugs but allows it with an action
("should preferably be avoided ... observation is recommended if these agents are used together";
"only if benefit outweighs risk"). That mitigation is attacked by every other candidate for a shared indication
that does not itself rely on such advice: if any of them is accepted, the combination is avoidable and the
objection stands; if none is, the mitigation holds. The verdict on one drug therefore depends on the verdicts
on the others, which a per-drug filter cannot express. `--no-necessity` switches this off; `eval` reports it as
the `+necessity` row. Do not redistribute fetched pages (CC BY-NC-SA).

## Bio2RDF: check your endpoint's vocabulary

Bio2RDF releases differ in a few predicate names. Run this once against the endpoint you will use:

```bash
drugarg probe --endpoint https://bio2rdf.org/sparql
drugarg probe --endpoint http://localhost:8890/sparql          # local Virtuoso mirror
```

It prints every predicate on `drugbank:DB01050` and the triples on its DDI resources. The defaults
expect `dbv:indication`, `dbv:category`, `dcterms:title`/`rdfs:label`, and
`dbv:ddi-interactor-in | dbv:is-ddi-interactor-in` to a `dbv:Drug-Drug-Interaction` resource carrying
`dcterms:description` or `rdfs:label`. If your release differs, put the right URIs in a JSON file and pass
`--vocab vocab.json`, e.g.

```json
{"ddi_path": "<http://bio2rdf.org/drugbank_vocabulary:ddi-interactor-in>",
 "indication": "http://bio2rdf.org/drugbank_vocabulary:indication"}
```

## Run

```bash
drugarg run --endpoint https://bio2rdf.org/sparql \
  --disease-text arthritis --comed warfarin --comed sertraline \
  --patient-condition c_ulcerhx --mitigation monitor --mitigation ppi -o out/
```

Outputs in `out/`:

| File | Content |
|---|---|
| `report.md` | per-drug table: argumentation vs filter, why, counterfactual |
| `answers.json` | accepted / pick-one / rejected sets, explanations |
| `arggraph.json`, `arggraph.dot` | the framework with grounded labels and preferred extensions (`dot -Tpdf`) |
| `subgraph.json`, `subgraph.ttl` | the extracted, bounded subgraph |
| `run.json` | counts and timings (per query, construction, semantics) |
| `demo_dataset.json` | load it in the DrugArg demo page (Data → paste → Load dataset) |

Options: `--threshold minor|moderate|major` (lowest DDI severity that becomes an attack),
`--no-mitigations`, `--no-duplication`, `--max-candidates N`, `--rules my_rules.json`,
`--method POST`, `--timeout`, `--retries`. Co-medications can be names or DrugBank ids.

Queries are cached in `.drugarg-cache/` keyed by endpoint and query text, so a run can be repeated
exactly even when the public endpoint is down (`--no-cache` to bypass).

## Paper-style evaluation

```bash
drugarg eval --endpoint ... --disease-text arthritis --comed warfarin --comed sertraline \
  --patient-condition c_ulcerhx --mitigation monitor --mitigation ppi -o out/
```

One extraction, five contexts (bare, condition, condition+comed, +mitigations, +mitigations+duplication).
For each: argument and attack counts, accepted / pick-one / rejected, filter rejections, disagreement
with the filter, shrinkage vs bare, defeat attribution, counterfactual flip rate, median semantics time.

## Offline / tests

`--rdf-file dump.ttl` runs the same SPARQL with rdflib over a local dump (e.g. a slice of the
Bio2RDF DrugBank N-Quads). `pytest` runs the semantics tests and an end-to-end test over
`tests/fixtures/mini_bio2rdf.ttl`, a small hand-written Bio2RDF-shaped fixture.

## What comes from the KG and what does not

Bio2RDF DrugBank gives drugs, indication text, categories and interaction assertions with a text
description. It does **not** give structured condition contraindications, interaction severity or
mitigations. Those come from `drugarg/data/rules.json`:

- **contraindications**: curated rules by DrugBank id, group (`grp:NSAID`) or category regex (`cat:...`);
- **severity**: curated overrides first (marked `curated`), otherwise regex rules over the DDI text
  (marked `text-heuristic`), otherwise the default (`default`). The source is shown in every explanation;
- **mitigations**: which objection a mitigation can answer (never absolute contraindications or major DDIs);
- **groups**: duplication classes by DrugBank id or category label.

Treat the bundled rules as a starting point to review, not clinical knowledge. This is a research prototype.

## Batch evaluation

```bash
drugarg batch --primekg primekg.sqlite --ddinter ddinter.sqlite -o batch/            # bundled 30-query set
drugarg batch my_queries.json --primekg primekg.sqlite --ddinter ddinter.sqlite --ddinter-fetch -o batch/
drugarg batch --primekg primekg.sqlite --ddinter ddinter.sqlite --only hypertension -o batch_htn/
```

Each query (`id`, `disease_text`, `comed`, `patient_condition`, `patient_disease`, `exclude_text`) is solved four
ways: rule filter, argumentation with DDInter severities only, + management advice, + necessity. `batch.md`
reports per query the disagreements with the filter for each variant, how many "avoid unless necessary"
mitigations appear and whether they were overruled or held, verdict flips caused by necessity, drugs whose
verdict depends on the query (held in one, overruled in another), and rejections that rest only on KG edges
with no published or curated support. Interactions without severity default to `--untyped-ddi strict` here.

## Version 0.9: counterfactual alternatives, DDInter-silent edges, reviewed exclusions

* For every overruled "avoid unless necessary" mitigation the report says which accepted alternatives would have
  to be unavailable for it to hold ("would be acceptable if unavailable: Celecoxib, Tramadol"). `batch` counts these.
* `--untyped-ddi ddinter-silent`: a PrimeKG interaction without severity is dropped when DDInter covers both drugs
  and records no interaction between them (listed as "not confirmed by DDInter"); otherwise it is treated as strict.
  Report strict and lenient as bounds.
* `exclude_drugs` in a query file (or `--exclude-drug NAME`) removes reviewed indication errors; the report lists them
  with their reason.

## 0.9.1: evidence-ranked necessity, one mitigation per harm

- **Necessity attacks come from `ALT:x`, not `USE:x`.** `ALT:x` ("x is an available alternative") is defeated only
  by supported objections to x: published severity, DDInter management, curated rules or curated KG grading.
  Unrated KG interaction edges and raw KG contraindication edges cannot make an alternative unavailable.
  If an "avoid unless necessary" mitigation is overruled only by alternatives that are themselves rejected on such
  weak evidence, the drug gets status **`review`**: not accepted, not rejected, check those edges. `review` never
  counts as a disagreement with the filter. Batch column: `necessity_review`.
- **One mitigation per harm** (`--no-same-harm` turns it off). Objections are tagged with harms (bleeding, QT
  prolongation, hyperkalaemia, serotonin toxicity, renal injury, CNS/respiratory depression, myelosuppression)
  from the condition label, KG text and DDInter interaction/management text. If two objections concern the same
  harm, one of them is a contraindication or a major interaction, and at least one is answered only by a mitigation,
  an unattacked `CUM` argument rejects the drug. Example: ulcer history (answered by a PPI) plus warfarin or an SSRI
  (bleeding) rejects non-selective NSAIDs. Batch column: `cumulative_harm_rejections`.
- **Counterfactuals are minimal and honest.** `alternative_counterfactual` prunes the removed set to a minimal one and
  reports the total number of alternatives; reports say "acceptable only if all k of these (of N) were unavailable".

## 0.9.2

- One mitigation per harm counts only supported objections (unrated KG edges and raw KG contraindications never stack).
- Harm tags name outcomes, not mechanisms: "renal clearance of lithium" is no longer "renal injury", platelet
  "serotonin" is no longer "serotonin toxicity".
- Batch: `cumulative_harm_decisive` = rejections that the cumulative-risk rule alone causes (solved again without
  the `CUM` arguments); review cases are listed only when the drug's status is actually `review`; the summary reports the
  smallest counterfactual set.

## 0.9.3 (frozen for the held-out run)

- `curated_indications` in rules.json adds documented candidates where PrimeKG lacks an indication edge; the only entry is
  paracetamol (DB00316) for osteoarthritis. Reported in run and batch output; `--no-curated-indications` turns it off.
- SSRI group no longer matches DrugBank's broad "Serotonin Uptake Inhibitors" category (which put SNRIs and trazodone in
  the SSRI choose-one group). Paracetamol is explicitly not an NSAID.
- Mitigation label "Monitoring" (was a fixed list "INR, renal function, potassium, drug levels" shown for every pair).

## 0.9.3.post1

Adds `drugarg export-mgmt ddinter.sqlite -o labels` (labelling sheets). No change to reasoning; verdicts are identical to 0.9.3.

## 0.9.4 (post-hoc: written after the held-out results were seen)

Report 0.9.4 in its own row. It never replaces the 0.9.3 held-out numbers.

- **Weak evidence never rejects on its own.** If every objection that stands against a drug is an unrated KG edge (no DDInter severity, no published management advice, no curated rule or grading), and the drug would not be rejected without those edges, the verdict is `review`, not `rejected`. The reason goes in `review_reason` (`weak evidence`, `necessity`, or both). Batch column: `weak_evidence_review`. Switch off with `--no-weak-review`.
- **Alternatives across the whole query.** An "avoid unless necessary" mitigation can now be overruled by any candidate of the query, not only by candidates that share the same PrimeKG disease node. `--alt-scope node` restores the 0.9.3 scope.
- **Potassium in both directions.** `hyperkalaemia` now needs a direction ("raises potassium", "potassium-sparing" …), and a new `hypokalaemia` tag covers potassium loss (loop/thiazide diuretic + digoxin). `--legacy-harm-tags` restores the 0.9.3 tags.
- **Curated rules added after the held-out run**, marked `"since": "0.9.4"` in rules.json: valproate and aliskiren in pregnancy, duloxetine and agomelatine in hepatic impairment. `--no-094-rules` drops them.
- **Candidate cap raised from 50 to 200.** A truncated list now shows up in the error column, and the summary has `truncated_queries`.
- `--as-0.9.3` switches everything above back to 0.9.3 behaviour (on the test fixtures it gives batch output identical to 0.9.3.post1). Each flag can also be switched off on its own, for an ablation.

`drugarg check-queries FILE --primekg DB` checks a query file before freezing. It reports whether disease texts, co-medications and patient diseases resolve, and prints counts only: no candidates, no verdicts.

0.9.4 reporting fix (before the held-out-2 freeze): `cumulative_harm_decisive` now counts only drugs that would be acceptable without the cumulative-risk argument. Drugs that would only reach `review` are counted separately, in `cumulative_harm_decisive_review`. Verdicts are unchanged.

0.9.4 pre-freeze matching fix: a patient disease also matches a node named exactly `<term> (disease)`. Before this fix, "dementia" fell back to substring matching and also picked up "Lewy body dementia". No development or held-out-1 query is affected: their patient diseases match exact node names.
